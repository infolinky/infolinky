import 'dotenv/config';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import type { Request, Response } from 'express';
import { GoogleGenAI } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.resolve(__dirname, 'data');
const SUBMISSIONS_FILE = path.join(DATA_DIR, 'submissions.json');
const PRODUCTS_FILE = path.resolve(__dirname, 'src', 'data', 'products.json');

interface AiRequestBody {
  toolId?: string;
  input?: string;
  tone?: string;
  length?: string;
  targetLanguage?: string;
  platform?: string;
  audience?: string;
  recipient?: string;
}

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function buildAiPrompt(body: AiRequestBody): { systemInstruction: string; contents: string } {
  const toolId = body.toolId || 'ai-text-generator';
  const input = (body.input || '').trim();
  const tone = body.tone || 'Professional';
  const length = body.length || 'Medium';
  const targetLanguage = body.targetLanguage || 'Spanish';
  const platform = body.platform || 'LinkedIn';

  switch (toolId) {
    case 'ai-content-writer':
      return {
        systemInstruction: `You are an experienced digital copywriter. Write clear, scannable, conversion-focused content without hype or clichés. Tone: ${tone}. Desired length: ${length}.`,
        contents: `Write high-clarity marketing/web content for the following brief:\n\n${input}`,
      };
    case 'ai-paragraph-rewriter':
      return {
        systemInstruction: `You are an editorial rewriter. Preserve the original meaning and facts while improving clarity, flow, and sentence rhythm. Tone: ${tone}.`,
        contents: `Rewrite the following paragraph cleanly:\n\n${input}`,
      };
    case 'ai-summarizer':
      return {
        systemInstruction: `You are an executive editor. Summarize the provided text accurately without inventing facts. Provide a concise overview followed by key bullet points. Desired length: ${length}.`,
        contents: `Summarize the following text:\n\n${input}`,
      };
    case 'ai-translator':
      return {
        systemInstruction: `You are a professional translator. Translate accurately into ${targetLanguage} while preserving the original meaning, formatting, and ${tone.toLowerCase()} register. Output the translation directly.`,
        contents: input,
      };
    case 'ai-grammar-checker':
      return {
        systemInstruction: `You are a strict copy editor. First provide the fully corrected version under "Corrected Text:", then list the specific grammar, punctuation, or clarity fixes made under "Key Improvements:".`,
        contents: `Proofread and correct the following text:\n\n${input}`,
      };
    case 'ai-email-writer':
      return {
        systemInstruction: `You are a professional business communicator. Write a clear, polite email with a Subject line, concise body, and clear next step. Tone: ${tone}. Length: ${length}.`,
        contents: `Compose an email based on these details:\n\n${input}`,
      };
    case 'ai-social-caption':
      return {
        systemInstruction: `You are a social media strategist. Write 3 distinct, natural caption variations tailored for ${platform} with appropriate formatting and 3-5 relevant hashtags at the end. Tone: ${tone}.`,
        contents: `Create ${platform} captions for:\n\n${input}`,
      };
    case 'ai-blog-post':
      return {
        systemInstruction: `You are an international editorial writer. Produce a well-structured blog post with an SEO title, meta description, clear H2/H3 headings, practical advice, and a concise conclusion. Avoid fabricated statistics. Tone: ${tone}. Target length: ${length}.`,
        contents: `Write a structured blog article about:\n\n${input}`,
      };
    case 'cover-letter-enhance':
      return {
        systemInstruction: `You are a career editor. Refine the applicant's cover letter draft so it reads naturally, highlights concrete achievements, and avoids generic buzzwords. Tone: ${tone}.`,
        contents: `Polish this cover letter draft:\n\n${input}`,
      };
    case 'ai-text-generator':
    default:
      return {
        systemInstruction: `You are a helpful, accurate writing assistant. Fulfill the user's request clearly with well-organized prose. Tone: ${tone}. Length: ${length}.`,
        contents: input,
      };
  }
}

async function ensureDataDir(): Promise<void> {
  await fs.mkdir(DATA_DIR, { recursive: true });
}

interface StoredSubmission {
  id: string;
  type: 'product-listing' | 'advertising' | 'contact';
  status: 'pending_review';
  createdAt: string;
  payload: Record<string, unknown>;
}

async function saveSubmission(entry: StoredSubmission): Promise<void> {
  await ensureDataDir();
  let existing: StoredSubmission[] = [];
  try {
    const raw = await fs.readFile(SUBMISSIONS_FILE, 'utf-8');
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      existing = parsed;
    }
  } catch {
    existing = [];
  }
  existing.unshift(entry);
  await fs.writeFile(SUBMISSIONS_FILE, JSON.stringify(existing, null, 2), 'utf-8');
}

async function forwardToWebhook(entry: StoredSubmission): Promise<boolean> {
  const webhookUrl = process.env.FORM_WEBHOOK_URL?.trim();
  if (!webhookUrl) {
    return false;
  }
  try {
    const resp = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify(entry),
    });
    return resp.ok;
  } catch {
    return false;
  }
}

function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function isValidHttpUrl(url: string): boolean {
  try {
    const u = new URL(url);
    return u.protocol === 'https:' || u.protocol === 'http:';
  } catch {
    return false;
  }
}

async function startServer(): Promise<void> {
  const app = express();
  app.use(express.json({ limit: '4mb' }));

  // Health check
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({ ok: true, service: 'infolinky-api' });
  });

  // Download complete project archive
  app.get('/download/infolinky-complete-project.zip', (_req: Request, res: Response) => {
    const zipPath = path.join(DATA_DIR, 'infolinky-complete-project.zip');
    res.download(zipPath, 'infolinky-complete-project.zip', (err) => {
      if (err && !res.headersSent) {
        res.status(404).json({ error: 'Project archive not found.' });
      }
    });
  });

  // Owner-managed products JSON feed
  app.get('/api/products', async (_req: Request, res: Response) => {
    try {
      const raw = await fs.readFile(PRODUCTS_FILE, 'utf-8');
      res.type('application/json').send(raw);
    } catch {
      res.status(500).json({ error: 'Unable to load products catalog.' });
    }
  });

  // Server-side Gemini AI Writing endpoint
  app.post('/api/ai/generate', async (req: Request, res: Response) => {
    const body = (req.body || {}) as AiRequestBody;
    const input = typeof body.input === 'string' ? body.input.trim() : '';

    if (!input) {
      res.status(400).json({ error: 'Please enter text or a prompt before generating.' });
      return;
    }
    if (input.length > 15000) {
      res.status(400).json({ error: 'Input exceeds the 15,000-character limit per request.' });
      return;
    }

    const ai = getGeminiClient();
    if (!ai) {
      res.status(503).json({
        error:
          'AI Writing service requires GEMINI_API_KEY to be configured on the server (Settings > Secrets). Browser-based PDF, image, business, design, and converter tools remain fully available.',
      });
      return;
    }

    try {
      const { systemInstruction, contents } = buildAiPrompt(body);
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents,
        config: {
          systemInstruction,
        },
      });

      const output = (response.text || '').trim();
      if (!output) {
        res.status(502).json({ error: 'The AI model returned an empty response. Please refine your prompt and retry.' });
        return;
      }

      res.json({ ok: true, output });
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Unexpected AI service error.';
      const status =
        message.includes('403') || message.includes('PERMISSION_DENIED')
          ? 403
          : message.includes('429') || message.includes('RESOURCE_EXHAUSTED')
            ? 429
            : 500;
      res.status(status).json({ error: message });
    }
  });

  // Third-party Product Listing Request submission (pending owner verification)
  app.post('/api/submissions/product-listing', async (req: Request, res: Response) => {
    const p = (req.body || {}) as Record<string, unknown>;
    const requiredStrings = [
      'fullName',
      'companyName',
      'businessEmail',
      'companyWebsite',
      'productName',
      'productCategory',
      'productDescription',
      'officialProductUrl',
      'promotionOption',
    ];

    for (const field of requiredStrings) {
      if (typeof p[field] !== 'string' || !String(p[field]).trim()) {
        res.status(400).json({ error: `Missing required field: ${field}` });
        return;
      }
    }

    if (!isValidEmail(String(p.businessEmail))) {
      res.status(400).json({ error: 'Please provide a valid business email address.' });
      return;
    }
    if (!isValidHttpUrl(String(p.companyWebsite)) || !isValidHttpUrl(String(p.officialProductUrl))) {
      res.status(400).json({ error: 'Company Website and Official Product URL must start with https:// or http://.' });
      return;
    }

    const entry: StoredSubmission = {
      id: `prod_${Date.now()}`,
      type: 'product-listing',
      status: 'pending_review',
      createdAt: new Date().toISOString(),
      payload: {
        fullName: String(p.fullName).trim(),
        companyName: String(p.companyName).trim(),
        businessEmail: String(p.businessEmail).trim(),
        contactNumber: typeof p.contactNumber === 'string' ? p.contactNumber.trim() : '',
        companyWebsite: String(p.companyWebsite).trim(),
        productName: String(p.productName).trim(),
        productCategory: String(p.productCategory).trim(),
        productDescription: String(p.productDescription).trim(),
        productPrice: typeof p.productPrice === 'string' ? p.productPrice.trim() : '',
        officialProductUrl: String(p.officialProductUrl).trim(),
        affiliateLink: typeof p.affiliateLink === 'string' ? p.affiliateLink.trim() : '',
        promotionOption: String(p.promotionOption).trim(),
        additionalMessage: typeof p.additionalMessage === 'string' ? p.additionalMessage.trim() : '',
        logoFileName: typeof p.logoFileName === 'string' ? p.logoFileName.trim() : '',
        logoDataUrl: typeof p.logoDataUrl === 'string' && p.logoDataUrl.length < 1_500_000 ? p.logoDataUrl : '',
      },
    };

    try {
      await saveSubmission(entry);
      const relayed = await forwardToWebhook(entry);
      res.json({
        ok: true,
        id: entry.id,
        status: entry.status,
        relayed,
        message: relayed
          ? 'Your product listing request has been recorded and forwarded to InfoLinky editorial review.'
          : 'Your product listing request has been recorded in the pending review queue. No products are published without owner verification.',
      });
    } catch {
      res.status(500).json({ error: 'Failed to save product listing request. Please email aliraza.kgm@gmail.com directly.' });
    }
  });

  // Advertising Inquiry submission
  app.post('/api/submissions/advertising', async (req: Request, res: Response) => {
    const p = (req.body || {}) as Record<string, unknown>;
    const required = ['fullName', 'companyName', 'businessEmail', 'websiteUrl', 'advertisingType', 'duration', 'message'];
    for (const field of required) {
      if (typeof p[field] !== 'string' || !String(p[field]).trim()) {
        res.status(400).json({ error: `Missing required field: ${field}` });
        return;
      }
    }
    if (!isValidEmail(String(p.businessEmail))) {
      res.status(400).json({ error: 'Please provide a valid business email address.' });
      return;
    }
    if (!isValidHttpUrl(String(p.websiteUrl))) {
      res.status(400).json({ error: 'Website URL must start with https:// or http://.' });
      return;
    }

    const entry: StoredSubmission = {
      id: `adv_${Date.now()}`,
      type: 'advertising',
      status: 'pending_review',
      createdAt: new Date().toISOString(),
      payload: {
        fullName: String(p.fullName).trim(),
        companyName: String(p.companyName).trim(),
        businessEmail: String(p.businessEmail).trim(),
        websiteUrl: String(p.websiteUrl).trim(),
        advertisingType: String(p.advertisingType).trim(),
        duration: String(p.duration).trim(),
        budget: typeof p.budget === 'string' ? p.budget.trim() : '',
        message: String(p.message).trim(),
      },
    };

    try {
      await saveSubmission(entry);
      const relayed = await forwardToWebhook(entry);
      res.json({
        ok: true,
        id: entry.id,
        relayed,
        message: relayed
          ? 'Your advertising request has been sent for review by Ali Raza.'
          : 'Your advertising request has been recorded in the InfoLinky inquiry queue.',
      });
    } catch {
      res.status(500).json({ error: 'Unable to save inquiry. Please email aliraza.kgm@gmail.com directly.' });
    }
  });

  // General Contact submission
  app.post('/api/submissions/contact', async (req: Request, res: Response) => {
    const p = (req.body || {}) as Record<string, unknown>;
    if (
      typeof p.name !== 'string' ||
      !p.name.trim() ||
      typeof p.email !== 'string' ||
      !isValidEmail(p.email.trim()) ||
      typeof p.subject !== 'string' ||
      !p.subject.trim() ||
      typeof p.message !== 'string' ||
      !p.message.trim()
    ) {
      res.status(400).json({ error: 'Please complete your name, a valid email, subject, and message.' });
      return;
    }

    const entry: StoredSubmission = {
      id: `msg_${Date.now()}`,
      type: 'contact',
      status: 'pending_review',
      createdAt: new Date().toISOString(),
      payload: {
        name: p.name.trim(),
        email: p.email.trim(),
        subject: p.subject.trim(),
        message: p.message.trim(),
      },
    };

    try {
      await saveSubmission(entry);
      const relayed = await forwardToWebhook(entry);
      res.json({
        ok: true,
        id: entry.id,
        relayed,
        message: relayed
          ? 'Your message has been forwarded to InfoLinky.'
          : 'Your message has been logged in the InfoLinky inbox queue.',
      });
    } catch {
      res.status(500).json({ error: 'Unable to save message. Please email aliraza.kgm@gmail.com directly.' });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`InfoLinky server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start InfoLinky server:', err);
  process.exit(1);
});
