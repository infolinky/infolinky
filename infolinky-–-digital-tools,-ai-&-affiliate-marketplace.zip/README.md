# InfoLinky – Digital Tools, AI Workspace & Software Marketplace

**Website:** https://infolinky.github.io/infolinky/  
**Owner:** Ali Raza (Hyderabad, Pakistan)  
**Contact:** aliraza.kgm@gmail.com  

## Overview

InfoLinky combines:
1. **51 Digital Utilities** across 7 suites (AI Writing, Image Tools, PDF Tools, Productivity, Business, Design, and File & Unit Converters).
2. **Affiliate Products Marketplace** (`src/data/products.json`) with owner-configured tracking links and FTC disclosure.
3. **Editorial Guides, Free eBook Funnel & Business Partnerships** (Software Reviews, Online Earning, Affiliate Marketing, Resources, Systeme.io eBook funnel, Product Listing Request form, and Advertising Inquiry form).

---

## Local Development

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

### Environment Variables (`.env`)
Copy `.env.example` to `.env` when running the Express backend (`server.ts`):
- `GEMINI_API_KEY`: Enables the 9 server-side AI Writing Tools (`/api/ai/generate`).
- `FORM_WEBHOOK_URL` *(optional)*: Webhook endpoint to forward Product Listing, Advertising, and Contact submissions.

---

## Build & Deploy to GitHub Pages (`https://infolinky.github.io/infolinky/`)

GitHub Pages is static hosting. All 42 browser-based utilities (PDF, Image, Productivity, Business, Design, Converters) and the Marketplace work 100% statically.

### Option A: Automated Deployment with GitHub Actions (Recommended)
1. Create or open your repository named `infolinky` under GitHub account `infolinky` (URL: `https://github.com/infolinky/infolinky`).
2. Push all project files to the `main` branch:
   ```bash
   git init
   git add .
   git commit -m "Deploy InfoLinky website"
   git branch -M main
   git remote add origin https://github.com/infolinky/infolinky.git
   git push -u origin main
   ```
3. In your GitHub repository, open **Settings → Pages**.
4. Under **Build and deployment → Source**, choose **GitHub Actions**.
5. The included workflow (`.github/workflows/deploy-gh-pages.yml`) automatically runs `npm run build:gh-pages` and publishes `./dist` to `https://infolinky.github.io/infolinky/`.

### Option B: Manual Build & Push to `gh-pages` Branch
1. Build with the `/infolinky/` base path and SPA `404.html` fallback:
   ```bash
   npm install
   npm run build:gh-pages
   ```
2. Deploy the generated `dist/` folder using `gh-pages`:
   ```bash
   npx gh-pages -d dist
   ```
3. In GitHub **Settings → Pages**, set the source to the `gh-pages` branch (`/ (root)`).

> **Deploying to a Custom Domain or User Root (`username.github.io`):**  
> Run `npm run build` (uses base path `/`) and copy `dist/index.html` to `dist/404.html`.

---

## Owner Customization Notes

- **Marketplace Products & Affiliate Links:** Edit `src/data/products.json`. Add your verified `affiliateUrl` for any product or add new entries.
- **Google AdSense, GA4, Search Console & Static Form Endpoints:** Configure `src/config/siteConfig.ts` (for example, add a Formspree endpoint in `staticFormEndpoint` when hosting purely statically on GitHub Pages without `server.ts`).
- **Server-Side AI Tools on Static Hosting:** To keep AI Writing Tools active on GitHub Pages, deploy `server.ts` separately (e.g., Cloud Run, Render, or Railway) and proxy `/api/ai/generate`, keeping `GEMINI_API_KEY` strictly on the server.
