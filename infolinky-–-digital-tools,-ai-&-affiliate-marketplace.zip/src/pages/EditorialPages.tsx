import { Link } from 'react-router-dom';
import { Check, X, ExternalLink, ArrowRight } from 'lucide-react';
import { SOFTWARE_REVIEWS, EDUCATIONAL_GUIDES } from '../data/editorialData';
import { ASSETS } from '../assets/assetMap';
import { ResilientImage } from '../components/ResilientImage';
import { PageMeta } from '../components/PageMeta';
import { AdPlacement } from '../components/AdPlacement';
import { EbookFunnelSection } from '../components/EbookFunnelSection';

export function SoftwareReviewsPage() {
  return (
    <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-10 space-y-10">
      <PageMeta
        title="Honest Software Reviews & Comparisons – InfoLinky"
        description="Transparent SaaS evaluations showing pros, cons, realistic pricing, and ideal use cases for SEO, funnels, hosting, and design software."
      />

      <section className="bg-white border border-slate-200 rounded-2xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 items-stretch">
        <div className="lg:col-span-7 p-6 sm:p-10 flex flex-col justify-center space-y-3">
          <div className="text-xs font-semibold text-[#2563EB]">
            Independent Software Evaluations
          </div>
          <h1 className="font-display text-2xl sm:text-4xl font-bold text-[#101C35]">
            Honest Software Reviews &amp; Side-by-Side Trade-Offs
          </h1>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Every software subscription carries strengths and limitations. We document clear
            advantages, drawbacks, and pricing context so you choose tools that fit your budget.
          </p>
        </div>
        <div className="lg:col-span-5 min-h-[220px]">
          <ResilientImage
            src={ASSETS.softwareReviews}
            alt="Software Review and Interface Comparison"
            className="w-full h-full object-cover"
          />
        </div>
      </section>

      <div className="space-y-6">
        {SOFTWARE_REVIEWS.map((review) => (
          <article
            key={review.id}
            className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 space-y-5"
          >
            <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 border-b border-slate-100 pb-4">
              <div>
                <div className="text-xs text-slate-500 mb-1">
                  {review.category} · {review.pricingSummary}
                </div>
                <h2 className="font-display text-2xl font-bold text-[#101C35]">
                  {review.name} Review
                </h2>
                <p className="text-sm font-medium text-[#2563EB] mt-1">{review.verdict}</p>
              </div>
              <a
                href={review.officialUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 h-9 px-4 rounded-lg bg-[#101C35] text-white text-xs font-semibold hover:bg-[#1b2d52] shrink-0"
              >
                <span>Official Site</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            <p className="text-sm text-slate-700 leading-relaxed">{review.summary}</p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-[#F5F7FB] rounded-xl p-5 space-y-2.5 border border-slate-200">
                <h3 className="text-xs font-semibold text-[#059669]">Key Advantages</h3>
                <ul className="space-y-2 text-xs text-slate-700">
                  {review.pros.map((pro, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-[#059669] shrink-0 mt-0.5" />
                      <span>{pro}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="bg-[#F5F7FB] rounded-xl p-5 space-y-2.5 border border-slate-200">
                <h3 className="text-xs font-semibold text-rose-700">Disadvantages to Consider</h3>
                <ul className="space-y-2 text-xs text-slate-700">
                  {review.cons.map((con, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <X className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                      <span>{con}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="text-xs text-slate-500">
              <strong className="text-[#101C35]">Best suited for:</strong> {review.bestFor}
            </div>
          </article>
        ))}
      </div>

      <AdPlacement placement="article" />
    </div>
  );
}

export function OnlineEarningPage() {
  const articles = EDUCATIONAL_GUIDES.filter((g) => g.section === 'online-earning');

  return (
    <div className="max-w-[1140px] mx-auto px-4 sm:px-6 py-10 space-y-10">
      <PageMeta
        title="Online Earning Education – Practical Digital Skills – InfoLinky"
        description="Realistic guides on digital freelancing, selling practical templates, and building sustainable online income without false guarantees."
      />

      <section className="bg-white border border-slate-200 rounded-2xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 items-stretch">
        <div className="lg:col-span-7 p-6 sm:p-10 flex flex-col justify-center space-y-3">
          <div className="text-xs font-semibold text-[#059669]">
            Skill-First Digital Business Education
          </div>
          <h1 className="font-display text-2xl sm:text-4xl font-bold text-[#101C35]">
            Online Earning Education Built on Real Skills
          </h1>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Sustainable online revenue requires valuable skills, consistent execution, and customer
            trust. InfoLinky never promotes get-rich-quick shortcuts or guaranteed income claims.
          </p>
        </div>
        <div className="lg:col-span-5 min-h-[220px]">
          <ResilientImage
            src={ASSETS.onlineEarning}
            alt="Independent digital worker building sustainable online skills"
            className="w-full h-full object-cover"
          />
        </div>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {articles.map((art) => (
          <article key={art.id} className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 space-y-4">
            <div className="text-xs text-slate-500">
              Online Earning Guide · {art.readTime}
            </div>
            <h2 className="font-display text-xl font-bold text-[#101C35]">{art.title}</h2>
            <p className="text-sm text-slate-600">{art.summary}</p>
            <div className="space-y-3 text-sm text-slate-700 leading-relaxed">
              {art.body.map((para, idx) => (
                <p key={idx}>{para}</p>
              ))}
            </div>
            <div className="pt-3 border-t border-slate-100 space-y-2">
              <div className="text-xs font-semibold text-[#101C35]">Actionable Takeaways</div>
              <ul className="space-y-1.5 text-xs text-slate-600">
                {art.keyTakeaways.map((tk, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <Check className="w-3.5 h-3.5 text-[#059669] shrink-0 mt-0.5" />
                    <span>{tk}</span>
                  </li>
                ))}
              </ul>
            </div>
          </article>
        ))}
      </div>

      <div className="bg-[#101C35] text-white rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="space-y-1">
          <h3 className="font-display text-lg font-bold">Ready to Build Client Deliverables?</h3>
          <p className="text-xs sm:text-sm text-slate-300">
            Use InfoLinky&apos;s Invoice Generator, Quotation Generator, and Resume Builder for free.
          </p>
        </div>
        <Link
          to="/business-tools"
          className="h-10 px-5 rounded-lg bg-[#D4AF37] text-[#101C35] text-xs font-semibold inline-flex items-center gap-2 shrink-0"
        >
          <span>Open Business Tools</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>
    </div>
  );
}

export function AffiliateMarketingPage() {
  const articles = EDUCATIONAL_GUIDES.filter((g) => g.section === 'affiliate-marketing');

  return (
    <div className="max-w-[1140px] mx-auto px-4 sm:px-6 py-10 space-y-10">
      <PageMeta
        title="Affiliate Marketing Tutorials & Website Playbook – InfoLinky"
        description="Learn ethical affiliate publishing, transparent review writing, website hosting selection, and email list architecture."
      />

      <div className="space-y-3">
        <div className="text-xs font-semibold text-[#2563EB]">
          Affiliate &amp; Website Building Tutorials
        </div>
        <h1 className="font-display text-3xl sm:text-4xl font-bold text-[#101C35]">
          Ethical Affiliate Marketing &amp; Platform Growth
        </h1>
        <p className="text-sm sm:text-base text-slate-600 max-w-3xl leading-relaxed">
          Learn how to structure comparison websites, pair free utilities with educational content,
          and comply with FTC disclosure standards. Earnings depend entirely on traffic quality,
          reader trust, and sustained effort.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {articles.map((art) => (
          <article key={art.id} className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 space-y-4">
            <div className="text-xs text-slate-500">Tutorial · {art.readTime}</div>
            <h2 className="font-display text-xl font-bold text-[#101C35]">{art.title}</h2>
            <p className="text-sm text-slate-600">{art.summary}</p>
            <div className="space-y-3 text-sm text-slate-700 leading-relaxed">
              {art.body.map((para, idx) => (
                <p key={idx}>{para}</p>
              ))}
            </div>
            <ul className="pt-3 border-t border-slate-100 space-y-1.5 text-xs text-slate-600">
              {art.keyTakeaways.map((tk, i) => (
                <li key={i} className="flex items-start gap-2">
                  <Check className="w-3.5 h-3.5 text-[#059669] shrink-0 mt-0.5" />
                  <span>{tk}</span>
                </li>
              ))}
            </ul>
          </article>
        ))}
      </div>

      <AdPlacement placement="inline" />
    </div>
  );
}

export function ResourcesPage() {
  const articles = EDUCATIONAL_GUIDES.filter((g) => g.section === 'resources');

  return (
    <div className="max-w-[1140px] mx-auto px-4 sm:px-6 py-10 space-y-10">
      <PageMeta
        title="Digital Business Resources & Guides – InfoLinky"
        description="Practical launch checklists, AI prompting guides, and productivity workflows curated by InfoLinky."
      />

      <div className="space-y-3">
        <h1 className="font-display text-3xl sm:text-4xl font-bold text-[#101C35]">
          Resources &amp; Digital Playbooks
        </h1>
        <p className="text-sm sm:text-base text-slate-600 max-w-2xl">
          Practical guides for launching websites, structuring AI prompts, and organizing everyday
          business operations.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {articles.map((art) => (
          <article key={art.id} className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 space-y-4">
            <div className="text-xs text-slate-500">Resource Guide · {art.readTime}</div>
            <h2 className="font-display text-xl font-bold text-[#101C35]">{art.title}</h2>
            <p className="text-sm text-slate-600">{art.summary}</p>
            <div className="space-y-3 text-sm text-slate-700 leading-relaxed">
              {art.body.map((para, idx) => (
                <p key={idx}>{para}</p>
              ))}
            </div>
            <ul className="pt-3 border-t border-slate-100 space-y-1.5 text-xs text-slate-600">
              {art.keyTakeaways.map((tk, i) => (
                <li key={i} className="flex items-start gap-2">
                  <Check className="w-3.5 h-3.5 text-[#059669] shrink-0 mt-0.5" />
                  <span>{tk}</span>
                </li>
              ))}
            </ul>
          </article>
        ))}
      </div>

      <EbookFunnelSection />
    </div>
  );
}

export function EbookPage() {
  return (
    <div className="max-w-[1140px] mx-auto px-4 sm:px-6 py-10 space-y-10">
      <PageMeta
        title="Free eBook – Discover New Digital Opportunities – InfoLinky"
        description="Get your free InfoLinky eBook through our Systeme.io funnel and explore practical AI, productivity, and online business workflows."
      />

      <EbookFunnelSection />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-2">
          <div className="font-mono text-xs text-[#2563EB]">01. Foundation</div>
          <h2 className="font-display text-lg font-bold text-[#101C35]">
            Choosing High-Demand Digital Skills
          </h2>
          <p className="text-sm text-slate-600">
            How to identify durable service and content niches without chasing temporary trends.
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-2">
          <div className="font-mono text-xs text-[#2563EB]">02. Execution</div>
          <h2 className="font-display text-lg font-bold text-[#101C35]">
            Practical AI &amp; Automation Workflows
          </h2>
          <p className="text-sm text-slate-600">
            Using browser tools and structured AI drafting responsibly to improve daily output.
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-2">
          <div className="font-mono text-xs text-[#2563EB]">03. Monetization</div>
          <h2 className="font-display text-lg font-bold text-[#101C35]">
            Ethical Websites &amp; Funnels
          </h2>
          <p className="text-sm text-slate-600">
            Structuring useful resources, transparent software recommendations, and email delivery.
          </p>
        </div>
      </div>
    </div>
  );
}
