import { useState, useMemo } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Search, ArrowRight } from 'lucide-react';
import { TOOL_CATEGORIES, TOOLS_CATALOG, type ToolCategoryId } from '../data/toolsCatalog';
import { PageMeta } from '../components/PageMeta';
import { AdPlacement } from '../components/AdPlacement';

export function AllToolsPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialQuery = searchParams.get('q') || '';
  const [query, setQuery] = useState(initialQuery);
  const [selectedCat, setSelectedCat] = useState<'all' | ToolCategoryId>('all');

  const filteredTools = useMemo(() => {
    const q = query.trim().toLowerCase();
    return TOOLS_CATALOG.filter((tool) => {
      const catMatch = selectedCat === 'all' || tool.category === selectedCat;
      if (!catMatch) return false;
      if (!q) return true;
      return (
        tool.name.toLowerCase().includes(q) ||
        tool.description.toLowerCase().includes(q) ||
        tool.categoryLabel.toLowerCase().includes(q)
      );
    });
  }, [query, selectedCat]);

  const handleQueryChange = (val: string) => {
    setQuery(val);
    if (val.trim()) {
      setSearchParams({ q: val });
    } else {
      setSearchParams({});
    }
  };

  return (
    <div className="max-w-[1280px] mx-auto px-4 sm:px-6 py-10 space-y-8">
      <PageMeta
        title="All 51 Digital Tools – InfoLinky Utility Hub"
        description="Search and launch 51 working browser-based and AI writing tools across PDF, image, productivity, business, design, and converter suites."
      />

      <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 space-y-5">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
          <div>
            <h1 className="font-display text-2xl sm:text-4xl font-bold text-[#101C35]">
              All InfoLinky Digital Tools
            </h1>
            <p className="text-sm sm:text-base text-slate-600 mt-1.5 max-w-2xl">
              Select any utility below to open its interactive workspace. Document, image, design,
              calculator, and conversion tools process locally in your browser.
            </p>
          </div>
          <div className="text-xs font-medium text-slate-500 tabular-nums">
            Showing {filteredTools.length} of {TOOLS_CATALOG.length} tools
          </div>
        </div>

        <div className="relative max-w-xl">
          <Search
            className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
            aria-hidden="true"
          />
          <input
            type="search"
            value={query}
            onChange={(e) => handleQueryChange(e.target.value)}
            placeholder="Filter tools by name or task (e.g. Compress, Invoice, Translator, QR)..."
            className="w-full h-11 pl-10 pr-4 rounded-xl border border-slate-200 bg-[#F5F7FB] focus:bg-white text-sm text-[#101C35] focus:outline-none focus:border-[#2563EB]"
          />
        </div>

        {/* Category Filter Tabs */}
        <div className="flex flex-wrap gap-1.5 p-1.5 bg-[#F5F7FB] rounded-xl border border-slate-200">
          <button
            type="button"
            onClick={() => setSelectedCat('all')}
            className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              selectedCat === 'all'
                ? 'bg-[#101C35] text-white'
                : 'text-slate-600 hover:text-[#101C35]'
            }`}
          >
            All Suites ({TOOLS_CATALOG.length})
          </button>
          {TOOL_CATEGORIES.map((cat) => {
            const count = TOOLS_CATALOG.filter((t) => t.category === cat.id).length;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCat(cat.id)}
                className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  selectedCat === cat.id
                    ? 'bg-[#101C35] text-white'
                    : 'text-slate-600 hover:text-[#101C35]'
                }`}
              >
                {cat.shortLabel} ({count})
              </button>
            );
          })}
        </div>
      </div>

      {filteredTools.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center space-y-3">
          <p className="text-sm text-slate-600">
            No tools matched &ldquo;{query}&rdquo;. Try clearing your search filter.
          </p>
          <button
            type="button"
            onClick={() => {
              handleQueryChange('');
              setSelectedCat('all');
            }}
            className="px-4 py-2 rounded-lg bg-[#2563EB] text-white text-xs font-semibold cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredTools.map((tool) => (
            <Link
              key={tool.id}
              to={tool.route}
              className="group bg-white border border-slate-200 hover:border-[#2563EB] rounded-xl p-5 flex flex-col justify-between gap-4 transition-all duration-150"
            >
              <div>
                <div className="text-xs text-slate-500 mb-1.5">
                  {tool.categoryLabel}
                  <span className="mx-1.5" aria-hidden="true">·</span>
                  <span>{tool.mode === 'ai-backend' ? 'Server AI' : 'Browser Local'}</span>
                </div>
                <h2 className="font-display text-lg font-bold text-[#101C35] group-hover:text-[#2563EB]">
                  {tool.name}
                </h2>
                <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">
                  {tool.description}
                </p>
              </div>
              <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#2563EB]">
                <span>Open Tool</span>
                <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
              </div>
            </Link>
          ))}
        </div>
      )}

      <AdPlacement placement="inline" />
    </div>
  );
}
