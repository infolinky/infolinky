import { useState } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2, AlertCircle, Mail, MapPin, Upload, Loader2 } from 'lucide-react';
import { SITE_CONFIG } from '../config/siteConfig';
import { ASSETS } from '../assets/assetMap';
import { ResilientImage } from '../components/ResilientImage';
import { PageMeta } from '../components/PageMeta';

const PROMOTION_OPTIONS = [
  'Standard Product Listing',
  'Featured Product Listing',
  'Sponsored Product',
  'Banner Promotion',
  'Affiliate Partnership',
  'Sponsored Review',
];

const PRODUCT_CATEGORIES = [
  'AI Software',
  'Website Hosting',
  'Digital Marketing Software',
  'Graphic Design Software',
  'Online Business Services',
  'Educational Products',
  'Productivity Software',
  'Digital Subscriptions',
  'Other Digital Product',
];

export function SubmitProductPage() {
  const [form, setForm] = useState({
    fullName: '',
    companyName: '',
    businessEmail: '',
    contactNumber: '',
    companyWebsite: '',
    productName: '',
    productCategory: PRODUCT_CATEGORIES[0],
    productDescription: '',
    productPrice: '',
    officialProductUrl: '',
    affiliateLink: '',
    promotionOption: PROMOTION_OPTIONS[0],
    additionalMessage: '',
  });
  const [logoFileName, setLogoFileName] = useState('');
  const [logoDataUrl, setLogoDataUrl] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState<{ id: string; message: string; relayed: boolean } | null>(null);

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 1_000_000) {
      setError('Logo/image upload must be under 1 MB.');
      return;
    }
    setLogoFileName(file.name);
    const reader = new FileReader();
    reader.onload = () => setLogoDataUrl(String(reader.result));
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setResult(null);
    setBusy(true);

    try {
      const endpoint =
        SITE_CONFIG.staticFormEndpoint.productListing || '/api/submissions/product-listing';
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ ...form, logoFileName, logoDataUrl }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Could not submit product listing request.');
      } else {
        setResult({
          id: data.id || 'submitted',
          message:
            data.message ||
            'Product listing request received for owner review. Unverified products are never auto-published.',
          relayed: Boolean(data.relayed),
        });
      }
    } catch {
      setError(
        `Could not reach the submission backend. Please email your product details directly to ${SITE_CONFIG.contactEmail} using the email button below.`
      );
    } finally {
      setBusy(false);
    }
  };

  const mailtoHref = `mailto:${SITE_CONFIG.contactEmail}?subject=${encodeURIComponent(
    `InfoLinky Product Listing Request: ${form.productName || 'New Product'}`
  )}&body=${encodeURIComponent(
    `Full Name: ${form.fullName}\nCompany: ${form.companyName}\nBusiness Email: ${form.businessEmail}\nWebsite: ${form.companyWebsite}\nProduct Name: ${form.productName}\nCategory: ${form.productCategory}\nOfficial URL: ${form.officialProductUrl}\nAffiliate Link: ${form.affiliateLink}\nPrice: ${form.productPrice}\nPromotion Option: ${form.promotionOption}\nDescription: ${form.productDescription}\nMessage: ${form.additionalMessage}`
  )}`;

  return (
    <div className="max-w-[960px] mx-auto px-4 sm:px-6 py-10 space-y-8">
      <PageMeta
        title="List Your Product on InfoLinky – Submit Software or Service"
        description="Submit your legitimate software product, SaaS tool, or digital service for editorial review and placement on InfoLinky."
      />

      <div className="space-y-3">
        <div className="text-xs font-semibold text-[#2563EB]">
          Third-Party Product Listing Service
        </div>
        <h1 className="font-display text-2xl sm:text-4xl font-bold text-[#101C35]">
          LIST YOUR PRODUCT ON INFOLINKY
        </h1>
        <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
          Software developers, SaaS teams, and legitimate brands may request placement in the
          InfoLinky Marketplace. Every submission is manually reviewed by Ali Raza before
          publication—unverified products are never published automatically.
        </p>
      </div>

      <form
        onSubmit={handleSubmit}
        className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 space-y-5"
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-[#101C35] mb-1">
              1. Full Name *
            </label>
            <input
              type="text"
              required
              value={form.fullName}
              onChange={(e) => setForm({ ...form, fullName: e.target.value })}
              className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-[#101C35] mb-1">
              2. Company or Brand Name *
            </label>
            <input
              type="text"
              required
              value={form.companyName}
              onChange={(e) => setForm({ ...form, companyName: e.target.value })}
              className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-[#101C35] mb-1">
              3. Business Email *
            </label>
            <input
              type="email"
              required
              value={form.businessEmail}
              onChange={(e) => setForm({ ...form, businessEmail: e.target.value })}
              className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-[#101C35] mb-1">
              4. Contact Number (Optional)
            </label>
            <input
              type="tel"
              value={form.contactNumber}
              onChange={(e) => setForm({ ...form, contactNumber: e.target.value })}
              className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-[#101C35] mb-1">
              5. Company Website *
            </label>
            <input
              type="url"
              required
              placeholder="https://company.com"
              value={form.companyWebsite}
              onChange={(e) => setForm({ ...form, companyWebsite: e.target.value })}
              className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-[#101C35] mb-1">
              6. Product Name *
            </label>
            <input
              type="text"
              required
              value={form.productName}
              onChange={(e) => setForm({ ...form, productName: e.target.value })}
              className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-[#101C35] mb-1">
              7. Product Category *
            </label>
            <select
              value={form.productCategory}
              onChange={(e) => setForm({ ...form, productCategory: e.target.value })}
              className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm bg-white"
            >
              {PRODUCT_CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-[#101C35] mb-1">
              10. Product Price (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g. Free tier / $29/mo"
              value={form.productPrice}
              onChange={(e) => setForm({ ...form, productPrice: e.target.value })}
              className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-[#101C35] mb-1">
            8. Product Description *
          </label>
          <textarea
            rows={4}
            required
            value={form.productDescription}
            onChange={(e) => setForm({ ...form, productDescription: e.target.value })}
            placeholder="Summarize key capabilities, ideal users, and verified features..."
            className="w-full p-3 rounded-lg border border-slate-200 text-sm"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-[#101C35] mb-1">
              11. Official Product URL *
            </label>
            <input
              type="url"
              required
              placeholder="https://product.com"
              value={form.officialProductUrl}
              onChange={(e) => setForm({ ...form, officialProductUrl: e.target.value })}
              className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-[#101C35] mb-1">
              12. Affiliate Link (Optional)
            </label>
            <input
              type="url"
              placeholder="https://..."
              value={form.affiliateLink}
              onChange={(e) => setForm({ ...form, affiliateLink: e.target.value })}
              className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-[#101C35] mb-1">
              9. Product Image or Logo Upload
            </label>
            <label className="flex items-center gap-2 h-10 px-3 rounded-lg border border-dashed border-slate-300 bg-[#F5F7FB] text-xs text-slate-700 cursor-pointer hover:border-[#2563EB]">
              <Upload className="w-4 h-4 text-[#2563EB]" />
              <span className="truncate">{logoFileName || 'Choose PNG/JPG logo (max 1MB)'}</span>
              <input type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
            </label>
          </div>
          <div>
            <label className="block text-xs font-semibold text-[#101C35] mb-1">
              13. Advertising or Promotion Requirements *
            </label>
            <select
              value={form.promotionOption}
              onChange={(e) => setForm({ ...form, promotionOption: e.target.value })}
              className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm bg-white"
            >
              {PROMOTION_OPTIONS.map((opt) => (
                <option key={opt} value={opt}>
                  {opt}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-[#101C35] mb-1">
            14. Additional Message
          </label>
          <textarea
            rows={3}
            value={form.additionalMessage}
            onChange={(e) => setForm({ ...form, additionalMessage: e.target.value })}
            placeholder="Share demo credentials for review, commission terms, or launch dates..."
            className="w-full p-3 rounded-lg border border-slate-200 text-sm"
          />
        </div>

        {error && (
          <div className="p-3.5 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {result && (
          <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 space-y-2 text-xs text-emerald-900">
            <div className="flex items-center gap-2 font-semibold">
              <CheckCircle2 className="w-4 h-4 text-[#059669]" />
              <span>Submission Recorded (Reference: {result.id})</span>
            </div>
            <p>{result.message}</p>
            {!result.relayed && (
              <p>
                To also send a direct email copy to {SITE_CONFIG.contactEmail},{' '}
                <a href={mailtoHref} className="font-semibold underline text-[#101C35]">
                  open pre-filled email draft
                </a>
                .
              </p>
            )}
          </div>
        )}

        <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
          <button
            type="submit"
            disabled={busy}
            className="h-11 px-6 rounded-lg bg-[#2563EB] hover:bg-[#1d4ed8] disabled:opacity-60 text-white text-sm font-semibold inline-flex items-center gap-2 cursor-pointer"
          >
            {busy && <Loader2 className="w-4 h-4 animate-spin" />}
            <span>SUBMIT PRODUCT LISTING REQUEST</span>
          </button>

          <a href={mailtoHref} className="text-xs font-medium text-slate-600 hover:text-[#101C35] underline">
            Or send directly to {SITE_CONFIG.contactEmail}
          </a>
        </div>
      </form>
    </div>
  );
}

const AD_SERVICES = [
  'Website Banner Advertising',
  'Homepage Featured Advertising',
  'Sponsored Articles',
  'Sponsored Product Reviews',
  'Product Promotions',
  'Featured Product Placement',
  'Software Promotions',
  'Affiliate Partnerships',
  'Business Collaborations',
];

const AD_DURATIONS = ['7 Days', '15 Days', '30 Days', '3 Months', 'Custom Duration'];

export function AdvertiseWithUsPage() {
  const [form, setForm] = useState({
    fullName: '',
    companyName: '',
    businessEmail: '',
    websiteUrl: '',
    advertisingType: AD_SERVICES[0],
    duration: AD_DURATIONS[2],
    budget: '',
    message: '',
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState<{ id: string; message: string; relayed: boolean } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setResult(null);
    setBusy(true);
    try {
      const endpoint =
        SITE_CONFIG.staticFormEndpoint.advertising || '/api/submissions/advertising';
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Could not submit advertising inquiry.');
      } else {
        setResult({
          id: data.id || 'adv_logged',
          message: data.message || 'Advertising inquiry recorded for review.',
          relayed: Boolean(data.relayed),
        });
      }
    } catch {
      setError(`Could not reach submission server. Please email ${SITE_CONFIG.contactEmail} directly.`);
    } finally {
      setBusy(false);
    }
  };

  const mailtoHref = `mailto:${SITE_CONFIG.contactEmail}?subject=${encodeURIComponent(
    `InfoLinky Advertising Inquiry: ${form.companyName || form.fullName}`
  )}&body=${encodeURIComponent(
    `Full Name: ${form.fullName}\nCompany: ${form.companyName}\nEmail: ${form.businessEmail}\nWebsite: ${form.websiteUrl}\nAdvertising Type: ${form.advertisingType}\nDuration: ${form.duration}\nBudget: ${form.budget}\nMessage: ${form.message}`
  )}`;

  return (
    <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-10 space-y-10">
      <PageMeta
        title="Advertise With InfoLinky – Sponsorships & Partnerships"
        description="Partner with InfoLinky for banner advertising, sponsored articles, featured software placement, and affiliate collaborations."
      />

      <section className="bg-white border border-slate-200 rounded-2xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 items-stretch">
        <div className="lg:col-span-6 p-6 sm:p-10 flex flex-col justify-center space-y-4">
          <div className="text-xs font-semibold text-[#2563EB]">
            Media Kits &amp; Business Partnerships
          </div>
          <h1 className="font-display text-2xl sm:text-4xl font-bold text-[#101C35]">
            ADVERTISE WITH INFOLINKY
          </h1>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Reach an international audience of software buyers, creators, freelancers, and digital
            businesses. We keep placements clean, clearly labeled, and separated from tool controls.
          </p>
          <div className="text-xs text-slate-600">
            Direct Partner Desk:{' '}
            <a href={`mailto:${SITE_CONFIG.contactEmail}`} className="font-semibold text-[#2563EB]">
              {SITE_CONFIG.contactEmail}
            </a>
          </div>
        </div>
        <div className="lg:col-span-6 min-h-[240px]">
          <ResilientImage
            src={ASSETS.advertiseWithUs}
            alt="Advertise With InfoLinky Boardroom Partnership"
            className="w-full h-full object-cover"
          />
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-6 space-y-4">
          <h2 className="font-display text-lg font-bold text-[#101C35]">
            Available Advertising Services
          </h2>
          <ul className="space-y-2.5 text-sm text-slate-700">
            {AD_SERVICES.map((svc, idx) => (
              <li key={svc} className="flex items-start gap-2.5">
                <span className="font-mono text-xs text-[#2563EB] mt-0.5 tabular-nums">
                  0{idx + 1}.
                </span>
                <span>{svc}</span>
              </li>
            ))}
          </ul>
          <div className="pt-4 border-t border-slate-100 text-xs text-slate-500">
            Looking to submit a software listing instead?{' '}
            <Link to="/submit-product" className="text-[#2563EB] font-semibold underline">
              Use the Product Listing Form
            </Link>
            .
          </div>
        </div>

        <form
          onSubmit={handleSubmit}
          className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 space-y-4"
        >
          <h2 className="font-display text-xl font-bold text-[#101C35]">
            Advertising Inquiry Form
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-[#101C35] mb-1">Full Name *</label>
              <input
                type="text"
                required
                value={form.fullName}
                onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#101C35] mb-1">Company Name *</label>
              <input
                type="text"
                required
                value={form.companyName}
                onChange={(e) => setForm({ ...form, companyName: e.target.value })}
                className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#101C35] mb-1">Business Email *</label>
              <input
                type="email"
                required
                value={form.businessEmail}
                onChange={(e) => setForm({ ...form, businessEmail: e.target.value })}
                className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#101C35] mb-1">Website URL *</label>
              <input
                type="url"
                required
                placeholder="https://company.com"
                value={form.websiteUrl}
                onChange={(e) => setForm({ ...form, websiteUrl: e.target.value })}
                className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#101C35] mb-1">
                Advertising Type *
              </label>
              <select
                value={form.advertisingType}
                onChange={(e) => setForm({ ...form, advertisingType: e.target.value })}
                className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm bg-white"
              >
                {AD_SERVICES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#101C35] mb-1">
                Advertising Duration *
              </label>
              <select
                value={form.duration}
                onChange={(e) => setForm({ ...form, duration: e.target.value })}
                className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm bg-white"
              >
                {AD_DURATIONS.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#101C35] mb-1">
              Advertising Budget (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g. $250 - $1,000"
              value={form.budget}
              onChange={(e) => setForm({ ...form, budget: e.target.value })}
              className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#101C35] mb-1">Message *</label>
            <textarea
              rows={4}
              required
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
              placeholder="Describe your campaign goals, target dates, and placement preferences..."
              className="w-full p-3 rounded-lg border border-slate-200 text-sm"
            />
          </div>

          {error && (
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-800">
              {error}
            </div>
          )}

          {result && (
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 space-y-1.5 text-xs text-emerald-900">
              <div className="font-semibold">Inquiry Logged (Ref: {result.id})</div>
              <p>{result.message}</p>
              {!result.relayed && (
                <a href={mailtoHref} className="font-semibold underline text-[#101C35] inline-block">
                  Send copy via email client ({SITE_CONFIG.contactEmail})
                </a>
              )}
            </div>
          )}

          <div className="flex flex-wrap items-center justify-between gap-4 pt-1">
            <button
              type="submit"
              disabled={busy}
              className="h-11 px-6 rounded-lg bg-[#2563EB] hover:bg-[#1d4ed8] disabled:opacity-60 text-white text-sm font-semibold inline-flex items-center gap-2 cursor-pointer"
            >
              {busy && <Loader2 className="w-4 h-4 animate-spin" />}
              <span>SEND ADVERTISING REQUEST</span>
            </button>
            <a href={mailtoHref} className="text-xs text-slate-600 hover:text-[#101C35] underline">
              Direct email: {SITE_CONFIG.contactEmail}
            </a>
          </div>
        </form>
      </div>
    </div>
  );
}

export function ContactPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState<{ id: string; message: string; relayed: boolean } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setResult(null);
    setBusy(true);
    try {
      const endpoint = SITE_CONFIG.staticFormEndpoint.contact || '/api/submissions/contact';
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ name, email, subject, message }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Could not send message.');
      } else {
        setResult({
          id: data.id || 'msg_logged',
          message: data.message || 'Your message has been logged.',
          relayed: Boolean(data.relayed),
        });
      }
    } catch {
      setError(`Could not reach contact server. Please email ${SITE_CONFIG.contactEmail} directly.`);
    } finally {
      setBusy(false);
    }
  };

  const mailtoHref = `mailto:${SITE_CONFIG.contactEmail}?subject=${encodeURIComponent(
    subject || 'InfoLinky Contact Inquiry'
  )}&body=${encodeURIComponent(`From: ${name} (${email})\n\n${message}`)}`;

  return (
    <div className="max-w-[1000px] mx-auto px-4 sm:px-6 py-10 space-y-8">
      <PageMeta
        title="Contact InfoLinky – Support & Partnerships"
        description="Contact InfoLinky owner Ali Raza in Hyderabad, Pakistan for support, tool feedback, or business inquiries."
      />

      <div>
        <h1 className="font-display text-3xl sm:text-4xl font-bold text-[#101C35]">
          Contact InfoLinky
        </h1>
        <p className="text-sm sm:text-base text-slate-600 mt-2">
          Questions about a tool, software listing, or editorial feedback? Reach out directly.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
        <div className="md:col-span-5 bg-white border border-slate-200 rounded-2xl p-6 space-y-4">
          <h2 className="font-display text-lg font-bold text-[#101C35]">Owner Details</h2>
          <div className="space-y-3 text-sm text-slate-600">
            <div>
              <span className="font-semibold text-[#101C35]">Founder:</span> {SITE_CONFIG.ownerName}
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[#2563EB]" />
              <span>{SITE_CONFIG.location}</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-[#2563EB]" />
              <a href={`mailto:${SITE_CONFIG.contactEmail}`} className="text-[#2563EB] hover:underline">
                {SITE_CONFIG.contactEmail}
              </a>
            </div>
          </div>
          <div className="pt-4 border-t border-slate-100 space-y-2 text-xs text-slate-500">
            <p>For commercial inquiries, use the dedicated forms:</p>
            <div className="flex flex-col gap-1">
              <Link to="/submit-product" className="text-[#2563EB] font-semibold hover:underline">
                Submit a Product Listing
              </Link>
              <Link to="/advertise-with-us" className="text-[#2563EB] font-semibold hover:underline">
                Advertising &amp; Sponsorships
              </Link>
            </div>
          </div>
        </div>

        <form
          onSubmit={handleSubmit}
          className="md:col-span-7 bg-white border border-slate-200 rounded-2xl p-6 space-y-4"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-[#101C35] mb-1">Your Name *</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#101C35] mb-1">Email *</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-[#101C35] mb-1">Subject *</label>
            <input
              type="text"
              required
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-[#101C35] mb-1">Message *</label>
            <textarea
              rows={5}
              required
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full p-3 rounded-lg border border-slate-200 text-sm"
            />
          </div>

          {error && (
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-800">
              {error}
            </div>
          )}

          {result && (
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 space-y-1">
              <div className="font-semibold">Message Received (Ref: {result.id})</div>
              <p>{result.message}</p>
              {!result.relayed && (
                <a href={mailtoHref} className="font-semibold underline text-[#101C35] inline-block">
                  Open email draft to {SITE_CONFIG.contactEmail}
                </a>
              )}
            </div>
          )}

          <div className="flex flex-wrap items-center justify-between gap-3">
            <button
              type="submit"
              disabled={busy}
              className="h-10 px-6 rounded-lg bg-[#2563EB] hover:bg-[#1d4ed8] text-white text-sm font-semibold inline-flex items-center gap-2 cursor-pointer"
            >
              {busy && <Loader2 className="w-4 h-4 animate-spin" />}
              <span>Send Message</span>
            </button>
            <a href={mailtoHref} className="text-xs text-slate-500 hover:text-[#101C35] underline">
              Email directly
            </a>
          </div>
        </form>
      </div>
    </div>
  );
}
