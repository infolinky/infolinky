import { useState, useMemo, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Search, ExternalLink, Check, Info } from 'lucide-react';
import initialProducts from '../data/products.json';
import { ASSETS } from '../assets/assetMap';
import { ResilientImage } from '../components/ResilientImage';
import { PageMeta } from '../components/PageMeta';
import { AdPlacement } from '../components/AdPlacement';

interface MarketplaceProduct {
  id: string;
  name: string;
  company: string;
  category: string;
  description: string;
  features: string[];
  price?: string;
  specialOffer?: string;
  officialUrl: string;
  affiliateUrl?: string;
  featured?: boolean;
  sponsored?: boolean;
  brandInitials: string;
  brandColor?: string;
}

const ALL_CATEGORIES = [
  'All Categories',
  'Digital Marketing Software',
  'Online Business Services',
  'Website Hosting',
  'Graphic Design Software',
  'Educational Products',
  'AI Software',
  'Productivity Software',
  'Digital Subscriptions',
];

export function MarketplacePage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [products, setProducts] = useState<MarketplaceProduct[]>(initialProducts as MarketplaceProduct[]);
  const [query, setQuery] = useState(searchParams.get('q') || '');
  const [category, setCategory] = useState('All Categories');
  const [showOwnerGuide, setShowOwnerGuide] = useState(false);

  useEffect(() => {
    fetch('/api/products')
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (Array.isArray(data) && data.length > 0) {
          setProducts(data);
        }
      })
      .catch(() => {
        // Static build falls back to bundled products.json cleanly
      });
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return products.filter((p) => {
      const catMatch = category === 'All Categories' || p.category === category;
      if (!catMatch) return false;
      if (!q) return true;
      return (
        p.name.toLowerCase().includes(q) ||
        p.company.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q)
      );
    });
  }, [products, query, category]);

  return (
    <div className="max-w-[1280px] mx-auto px-4 sm:px-6 py-10 space-y-10">
      <PageMeta
        title="Affiliate Products Marketplace – InfoLinky"
        description="Discover vetted software, web hosting, AI tools, marketing suites, and creative subscriptions curated on InfoLinky."
      />

      {/* Marketplace Header */}
      <section className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
          <div className="lg:col-span-7 p-6 sm:p-10 flex flex-col justify-center space-y-4">
            <div className="text-xs font-semibold text-[#2563EB]">
              InfoLinky Software &amp; Digital Marketplace
            </div>
            <h1 className="font-display text-2xl sm:text-4xl font-bold text-[#101C35]">
              Curated Software, Hosting &amp; Digital Business Tools
            </h1>
            <p className="text-sm sm:text-base text-slate-600 leading-relaxed max-w-2xl">
              Explore reputable platforms used by creators, marketers, and online businesses.
              InfoLinky evaluates products from legitimate companies across any category and
              maintains transparent referral links.
            </p>
            <div className="flex flex-wrap gap-3 pt-1">
              <Link
                to="/submit-product"
                className="h-10 px-5 rounded-lg bg-[#2563EB] hover:bg-[#1d4ed8] text-white text-xs font-semibold inline-flex items-center"
              >
                List Your Product on InfoLinky
              </Link>
              <Link
                to="/software-reviews"
                className="h-10 px-5 rounded-lg border border-slate-200 text-[#101C35] text-xs font-semibold inline-flex items-center hover:bg-[#F5F7FB]"
              >
                Read Software Reviews
              </Link>
            </div>
          </div>

          <div className="lg:col-span-5 min-h-[220px] bg-slate-100">
            <ResilientImage
              src={ASSETS.affiliateMarketplace}
              alt="InfoLinky Affiliate Marketplace Showcase"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </section>

      {/* Transparent Disclosure */}
      <div className="bg-white border border-slate-200 rounded-xl px-5 py-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-xs text-slate-600">
        <div className="flex items-start gap-2.5">
          <Info className="w-4 h-4 text-[#2563EB] shrink-0 mt-0.5" aria-hidden="true" />
          <span>
            <strong className="text-[#101C35]">Affiliate Disclosure:</strong> Some outbound product
            links may use owner-configured tracking URLs that earn InfoLinky a commission at no extra
            cost to you. Where no custom tracking URL is active, buttons direct to the vendor&apos;s
            official website.
          </span>
        </div>
        <Link to="/affiliate-disclosure" className="text-[#2563EB] font-semibold hover:underline shrink-0">
          Full Disclosure
        </Link>
      </div>

      {/* Search & Category Filter */}
      <div className="space-y-4">
        <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
          <div className="relative flex-1 max-w-md">
            <Search
              className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <input
              type="search"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setSearchParams(e.target.value ? { q: e.target.value } : {});
              }}
              placeholder="Search products or companies..."
              className="w-full h-11 pl-10 pr-4 rounded-xl border border-slate-200 bg-white text-sm"
            />
          </div>

          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            aria-label="Filter marketplace by category"
            className="h-11 px-4 rounded-xl border border-slate-200 bg-white text-sm text-[#101C35]"
          >
            {ALL_CATEGORIES.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Product Grid */}
      {filtered.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center space-y-3">
          <p className="text-sm text-slate-600">No marketplace products match your current filter.</p>
          <button
            type="button"
            onClick={() => {
              setQuery('');
              setCategory('All Categories');
              setSearchParams({});
            }}
            className="px-4 py-2 rounded-lg bg-[#2563EB] text-white text-xs font-semibold cursor-pointer"
          >
            Show All Products
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((product) => {
            const customAff = product.affiliateUrl?.trim();
            const targetUrl = customAff || product.officialUrl;
            const isAff = Boolean(customAff);

            return (
              <article
                key={product.id}
                className="bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between gap-5"
              >
                <div className="space-y-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <div
                        className="w-11 h-11 rounded-xl flex items-center justify-center text-white font-display font-bold text-sm shrink-0"
                        style={{ backgroundColor: product.brandColor || '#101C35' }}
                      >
                        {product.brandInitials}
                      </div>
                      <div className="min-w-0">
                        <h2 className="font-display text-lg font-bold text-[#101C35] truncate">
                          {product.name}
                        </h2>
                        <div className="text-xs text-slate-500 truncate">
                          {product.company} · {product.category}
                        </div>
                      </div>
                    </div>
                  </div>

                  {(product.featured || product.sponsored) && (
                    <div className="text-xs font-semibold text-[#D4AF37]">
                      {product.sponsored ? 'Sponsored Placement' : 'Featured Listing'}
                    </div>
                  )}

                  <p className="text-sm text-slate-600 leading-relaxed">{product.description}</p>

                  <ul className="space-y-1.5 text-xs text-slate-700">
                    {product.features.map((feat, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <Check className="w-3.5 h-3.5 text-[#059669] shrink-0 mt-0.5" aria-hidden="true" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>

                  {(product.price || product.specialOffer) && (
                    <div className="pt-2 border-t border-slate-100 space-y-1 text-xs">
                      {product.price && (
                        <div className="font-medium text-[#101C35]">{product.price}</div>
                      )}
                      {product.specialOffer && (
                        <div className="text-[#059669]">{product.specialOffer}</div>
                      )}
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <a
                    href={targetUrl}
                    target="_blank"
                    rel={isAff ? 'noopener noreferrer sponsored' : 'noopener noreferrer'}
                    className="w-full h-10 px-4 rounded-lg bg-[#2563EB] hover:bg-[#1d4ed8] text-white text-xs font-semibold inline-flex items-center justify-center gap-2 transition-colors"
                  >
                    <span>Visit Product</span>
                    <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
                  </a>
                  <div className="text-[11px] text-slate-400 text-center">
                    {isAff ? 'Partner tracking link' : 'Official product website'}
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}

      {/* Owner Catalog Management Structure Note */}
      <section className="bg-white border border-slate-200 rounded-2xl p-6 space-y-3">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h3 className="font-display text-base font-bold text-[#101C35]">
              Owner Product Management Configuration
            </h3>
            <p className="text-xs text-slate-600">
              Designed for static GitHub Pages compatibility without insecure client-side admin logins.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setShowOwnerGuide((v) => !v)}
            className="px-3.5 py-2 rounded-lg border border-slate-200 text-xs font-semibold text-[#101C35] hover:bg-slate-50 cursor-pointer shrink-0"
          >
            {showOwnerGuide ? 'Hide Guide' : 'View Config Structure'}
          </button>
        </div>

        {showOwnerGuide && (
          <div className="pt-3 border-t border-slate-100 space-y-3 text-xs text-slate-600 leading-relaxed">
            <p>
              To add, edit, feature, sponsor, or remove any product—or to supply your custom
              affiliate tracking link—edit <code className="bg-slate-100 px-1.5 py-0.5 rounded">src/data/products.json</code> directly in your repository. Every product object supports:
            </p>
            <pre className="p-4 rounded-xl bg-[#101C35] text-slate-100 overflow-x-auto text-[11px]">
{`{
  "id": "unique-product-slug",
  "name": "Product Name",
  "company": "Legitimate Company Name",
  "category": "AI Software",
  "description": "Clear factual product overview",
  "features": ["Feature 1", "Feature 2", "Feature 3"],
  "price": "Optional pricing summary",
  "specialOffer": "Optional active promotion",
  "officialUrl": "https://example.com/",
  "affiliateUrl": "https://your-custom-affiliate-link.com/...",
  "featured": true,
  "sponsored": false,
  "brandInitials": "PN",
  "brandColor": "#2563EB"
}`}
            </pre>
          </div>
        )}
      </section>

      <AdPlacement placement="inline" />
    </div>
  );
}
