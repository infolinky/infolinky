import { Link, useSearchParams } from 'react-router-dom';
import { TOOL_CATEGORIES, TOOLS_CATALOG, type ToolCategoryId } from '../data/toolsCatalog';
import { AiToolsWorkspace } from '../tools/AiToolsWorkspace';
import { ImageToolsWorkspace } from '../tools/ImageToolsWorkspace';
import { PdfToolsWorkspace } from '../tools/PdfToolsWorkspace';
import { ProductivityToolsWorkspace } from '../tools/ProductivityToolsWorkspace';
import { BusinessToolsWorkspace } from '../tools/BusinessToolsWorkspace';
import { DesignToolsWorkspace } from '../tools/DesignToolsWorkspace';
import { ConvertersWorkspace } from '../tools/ConvertersWorkspace';
import { PageMeta } from '../components/PageMeta';
import { AdPlacement } from '../components/AdPlacement';

interface ToolCategoryPageProps {
  categoryId: ToolCategoryId;
}

export function ToolCategoryPage({ categoryId }: ToolCategoryPageProps) {
  const [searchParams, setSearchParams] = useSearchParams();
  const category = TOOL_CATEGORIES.find((c) => c.id === categoryId) || TOOL_CATEGORIES[0];
  const categoryTools = TOOLS_CATALOG.filter((t) => t.category === categoryId);

  const requestedTool = searchParams.get('tool') || '';
  const activeToolId = categoryTools.some((t) => t.id === requestedTool)
    ? requestedTool
    : categoryTools[0]?.id || '';

  const handleSelectTool = (toolId: string) => {
    setSearchParams({ tool: toolId });
  };

  return (
    <div className="max-w-[1280px] mx-auto px-4 sm:px-6 py-8 space-y-8">
      <PageMeta
        title={`${category.label} – InfoLinky`}
        description={category.description}
      />

      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 border-b border-slate-200 pb-6">
        <div>
          <div className="text-xs text-slate-500 mb-1">
            <Link to="/all-tools" className="hover:text-[#2563EB]">
              All Tools
            </Link>
            <span className="mx-1.5" aria-hidden="true">/</span>
            <span>{category.label}</span>
          </div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#101C35]">
            {category.label}
          </h1>
          <p className="text-sm text-slate-600 mt-1 max-w-2xl">{category.description}</p>
        </div>

        <div className="flex flex-wrap gap-2">
          {TOOL_CATEGORIES.map((cat) => (
            <Link
              key={cat.id}
              to={cat.route}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                cat.id === categoryId
                  ? 'bg-[#2563EB] text-white'
                  : 'bg-white border border-slate-200 text-slate-600 hover:text-[#101C35]'
              }`}
            >
              {cat.shortLabel}
            </Link>
          ))}
        </div>
      </div>

      {categoryId === 'ai-writing' && (
        <AiToolsWorkspace activeToolId={activeToolId} onSelectTool={handleSelectTool} />
      )}
      {categoryId === 'image' && (
        <ImageToolsWorkspace activeToolId={activeToolId} onSelectTool={handleSelectTool} />
      )}
      {categoryId === 'pdf' && (
        <PdfToolsWorkspace activeToolId={activeToolId} onSelectTool={handleSelectTool} />
      )}
      {categoryId === 'productivity' && (
        <ProductivityToolsWorkspace activeToolId={activeToolId} onSelectTool={handleSelectTool} />
      )}
      {categoryId === 'business' && (
        <BusinessToolsWorkspace activeToolId={activeToolId} onSelectTool={handleSelectTool} />
      )}
      {categoryId === 'design' && (
        <DesignToolsWorkspace activeToolId={activeToolId} onSelectTool={handleSelectTool} />
      )}
      {categoryId === 'converters' && (
        <ConvertersWorkspace activeToolId={activeToolId} onSelectTool={handleSelectTool} />
      )}

      <AdPlacement placement="footer" />
    </div>
  );
}
