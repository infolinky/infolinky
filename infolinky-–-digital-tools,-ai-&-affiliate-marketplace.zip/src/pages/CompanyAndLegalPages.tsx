import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { SITE_CONFIG } from '../config/siteConfig';
import { PageMeta } from '../components/PageMeta';

export function AboutPage() {
  return (
    <div className="max-w-[920px] mx-auto px-4 sm:px-6 py-10 space-y-8">
      <PageMeta
        title="About InfoLinky – Mission & Founder"
        description="Learn about InfoLinky, founded by Ali Raza in Hyderabad, Pakistan to unite practical browser tools, software reviews, and digital resources."
      />

      <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-10 space-y-5">
        <div className="text-xs font-semibold text-[#2563EB]">About InfoLinky</div>
        <h1 className="font-display text-3xl sm:text-4xl font-bold text-[#101C35]">
          One Practical Destination for Everyday Digital Work
        </h1>
        <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
          InfoLinky was created by <strong>{SITE_CONFIG.ownerName}</strong> in{' '}
          <strong>{SITE_CONFIG.location}</strong> with a straightforward goal: give international
          creators, students, freelancers, and online businesses a clean, dependable platform where
          common digital tasks can be finished without clutter or misleading downloads.
        </p>
        <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
          Alongside 51 interactive tools spanning AI writing, PDF documents, image editing,
          invoices, color systems, and unit conversions, InfoLinky curates vetted software
          platforms and publishes realistic guides on online business and ethical affiliate
          publishing.
        </p>

        <div className="pt-4 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div>
            <div className="text-slate-500">Founder &amp; Editor</div>
            <div className="font-semibold text-[#101C35] mt-0.5">{SITE_CONFIG.ownerName}</div>
          </div>
          <div>
            <div className="text-slate-500">Location</div>
            <div className="font-semibold text-[#101C35] mt-0.5">{SITE_CONFIG.location}</div>
          </div>
          <div>
            <div className="text-slate-500">Official Contact</div>
            <a
              href={`mailto:${SITE_CONFIG.contactEmail}`}
              className="font-semibold text-[#2563EB] hover:underline mt-0.5 block"
            >
              {SITE_CONFIG.contactEmail}
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

export function AffiliateDisclosurePage() {
  return (
    <div className="max-w-[920px] mx-auto px-4 sm:px-6 py-10">
      <PageMeta
        title="Affiliate Disclosure – InfoLinky"
        description="Transparent disclosure of InfoLinky's affiliate links, sponsored placements, and editorial independence."
      />
      <article className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-10 space-y-5 text-sm text-slate-700 leading-relaxed">
        <h1 className="font-display text-3xl font-bold text-[#101C35]">Affiliate Disclosure</h1>
        <p>
          InfoLinky (<strong>{SITE_CONFIG.websiteUrl}</strong>) is operated by{' '}
          {SITE_CONFIG.ownerName}. In accordance with FTC guidelines and international transparency
          best practices, please assume that outbound links to third-party software, web hosting,
          educational products, or services in our Marketplace and Reviews sections may include
          affiliate or referral tracking URLs configured by the website owner.
        </p>
        <h2 className="font-display text-lg font-bold text-[#101C35] pt-2">
          How Commissions Work
        </h2>
        <p>
          If you click an owner-configured affiliate link and sign up or purchase a product,
          InfoLinky may earn a referral commission at <strong>no additional cost to you</strong>.
          Where no affiliate partnership is configured, buttons link directly to the vendor&apos;s
          official website.
        </p>
        <h2 className="font-display text-lg font-bold text-[#101C35] pt-2">
          Editorial Independence &amp; Sponsored Listings
        </h2>
        <p>
          We never promise guaranteed earnings or fabricate performance metrics. Paid sponsorships,
          banner placements, and featured listings are reviewed manually prior to publication and are
          clearly distinguished from organic tool utilities.
        </p>
      </article>
    </div>
  );
}

export function PrivacyPolicyPage() {
  return (
    <div className="max-w-[920px] mx-auto px-4 sm:px-6 py-10">
      <PageMeta
        title="Privacy Policy – InfoLinky"
        description="Read how InfoLinky handles local browser file processing, AI writing prompts, contact submissions, and cookies."
      />
      <article className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-10 space-y-5 text-sm text-slate-700 leading-relaxed">
        <h1 className="font-display text-3xl font-bold text-[#101C35]">Privacy Policy</h1>
        <p>
          InfoLinky respects visitor privacy and minimizes data collection across all utilities and
          informational pages.
        </p>
        <h2 className="font-display text-lg font-bold text-[#101C35] pt-2">
          1. Local Browser-Based File Processing
        </h2>
        <p>
          Image editors, PDF merge/split/compress/conversion tools, QR code generation, password
          generation, calculators, and design tools run locally inside your browser. Your uploaded
          images and PDF documents are not stored on InfoLinky servers.
        </p>
        <h2 className="font-display text-lg font-bold text-[#101C35] pt-2">
          2. AI Writing Tools &amp; Form Submissions
        </h2>
        <p>
          When you invoke an AI Writing Tool, the text you enter is sent securely to InfoLinky&apos;s
          server-side API to generate a response via Google Gemini without exposing API keys in the
          browser. Do not submit sensitive personal, medical, or confidential financial credentials
          into AI prompts. Contact, Advertising, and Product Listing forms collect only the business
          details you choose to submit so {SITE_CONFIG.ownerName} ({SITE_CONFIG.contactEmail}) can
          review and reply.
        </p>
        <h2 className="font-display text-lg font-bold text-[#101C35] pt-2">
          3. Third-Party Services &amp; Advertising
        </h2>
        <p>
          Free eBook sign-ups are processed via Systeme.io ({SITE_CONFIG.ebookFunnelUrl}). Should
          Google Analytics 4 or Google AdSense be activated in the future, those services may use
          standard cookies in accordance with Google&apos;s privacy terms and your regional consent
          preferences.
        </p>
      </article>
    </div>
  );
}

export function CookiePolicyPage() {
  return (
    <div className="max-w-[920px] mx-auto px-4 sm:px-6 py-10">
      <PageMeta
        title="Cookie Policy – InfoLinky"
        description="Information about local browser storage, essential cookies, and future analytics/advertising cookies on InfoLinky."
      />
      <article className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-10 space-y-5 text-sm text-slate-700 leading-relaxed">
        <h1 className="font-display text-3xl font-bold text-[#101C35]">Cookie Policy</h1>
        <p>
          InfoLinky uses minimal browser storage to keep utilities functional—such as saving your
          draft notes locally in the Online Notepad via <code className="bg-slate-100 px-1.5 py-0.5 rounded">localStorage</code>.
        </p>
        <p>
          Advertising and analytics tags (Google AdSense and Google Analytics 4) remain disabled
          until genuine publisher IDs are configured by the owner. When active, third-party vendors
          including Google may use cookies to serve relevant ads or measure aggregate traffic. You
          may clear or block cookies at any time through your browser settings.
        </p>
      </article>
    </div>
  );
}

export function TermsPage() {
  return (
    <div className="max-w-[920px] mx-auto px-4 sm:px-6 py-10">
      <PageMeta
        title="Terms of Use – InfoLinky"
        description="Terms governing the use of InfoLinky digital tools, AI utilities, software marketplace listings, and educational content."
      />
      <article className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-10 space-y-5 text-sm text-slate-700 leading-relaxed">
        <h1 className="font-display text-3xl font-bold text-[#101C35]">Terms of Use</h1>
        <p>
          By accessing InfoLinky, you agree to use our utilities, reviews, and business forms for
          lawful purposes only.
        </p>
        <h2 className="font-display text-lg font-bold text-[#101C35] pt-2">
          No Warranties &amp; Output Verification
        </h2>
        <p>
          Browser utilities and AI-assisted writing tools are provided &ldquo;as is&rdquo;. Always
          review generated documents, invoices, translations, and AI drafts for accuracy before
          commercial or legal use.
        </p>
        <h2 className="font-display text-lg font-bold text-[#101C35] pt-2">
          Third-Party Products &amp; Educational Content
        </h2>
        <p>
          External products listed in the InfoLinky Marketplace are governed by their respective
          vendors&apos; terms and pricing. Educational guides do not constitute financial or legal
          advice and carry no guarantee of income.
        </p>
      </article>
    </div>
  );
}

export function NotFoundPage() {
  return (
    <div className="max-w-[720px] mx-auto px-4 sm:px-6 py-20 text-center space-y-5">
      <PageMeta
        title="Page Not Found (404) – InfoLinky"
        description="The requested InfoLinky page could not be found. Browse all 51 digital tools or return home."
      />
      <div className="font-mono text-sm font-semibold text-[#2563EB]">404 · Page Not Found</div>
      <h1 className="font-display text-3xl sm:text-4xl font-bold text-[#101C35]">
        We couldn&apos;t find that page.
      </h1>
      <p className="text-sm text-slate-600">
        The link may have moved or been mistyped. Explore all 51 working utilities or return to the
        InfoLinky homepage.
      </p>
      <div className="flex flex-wrap justify-center gap-3 pt-2">
        <Link
          to="/"
          className="h-10 px-5 rounded-lg bg-[#101C35] text-white text-xs font-semibold inline-flex items-center gap-2"
        >
          <span>Return Home</span>
        </Link>
        <Link
          to="/all-tools"
          className="h-10 px-5 rounded-lg bg-[#2563EB] text-white text-xs font-semibold inline-flex items-center gap-2"
        >
          <span>Browse All Tools</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>
    </div>
  );
}
