import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Search,
  ArrowRight,
  ExternalLink,
  FileText,
  Image as ImageIcon,
  Wand2,
  Briefcase,
  Palette,
  RefreshCw,
  CheckSquare,
} from 'lucide-react';
import { ASSETS } from '../assets/assetMap';
import { TOOL_CATEGORIES, TOOLS_CATALOG } from '../data/toolsCatalog';
import productsData from '../data/products.json';
import { ResilientImage } from '../components/ResilientImage';
import { AdPlacement } from '../components/AdPlacement';
import { EbookFunnelSection } from '../components/EbookFunnelSection';
import { PageMeta } from '../components/PageMeta';

const QUICK_TOOLS = [
  'ai-content-writer',
  'pdf-merge',
  'image-compressor',
  'invoice-generator',
  'qr-code-generator',
  'background-remover',
];

export function HomePage() {
  const navigate = useNavigate();
  const [heroSearch, setHeroSearch] = useState('');

  const handleHeroSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const q = heroSearch.trim();
    if (!q) {
      navigate('/all-tools');
      return;
    }
    const lower = q.toLowerCase();
    const matchedTool = TOOLS_CATALOG.find((t) => t.name.toLowerCase().includes(lower));
    if (matchedTool) {
      navigate(matchedTool.route);
      return;
    }
    const matchedProduct = productsData.find((p) => p.name.toLowerCase().includes(lower));
    if (matchedProduct) {
      navigate(`/affiliate-products?q=${encodeURIComponent(q)}`);
      return;
    }
    navigate(`/all-tools?q=${encodeURIComponent(q)}`);
  };

  const featuredProducts = productsData.filter((p) => p.featured).slice(0, 4);
  const quickToolsList = QUICK_TOOLS.map((id) => TOOLS_CATALOG.find((t) => t.id === id)).filter(
    Boolean
  );

  const categoryImageMap: Record<string, string> = {
    'ai-writing': ASSETS.aiTools,
    image: ASSETS.imageTools,
    pdf: ASSETS.businessTools,
    productivity: ASSETS.productivityTools,
    business: ASSETS.businessTools,
    design: ASSETS.imageTools,
    converters: ASSETS.aiTools,
  };

  const categoryIconMap: Record<string, typeof Wand2> = {
    'ai-writing': Wand2,
    image: ImageIcon,
    pdf: FileText,
    productivity: CheckSquare,
    business: Briefcase,
    design: Palette,
    converters: RefreshCw,
  };

  return (
    <div className="space-y-16 pb-16">
      <PageMeta
        title="InfoLinky – Digital Tools, AI Workspace & Software Marketplace"
        description="Complete everyday digital tasks in one place with InfoLinky: browser-based PDF, image, business, design, and AI writing tools, honest software reviews, and digital resources."
      />

      {/* Hero Section */}
      <section className="bg-white border-b border-slate-200">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 py-12 lg:py-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
            <div className="lg:col-span-6 flex flex-col justify-center space-y-6">
              <div className="text-xs font-semibold text-[#2563EB] tracking-wide">
                InfoLinky Digital Platform · 51 Working Utilities &amp; Software Directory
              </div>

              <h1
                className="font-display font-bold tracking-tight text-[#101C35] leading-[1.1]"
                style={{ fontSize: 'clamp(2.25rem, 4vw, 3.4rem)' }}
              >
                Everyday Digital Tools, AI Writing, and Trusted Software in One Workspace.
              </h1>

              <p className="text-base text-slate-600 leading-relaxed max-w-xl">
                Compress images, merge PDFs, generate invoices, format copy, and explore vetted
                business software without hopping across dozens of ad-heavy websites.
              </p>

              <form onSubmit={handleHeroSearch} className="flex flex-col sm:flex-row gap-2.5 max-w-xl">
                <div className="relative flex-1">
                  <Search
                    className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                    aria-hidden="true"
                  />
                  <input
                    type="search"
                    value={heroSearch}
                    onChange={(e) => setHeroSearch(e.target.value)}
                    placeholder="Find a tool or software (e.g. PDF Merge, Semrush, QR Code)..."
                    className="w-full h-12 pl-10 pr-4 rounded-xl border border-slate-300 bg-[#F5F7FB] focus:bg-white text-sm text-[#101C35] focus:outline-none focus:border-[#2563EB]"
                  />
                </div>
                <button
                  type="submit"
                  className="h-12 px-6 rounded-xl bg-[#2563EB] hover:bg-[#1d4ed8] text-white font-semibold text-sm inline-flex items-center justify-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <span>Search</span>
                  <ArrowRight className="w-4 h-4" aria-hidden="true" />
                </button>
              </form>

              <div className="flex flex-wrap items-center gap-5 pt-1 text-sm">
                <Link
                  to="/all-tools"
                  className="inline-flex items-center gap-1.5 font-semibold text-[#101C35] hover:text-[#2563EB] transition-colors"
                >
                  <span>Browse All 51 Tools</span>
                  <ArrowRight className="w-4 h-4" aria-hidden="true" />
                </Link>
                <span className="text-slate-300" aria-hidden="true">·</span>
                <Link
                  to="/affiliate-products"
                  className="font-medium text-slate-600 hover:text-[#101C35] transition-colors"
                >
                  Software Marketplace
                </Link>
                <span className="text-slate-300" aria-hidden="true">·</span>
                <Link
                  to="/submit-product"
                  className="font-medium text-slate-600 hover:text-[#101C35] transition-colors"
                >
                  List Your Product
                </Link>
              </div>
            </div>

            <div className="lg:col-span-6">
              <div className="h-full min-h-[280px] rounded-2xl overflow-hidden border border-slate-200 bg-slate-100">
                <ResilientImage
                  src={ASSETS.heroAiTech}
                  alt="InfoLinky modern international digital workspace"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Popular Direct-Launch Tools */}
      <section className="max-w-[1280px] mx-auto px-4 sm:px-6 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
          <div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#101C35]">
              01. Popular Instant Tools
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              Open any utility directly—image, PDF, business, and conversion tools run inside your browser.
            </p>
          </div>
          <Link
            to="/all-tools"
            className="text-sm font-semibold text-[#2563EB] hover:underline whitespace-nowrap shrink-0"
          >
            View all 51 tools
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {quickToolsList.map((tool) => {
            if (!tool) return null;
            return (
              <Link
                key={tool.id}
                to={tool.route}
                className="group bg-white border border-slate-200 hover:border-[#2563EB] rounded-xl p-5 flex flex-col justify-between gap-4 transition-all duration-150 hover:-translate-y-0.5"
              >
                <div>
                  <div className="text-xs text-slate-500 mb-1.5">
                    {tool.categoryLabel}
                    <span className="mx-1.5" aria-hidden="true">·</span>
                    <span>{tool.mode === 'ai-backend' ? 'Server Gemini AI' : 'Browser Local'}</span>
                  </div>
                  <h3 className="font-display text-lg font-bold text-[#101C35] group-hover:text-[#2563EB] transition-colors">
                    {tool.name}
                  </h3>
                  <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">
                    {tool.description}
                  </p>
                </div>
                <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#2563EB]">
                  <span>Open Tool</span>
                  <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Non-intrusive inline ad placement */}
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
        <AdPlacement placement="inline" />
      </div>

      {/* 7 Tool Suites Bento Showcase */}
      <section className="max-w-[1280px] mx-auto px-4 sm:px-6 space-y-6">
        <div>
          <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#101C35]">
            02. Complete Utility Suites
          </h2>
          <p className="text-sm text-slate-600 mt-1">
            Seven focused workspaces organized by workflow—no bloat, no fake buttons.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {TOOL_CATEGORIES.map((cat, idx) => {
            const count = TOOLS_CATALOG.filter((t) => t.category === cat.id).length;
            const Icon = categoryIconMap[cat.id] || Wand2;
            return (
              <Link
                key={cat.id}
                to={cat.route}
                className={`group bg-white border border-slate-200 hover:border-[#2563EB] rounded-2xl overflow-hidden flex flex-col transition-all duration-150 ${
                  idx === 0 ? 'md:col-span-2 lg:col-span-2' : ''
                }`}
              >
                <div className="h-44 overflow-hidden bg-slate-100 border-b border-slate-100">
                  <ResilientImage
                    src={categoryImageMap[cat.id] || ASSETS.aiTools}
                    alt={cat.label}
                    className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-300"
                  />
                </div>
                <div className="p-6 flex-1 flex flex-col justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2 text-xs font-medium text-slate-500 mb-2 tabular-nums">
                      <Icon className="w-4 h-4 text-[#2563EB]" aria-hidden="true" />
                      <span>{count} working tools</span>
                    </div>
                    <h3 className="font-display text-xl font-bold text-[#101C35] group-hover:text-[#2563EB] transition-colors">
                      {cat.label}
                    </h3>
                    <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">
                      {cat.description}
                    </p>
                  </div>
                  <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#101C35] group-hover:text-[#2563EB]">
                    <span>Launch {cat.shortLabel} Suite</span>
                    <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Affiliate Marketplace Preview */}
      <section className="bg-white border-y border-slate-200 py-14">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 space-y-8">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
            <div>
              <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#101C35]">
                03. Featured Software &amp; Digital Marketplace
              </h2>
              <p className="text-sm text-slate-600 mt-1 max-w-2xl">
                Curated platforms for SEO, hosting, funnels, and graphic design. Links clearly disclose
                any partner relationships—see our{' '}
                <Link to="/affiliate-disclosure" className="text-[#2563EB] underline">
                  Affiliate Disclosure
                </Link>
                .
              </p>
            </div>
            <div className="flex flex-wrap gap-3 shrink-0">
              <Link
                to="/affiliate-products"
                className="h-10 px-4 rounded-lg bg-[#101C35] text-white text-xs font-semibold inline-flex items-center gap-1.5 hover:bg-[#1b2d52]"
              >
                <span>All Marketplace Products</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
              <Link
                to="/submit-product"
                className="h-10 px-4 rounded-lg border border-slate-300 text-[#101C35] text-xs font-semibold inline-flex items-center hover:bg-[#F5F7FB]"
              >
                List Your Product
              </Link>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {featuredProducts.map((product) => {
              const targetHref = product.affiliateUrl?.trim() || product.officialUrl;
              const isAffiliate = Boolean(product.affiliateUrl?.trim());
              return (
                <article
                  key={product.id}
                  className="bg-[#F5F7FB] border border-slate-200 rounded-xl p-5 flex flex-col justify-between gap-4"
                >
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-lg flex items-center justify-center text-white font-display font-bold text-sm shrink-0"
                        style={{ backgroundColor: product.brandColor || '#101C35' }}
                      >
                        {product.brandInitials}
                      </div>
                      <div className="min-w-0">
                        <h3 className="font-display text-base font-bold text-[#101C35] truncate">
                          {product.name}
                        </h3>
                        <div className="text-xs text-slate-500 truncate">{product.category}</div>
                      </div>
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      {product.description}
                    </p>
                    <div className="text-xs font-medium text-[#101C35]">{product.price}</div>
                  </div>

                  <a
                    href={targetHref}
                    target="_blank"
                    rel={isAffiliate ? 'noopener noreferrer sponsored' : 'noopener noreferrer'}
                    className="inline-flex items-center justify-center gap-1.5 h-9 px-4 rounded-lg bg-[#2563EB] hover:bg-[#1d4ed8] text-white text-xs font-semibold transition-colors"
                  >
                    <span>Visit Product</span>
                    <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
                  </a>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      {/* Free eBook Funnel */}
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
        <EbookFunnelSection />
      </div>

      {/* Editorial & Partnership Highlights */}
      <section className="max-w-[1280px] mx-auto px-4 sm:px-6 grid grid-cols-1 md:grid-cols-3 gap-6">
        <Link
          to="/software-reviews"
          className="bg-white border border-slate-200 rounded-2xl overflow-hidden hover:border-[#2563EB] transition-colors group"
        >
          <div className="h-44 overflow-hidden">
            <ResilientImage
              src={ASSETS.softwareReviews}
              alt="Honest Software Reviews and Comparisons"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="p-6">
            <h3 className="font-display text-lg font-bold text-[#101C35] group-hover:text-[#2563EB]">
              Honest Software Reviews
            </h3>
            <p className="text-sm text-slate-600 mt-1.5">
              Balanced pros, cons, and pricing breakdowns before you commit to a SaaS subscription.
            </p>
          </div>
        </Link>

        <Link
          to="/online-earning"
          className="bg-white border border-slate-200 rounded-2xl overflow-hidden hover:border-[#2563EB] transition-colors group"
        >
          <div className="h-44 overflow-hidden">
            <ResilientImage
              src={ASSETS.onlineEarning}
              alt="Practical Digital Skills and Online Earning Guides"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="p-6">
            <h3 className="font-display text-lg font-bold text-[#101C35] group-hover:text-[#2563EB]">
              Online Earning Education
            </h3>
            <p className="text-sm text-slate-600 mt-1.5">
              Grounded guides on digital services, templates, and ethical affiliate publishing—zero hype.
            </p>
          </div>
        </Link>

        <Link
          to="/advertise-with-us"
          className="bg-white border border-slate-200 rounded-2xl overflow-hidden hover:border-[#2563EB] transition-colors group"
        >
          <div className="h-44 overflow-hidden">
            <ResilientImage
              src={ASSETS.advertiseWithUs}
              alt="Advertise and Partner With InfoLinky"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="p-6">
            <h3 className="font-display text-lg font-bold text-[#101C35] group-hover:text-[#2563EB]">
              Advertise &amp; Partner With Us
            </h3>
            <p className="text-sm text-slate-600 mt-1.5">
              Promote verified SaaS tools, developer products, and digital services to international readers.
            </p>
          </div>
        </Link>
      </section>
    </div>
  );
}
