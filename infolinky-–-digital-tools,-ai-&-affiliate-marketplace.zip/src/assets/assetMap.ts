import logoImg from './images/infolinky_logo_1794574154574.jpg';
import heroImg from './images/hero_ai_tech_1794574156141.jpg';
import ebookCoverImg from './images/ebook_cover_1794574156129.jpg';
import aiToolsImg from './images/ai_tools_1794574157198.jpg';
import imageToolsImg from './images/image_tools_1794574157533.jpg';
import productivityToolsImg from './images/productivity_tools_1794574159002.jpg';
import businessToolsImg from './images/business_tools_1794574158584.jpg';
import marketplaceImg from './images/affiliate_marketplace_1794574159291.jpg';
import onlineEarningImg from './images/online_earning_1794574160062.jpg';
import softwareReviewsImg from './images/software_reviews_1794574161137.jpg';
import advertiseImg from './images/advertise_with_us_1794574160914.jpg';

export const ASSETS = {
  logo: logoImg,
  heroAiTech: heroImg,
  ebookCover: ebookCoverImg,
  aiTools: aiToolsImg,
  imageTools: imageToolsImg,
  productivityTools: productivityToolsImg,
  businessTools: businessToolsImg,
  affiliateMarketplace: marketplaceImg,
  onlineEarning: onlineEarningImg,
  softwareReviews: softwareReviewsImg,
  advertiseWithUs: advertiseImg,
} as const;
