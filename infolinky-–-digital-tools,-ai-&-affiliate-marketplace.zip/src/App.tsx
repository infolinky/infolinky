import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { AllToolsPage } from './pages/AllToolsPage';
import { ToolCategoryPage } from './pages/ToolCategoryPage';
import { MarketplacePage } from './pages/MarketplacePage';
import {
  SubmitProductPage,
  AdvertiseWithUsPage,
  ContactPage,
} from './pages/BusinessFormsPages';
import {
  SoftwareReviewsPage,
  OnlineEarningPage,
  AffiliateMarketingPage,
  ResourcesPage,
  EbookPage,
} from './pages/EditorialPages';
import {
  AboutPage,
  AffiliateDisclosurePage,
  PrivacyPolicyPage,
  CookiePolicyPage,
  TermsPage,
  NotFoundPage,
} from './pages/CompanyAndLegalPages';

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

export default function App() {
  return (
    <BrowserRouter basename={import.meta.env.BASE_URL}>
      <ScrollToTop />
      <div className="min-h-screen flex flex-col bg-[#F5F7FB] text-[#101C35]">
        <Header />
        <main className="flex-1">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/index.html" element={<HomePage />} />

            <Route path="/all-tools" element={<AllToolsPage />} />
            <Route path="/all-tools.html" element={<AllToolsPage />} />

            <Route path="/ai-tools" element={<ToolCategoryPage categoryId="ai-writing" />} />
            <Route path="/ai-tools.html" element={<ToolCategoryPage categoryId="ai-writing" />} />

            <Route path="/image-tools" element={<ToolCategoryPage categoryId="image" />} />
            <Route path="/image-tools.html" element={<ToolCategoryPage categoryId="image" />} />

            <Route path="/pdf-tools" element={<ToolCategoryPage categoryId="pdf" />} />
            <Route path="/pdf-tools.html" element={<ToolCategoryPage categoryId="pdf" />} />

            <Route
              path="/productivity-tools"
              element={<ToolCategoryPage categoryId="productivity" />}
            />
            <Route
              path="/productivity-tools.html"
              element={<ToolCategoryPage categoryId="productivity" />}
            />

            <Route path="/business-tools" element={<ToolCategoryPage categoryId="business" />} />
            <Route
              path="/business-tools.html"
              element={<ToolCategoryPage categoryId="business" />}
            />

            <Route path="/design-tools" element={<ToolCategoryPage categoryId="design" />} />
            <Route path="/design-tools.html" element={<ToolCategoryPage categoryId="design" />} />

            <Route path="/converters" element={<ToolCategoryPage categoryId="converters" />} />
            <Route path="/converters.html" element={<ToolCategoryPage categoryId="converters" />} />

            <Route path="/affiliate-products" element={<MarketplacePage />} />
            <Route path="/affiliate-products.html" element={<MarketplacePage />} />

            <Route path="/software-reviews" element={<SoftwareReviewsPage />} />
            <Route path="/software-reviews.html" element={<SoftwareReviewsPage />} />

            <Route path="/online-earning" element={<OnlineEarningPage />} />
            <Route path="/online-earning.html" element={<OnlineEarningPage />} />

            <Route path="/affiliate-marketing" element={<AffiliateMarketingPage />} />
            <Route path="/affiliate-marketing.html" element={<AffiliateMarketingPage />} />

            <Route path="/resources" element={<ResourcesPage />} />
            <Route path="/resources.html" element={<ResourcesPage />} />

            <Route path="/ebook" element={<EbookPage />} />
            <Route path="/ebook.html" element={<EbookPage />} />

            <Route path="/advertise-with-us" element={<AdvertiseWithUsPage />} />
            <Route path="/advertise-with-us.html" element={<AdvertiseWithUsPage />} />

            <Route path="/submit-product" element={<SubmitProductPage />} />
            <Route path="/submit-product.html" element={<SubmitProductPage />} />

            <Route path="/about" element={<AboutPage />} />
            <Route path="/about.html" element={<AboutPage />} />

            <Route path="/contact" element={<ContactPage />} />
            <Route path="/contact.html" element={<ContactPage />} />

            <Route path="/affiliate-disclosure" element={<AffiliateDisclosurePage />} />
            <Route path="/affiliate-disclosure.html" element={<AffiliateDisclosurePage />} />

            <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
            <Route path="/privacy-policy.html" element={<PrivacyPolicyPage />} />

            <Route path="/cookie-policy" element={<CookiePolicyPage />} />
            <Route path="/cookie-policy.html" element={<CookiePolicyPage />} />

            <Route path="/terms" element={<TermsPage />} />
            <Route path="/terms.html" element={<TermsPage />} />

            <Route path="/404.html" element={<NotFoundPage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </BrowserRouter>
  );
}
