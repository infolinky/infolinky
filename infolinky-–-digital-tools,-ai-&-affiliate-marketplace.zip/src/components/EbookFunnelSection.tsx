import { useState } from 'react';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import { ASSETS } from '../assets/assetMap';
import { SITE_CONFIG } from '../config/siteConfig';
import { ResilientImage } from './ResilientImage';

export function EbookFunnelSection() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const funnelTargetUrl = useMemoFunnelUrl(name, email);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    setError('');
    if (!name.trim()) {
      e.preventDefault();
      setError('Please enter your first name.');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      e.preventDefault();
      setError('Please enter a valid email address.');
      return;
    }
    setSubmitted(true);
  };

  return (
    <section className="bg-[#101C35] text-white rounded-2xl overflow-hidden border border-slate-800">
      <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
        <div className="lg:col-span-5 bg-[#0B1426] p-8 sm:p-10 flex items-center justify-center">
          <div className="w-56 sm:w-64 rounded-xl overflow-hidden shadow-2xl border border-white/10">
            <ResilientImage
              src={ASSETS.ebookCover}
              alt="InfoLinky Free Digital Opportunities eBook Cover"
              className="w-full aspect-[3/4] object-cover"
            />
          </div>
        </div>

        <div className="lg:col-span-7 p-8 sm:p-12 flex flex-col justify-center">
          <p className="text-xs font-semibold tracking-wide text-[#D4AF37] mb-3">
            Free Digital Guide · Systeme.io Delivery
          </p>
          <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-white mb-4">
            Get Your Free eBook and Discover New Digital Opportunities.
          </h2>
          <p className="text-sm sm:text-base text-slate-300 leading-relaxed mb-6 max-w-xl">
            Receive our concise playbook covering practical AI workflows, reliable digital skill stacks,
            and ethical website monetization fundamentals—delivered straight through our Systeme.io reader funnel.
          </p>

          <form
            action={SITE_CONFIG.ebookFunnelUrl}
            method="GET"
            target="_blank"
            rel="noopener noreferrer"
            onSubmit={handleSubmit}
            className="space-y-3 max-w-lg"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label htmlFor="ebook-name" className="sr-only">
                  Your Name
                </label>
                <input
                  id="ebook-name"
                  name="first_name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Your name"
                  required
                  className="w-full h-11 px-4 rounded-lg bg-white/10 border border-white/20 text-white placeholder:text-slate-400 text-sm focus:outline-none focus:border-[#D4AF37]"
                />
              </div>
              <div>
                <label htmlFor="ebook-email" className="sr-only">
                  Email Address
                </label>
                <input
                  id="ebook-email"
                  name="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  required
                  className="w-full h-11 px-4 rounded-lg bg-white/10 border border-white/20 text-white placeholder:text-slate-400 text-sm focus:outline-none focus:border-[#D4AF37]"
                />
              </div>
            </div>

            {error && <p className="text-xs text-rose-300">{error}</p>}

            <div className="flex flex-col sm:flex-row sm:items-center gap-3 pt-1">
              <button
                type="submit"
                className="inline-flex items-center justify-center gap-2 h-11 px-6 rounded-lg bg-[#D4AF37] hover:bg-[#c39f2f] text-[#101C35] font-semibold text-sm transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <span>Get Free eBook</span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </button>
              <a
                href={funnelTargetUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-slate-300 hover:text-white underline underline-offset-4"
              >
                Open Systeme.io funnel page directly
              </a>
            </div>

            {submitted && (
              <div className="flex items-start gap-2 pt-2 text-xs text-emerald-300">
                <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
                <span>
                  Redirected to InfoLinky&apos;s Systeme.io funnel ({SITE_CONFIG.ebookFunnelUrl}) to complete email verification and eBook download.
                </span>
              </div>
            )}
          </form>
        </div>
      </div>
    </section>
  );
}

function useMemoFunnelUrl(name: string, email: string): string {
  const params = new URLSearchParams();
  if (name.trim()) params.set('first_name', name.trim());
  if (email.trim()) params.set('email', email.trim());
  const qs = params.toString();
  return qs ? `${SITE_CONFIG.ebookFunnelUrl}?${qs}` : SITE_CONFIG.ebookFunnelUrl;
}
