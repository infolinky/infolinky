import { useState, useMemo, useRef, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Search, Menu, X, ArrowRight } from 'lucide-react';
import { ASSETS } from '../assets/assetMap';
import { TOOLS_CATALOG } from '../data/toolsCatalog';
import productsData from '../data/products.json';

interface NavItem {
  label: string;
  to: string;
}

const NAV_ITEMS: NavItem[] = [
  { label: 'Home', to: '/' },
  { label: 'All Tools', to: '/all-tools' },
  { label: 'AI Tools', to: '/ai-tools' },
  { label: 'Affiliate Products', to: '/affiliate-products' },
  { label: 'Online Earning', to: '/online-earning' },
  { label: 'Software Reviews', to: '/software-reviews' },
  { label: 'Resources', to: '/resources' },
  { label: 'Free eBook', to: '/ebook' },
  { label: 'Advertise With Us', to: '/advertise-with-us' },
  { label: 'Contact', to: '/contact' },
];

export function Header() {
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [searchFocused, setSearchFocused] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setMobileOpen(false);
    setSearchFocused(false);
  }, [location.pathname, location.search]);

  useEffect(() => {
    function handleOutsideClick(e: MouseEvent) {
      if (
        searchContainerRef.current &&
        !searchContainerRef.current.contains(e.target as Node)
      ) {
        setSearchFocused(false);
      }
    }
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  const searchResults = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return { tools: [], products: [] };
    const tools = TOOLS_CATALOG.filter(
      (t) =>
        t.name.toLowerCase().includes(q) ||
        t.categoryLabel.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q)
    ).slice(0, 5);
    const products = productsData
      .filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.company.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q)
      )
      .slice(0, 4);
    return { tools, products };
  }, [query]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchResults.tools.length > 0) {
      navigate(searchResults.tools[0].route);
      setQuery('');
      setSearchFocused(false);
    } else if (searchResults.products.length > 0) {
      navigate(`/affiliate-products?q=${encodeURIComponent(query.trim())}`);
      setQuery('');
      setSearchFocused(false);
    } else if (query.trim()) {
      navigate(`/all-tools?q=${encodeURIComponent(query.trim())}`);
      setSearchFocused(false);
    }
  };

  const isActive = (to: string) => {
    if (to === '/') return location.pathname === '/' || location.pathname === '/index.html';
    return location.pathname === to || location.pathname === `${to}.html`;
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b border-slate-200">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        {/* Brand Zone */}
        <Link
          to="/"
          className="flex items-center gap-2.5 whitespace-nowrap shrink-0 group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB] rounded-lg"
        >
          <img
            src={ASSETS.logo}
            alt="InfoLinky emblem"
            className="w-8 h-8 rounded-lg object-cover border border-slate-200"
          />
          <span className="font-display text-lg font-bold tracking-tight text-[#101C35]">
            InfoLinky
          </span>
        </Link>

        {/* Desktop Navigation */}
        <nav
          aria-label="Main navigation"
          className="hidden xl:flex items-center gap-2.5 2xl:gap-4 text-xs 2xl:text-[13px] font-medium text-slate-600 min-w-0"
        >
          {NAV_ITEMS.map((item) => {
            const active = isActive(item.to);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors duration-150 ${
                  active
                    ? 'text-[#2563EB] border-[#2563EB] font-semibold'
                    : 'border-transparent hover:text-[#101C35] hover:border-slate-300'
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>

        {/* Prominent Search + Mobile Toggle */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div ref={searchContainerRef} className="relative hidden sm:block w-52 md:w-60 xl:w-40 2xl:w-52">
            <form onSubmit={handleSearchSubmit} role="search">
              <label htmlFor="header-search" className="sr-only">
                Search tools and products
              </label>
              <Search
                className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <input
                id="header-search"
                type="search"
                value={query}
                onFocus={() => setSearchFocused(true)}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setSearchFocused(true);
                }}
                placeholder="Search tools & products"
                className="w-full h-9 pl-9 pr-3 text-xs bg-[#F5F7FB] border border-slate-200 rounded-lg text-[#101C35] placeholder:text-slate-400 focus:outline-none focus:bg-white focus:border-[#2563EB] transition-colors"
              />
            </form>

            {searchFocused && query.trim().length > 0 && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white border border-slate-200 rounded-xl shadow-xl overflow-hidden z-50">
                {searchResults.tools.length === 0 && searchResults.products.length === 0 ? (
                  <div className="p-4 text-xs text-slate-500">
                    No matching tools or products found for &ldquo;{query}&rdquo;.
                  </div>
                ) : (
                  <div className="divide-y divide-slate-100 max-h-96 overflow-y-auto">
                    {searchResults.tools.length > 0 && (
                      <div className="p-2">
                        <div className="px-2 py-1 text-[11px] font-semibold text-slate-400">
                          Digital Tools
                        </div>
                        {searchResults.tools.map((tool) => (
                          <Link
                            key={tool.id}
                            to={tool.route}
                            className="flex items-center justify-between px-2.5 py-2 rounded-lg hover:bg-[#F5F7FB] transition-colors"
                          >
                            <div>
                              <div className="text-xs font-semibold text-[#101C35]">
                                {tool.name}
                              </div>
                              <div className="text-[11px] text-slate-500">
                                {tool.categoryLabel}
                              </div>
                            </div>
                            <ArrowRight className="w-3.5 h-3.5 text-slate-400" aria-hidden="true" />
                          </Link>
                        ))}
                      </div>
                    )}
                    {searchResults.products.length > 0 && (
                      <div className="p-2">
                        <div className="px-2 py-1 text-[11px] font-semibold text-slate-400">
                          Marketplace Products
                        </div>
                        {searchResults.products.map((product) => (
                          <Link
                            key={product.id}
                            to={`/affiliate-products?q=${encodeURIComponent(product.name)}`}
                            className="flex items-center justify-between px-2.5 py-2 rounded-lg hover:bg-[#F5F7FB] transition-colors"
                          >
                            <div>
                              <div className="text-xs font-semibold text-[#101C35]">
                                {product.name}
                              </div>
                              <div className="text-[11px] text-slate-500">
                                {product.company} · {product.category}
                              </div>
                            </div>
                            <ArrowRight className="w-3.5 h-3.5 text-slate-400" aria-hidden="true" />
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={mobileOpen}
            className="xl:hidden inline-flex items-center justify-center w-10 h-10 rounded-lg border border-slate-200 text-[#101C35] hover:bg-slate-50 transition-colors"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Responsive Mobile & Tablet Navigation Drawer */}
      {mobileOpen && (
        <div className="xl:hidden border-t border-slate-200 bg-white px-4 py-4 space-y-4 max-h-[82vh] overflow-y-auto">
          <form onSubmit={handleSearchSubmit} className="sm:hidden relative">
            <Search
              className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search 51 tools & software products..."
              className="w-full h-11 pl-9 pr-3 text-sm bg-[#F5F7FB] border border-slate-200 rounded-lg text-[#101C35]"
            />
          </form>

          <nav aria-label="Mobile navigation" className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
            {NAV_ITEMS.map((item) => {
              const active = isActive(item.to);
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={`px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                    active
                      ? 'bg-[#2563EB] text-white'
                      : 'text-[#101C35] hover:bg-[#F5F7FB]'
                  }`}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="pt-2 border-t border-slate-100 flex flex-wrap gap-3 text-xs">
            <Link to="/submit-product" className="font-semibold text-[#2563EB] hover:underline">
              List Your Product
            </Link>
            <span className="text-slate-300" aria-hidden="true">·</span>
            <Link to="/image-tools" className="text-slate-600 hover:text-[#101C35]">
              Image Tools
            </Link>
            <span className="text-slate-300" aria-hidden="true">·</span>
            <Link to="/pdf-tools" className="text-slate-600 hover:text-[#101C35]">
              PDF Tools
            </Link>
            <span className="text-slate-300" aria-hidden="true">·</span>
            <Link to="/business-tools" className="text-slate-600 hover:text-[#101C35]">
              Business Tools
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
