import { Link } from 'react-router-dom';
import { SITE_CONFIG } from '../config/siteConfig';

export type AdPlacementType = 'header' | 'inline' | 'article' | 'sidebar' | 'footer';

interface AdPlacementProps {
  placement: AdPlacementType;
  className?: string;
}

export function AdPlacement({ placement, className = '' }: AdPlacementProps) {
  const slotId = SITE_CONFIG.adsense.slots[placement];
  const isLive = Boolean(
    SITE_CONFIG.adsense.enabled && SITE_CONFIG.adsense.publisherId && slotId
  );

  if (isLive) {
    return (
      <aside
        aria-label="Advertisement"
        className={`border border-slate-200 bg-white rounded-xl p-4 text-center ${className}`}
      >
        <div className="text-[11px] text-slate-400 mb-2">Advertisement</div>
        <ins
          className="adsbygoogle block"
          data-ad-client={SITE_CONFIG.adsense.publisherId}
          data-ad-slot={slotId}
          data-ad-format="auto"
          data-full-width-responsive="true"
        />
      </aside>
    );
  }

  // Dormant placeholder visually separate from interactive tools & marketplace cards
  return (
    <aside
      aria-label="Sponsorship and advertising placement"
      className={`border border-dashed border-slate-300/90 bg-slate-50/80 rounded-xl px-5 py-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 ${className}`}
    >
      <div className="text-xs text-slate-600 leading-relaxed">
        <span className="font-semibold text-[#101C35]">Advertisement Placement ({placement})</span>
        <span className="mx-2 text-slate-300" aria-hidden="true">·</span>
        <span>
          Reserved for Google AdSense or verified brand sponsors once publisher approval is active.
        </span>
      </div>
      <Link
        to="/advertise-with-us"
        className="text-xs font-semibold text-[#2563EB] hover:underline whitespace-nowrap shrink-0"
      >
        Sponsor this space
      </Link>
    </aside>
  );
}
