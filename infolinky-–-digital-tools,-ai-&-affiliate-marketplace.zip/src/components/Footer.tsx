import { Link } from 'react-router-dom';
import { Mail, MapPin } from 'lucide-react';
import { ASSETS } from '../assets/assetMap';
import { SITE_CONFIG } from '../config/siteConfig';

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="bg-[#101C35] text-slate-300 border-t border-slate-800">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand Summary */}
          <div className="lg:col-span-2 space-y-4">
            <Link to="/" className="inline-flex items-center gap-2.5">
              <img
                src={ASSETS.logo}
                alt="InfoLinky logo"
                className="w-8 h-8 rounded-lg object-cover border border-white/15"
              />
              <span className="font-display text-lg font-bold text-white tracking-tight">
                InfoLinky
              </span>
            </Link>
            <p className="text-sm text-slate-300/90 leading-relaxed max-w-md">
              An international digital utility and software discovery platform built to help creators,
              students, and businesses complete everyday tasks in one workspace.
            </p>
            <div className="space-y-2 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#D4AF37]" aria-hidden="true" />
                <span>Operated by {SITE_CONFIG.ownerName} · {SITE_CONFIG.location}</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-[#D4AF37]" aria-hidden="true" />
                <a
                  href={`mailto:${SITE_CONFIG.contactEmail}`}
                  className="hover:text-white transition-colors"
                >
                  {SITE_CONFIG.contactEmail}
                </a>
              </div>
            </div>
          </div>

          {/* Column 1: Digital Tools */}
          <div>
            <h3 className="font-display text-sm font-semibold text-white mb-4">Digital Tools</h3>
            <ul className="space-y-2.5 text-sm">
              <li><Link to="/all-tools" className="hover:text-white transition-colors">All 51 Tools</Link></li>
              <li><Link to="/ai-tools" className="hover:text-white transition-colors">AI Writing Tools</Link></li>
              <li><Link to="/image-tools" className="hover:text-white transition-colors">Image Tools</Link></li>
              <li><Link to="/pdf-tools" className="hover:text-white transition-colors">PDF Tools</Link></li>
              <li><Link to="/productivity-tools" className="hover:text-white transition-colors">Productivity Tools</Link></li>
              <li><Link to="/business-tools" className="hover:text-white transition-colors">Business Tools</Link></li>
              <li><Link to="/design-tools" className="hover:text-white transition-colors">Design Tools</Link></li>
              <li><Link to="/converters" className="hover:text-white transition-colors">Unit Converters</Link></li>
            </ul>
          </div>

          {/* Column 2: Marketplace & Partnerships */}
          <div>
            <h3 className="font-display text-sm font-semibold text-white mb-4">Marketplace</h3>
            <ul className="space-y-2.5 text-sm">
              <li><Link to="/affiliate-products" className="hover:text-white transition-colors">Affiliate Products</Link></li>
              <li><Link to="/software-reviews" className="hover:text-white transition-colors">Software Reviews</Link></li>
              <li><Link to="/submit-product" className="hover:text-white transition-colors">List Your Product</Link></li>
              <li><Link to="/advertise-with-us" className="hover:text-white transition-colors">Advertise With Us</Link></li>
              <li><Link to="/ebook" className="hover:text-white transition-colors">Free eBook</Link></li>
            </ul>
          </div>

          {/* Column 3: Education & Policies */}
          <div>
            <h3 className="font-display text-sm font-semibold text-white mb-4">Guides &amp; Legal</h3>
            <ul className="space-y-2.5 text-sm">
              <li><Link to="/online-earning" className="hover:text-white transition-colors">Online Earning</Link></li>
              <li><Link to="/affiliate-marketing" className="hover:text-white transition-colors">Affiliate Marketing</Link></li>
              <li><Link to="/resources" className="hover:text-white transition-colors">Resources</Link></li>
              <li><Link to="/about" className="hover:text-white transition-colors">About InfoLinky</Link></li>
              <li><Link to="/contact" className="hover:text-white transition-colors">Contact</Link></li>
              <li><Link to="/affiliate-disclosure" className="hover:text-white transition-colors">Affiliate Disclosure</Link></li>
              <li><Link to="/privacy-policy" className="hover:text-white transition-colors">Privacy Policy</Link></li>
              <li><Link to="/cookie-policy" className="hover:text-white transition-colors">Cookie Policy</Link></li>
              <li><Link to="/terms" className="hover:text-white transition-colors">Terms of Use</Link></li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-white/10 flex flex-col md:flex-row md:items-center md:justify-between gap-4 text-xs text-slate-400">
          <p>
            © {year} InfoLinky. Built for global productivity and transparent software discovery.
          </p>
          <p className="max-w-xl leading-relaxed">
            Disclosure: InfoLinky may earn referral commissions when you sign up through partner links
            at no extra cost to you. See our{' '}
            <Link to="/affiliate-disclosure" className="text-slate-200 underline hover:text-white">
              Affiliate Disclosure
            </Link>
            .
          </p>
        </div>
      </div>
    </footer>
  );
}
