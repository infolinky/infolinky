export const SITE_CONFIG = {
  brandName: 'InfoLinky',
  ownerName: 'Ali Raza',
  location: 'Hyderabad, Pakistan',
  websiteUrl: 'https://infolinky.github.io/infolinky/',
  contactEmail: 'aliraza.kgm@gmail.com',
  ebookFunnelUrl: 'https://infolinky.systeme.io/',

  // Monetization & Analytics Placeholders
  // Leave empty until genuine publisher/measurement IDs are issued after approval.
  adsense: {
    enabled: false,
    publisherId: '', // e.g. 'ca-pub-xxxxxxxxxxxxxxxx'
    slots: {
      header: '',
      inline: '',
      article: '',
      sidebar: '',
      footer: '',
    },
  },
  analytics: {
    ga4MeasurementId: '', // e.g. 'G-XXXXXXXXXX'
    searchConsoleVerification: '', // Meta content token from Google Search Console
  },

  // Optional static form service endpoint (for GitHub Pages static deployment)
  // Leave blank when using InfoLinky's Express backend (/api/submissions/*).
  staticFormEndpoint: {
    productListing: '', // e.g. 'https://formspree.io/f/your-id'
    advertising: '',
    contact: '',
  },
} as const;
