import { useState, useEffect, useRef } from 'react';
import { Copy, Check, Download, RefreshCw, Play, Square, Mic, MicOff } from 'lucide-react';
import QRCode from 'qrcode';
import { TOOLS_CATALOG } from '../data/toolsCatalog';

const PRODUCTIVITY_TOOLS = TOOLS_CATALOG.filter((t) => t.category === 'productivity');

interface ProductivityToolsWorkspaceProps {
  activeToolId: string;
  onSelectTool: (id: string) => void;
}

export function ProductivityToolsWorkspace({
  activeToolId,
  onSelectTool,
}: ProductivityToolsWorkspaceProps) {
  const currentTool =
    PRODUCTIVITY_TOOLS.find((t) => t.id === activeToolId) || PRODUCTIVITY_TOOLS[0];

  // Shared text input for counter/formatter/speech
  const [text, setText] = useState('');
  const [copied, setCopied] = useState(false);

  // QR Code state
  const [qrInput, setQrInput] = useState('https://infolinky.github.io/infolinky/');
  const [qrColor, setQrColor] = useState('#101C35');
  const [qrBg, setQrBg] = useState('#FFFFFF');
  const [qrPngUrl, setQrPngUrl] = useState('');
  const [qrSvg, setQrSvg] = useState('');

  // Password state
  const [pwLength, setPwLength] = useState(16);
  const [useUpper, setUseUpper] = useState(true);
  const [useLower, setUseLower] = useState(true);
  const [useNumbers, setUseNumbers] = useState(true);
  const [useSymbols, setUseSymbols] = useState(true);
  const [password, setPassword] = useState('');

  // Notepad state
  const [noteContent, setNoteContent] = useState(() => {
    try {
      return localStorage.getItem('infolinky_notepad_v1') || '';
    } catch {
      return '';
    }
  });
  const [noteSavedAt, setNoteSavedAt] = useState('');

  // TTS state
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoice, setSelectedVoice] = useState('');
  const [speechRate, setSpeechRate] = useState(1);
  const [speechPitch, setSpeechPitch] = useState(1);
  const [speaking, setSpeaking] = useState(false);

  // STT state
  const [listening, setListening] = useState(false);
  const [sttError, setSttError] = useState('');
  const [sttLang, setSttLang] = useState('en-US');
  const recognitionRef = useRef<{ stop: () => void } | null>(null);

  useEffect(() => {
    if (currentTool.id === 'qr-code-generator') {
      const value = qrInput.trim() || 'https://infolinky.github.io/infolinky/';
      QRCode.toDataURL(value, {
        width: 360,
        margin: 2,
        color: { dark: qrColor, light: qrBg },
      })
        .then(setQrPngUrl)
        .catch(() => setQrPngUrl(''));
      QRCode.toString(value, {
        type: 'svg',
        margin: 2,
        color: { dark: qrColor, light: qrBg },
      })
        .then(setQrSvg)
        .catch(() => setQrSvg(''));
    }
  }, [currentTool.id, qrInput, qrColor, qrBg]);

  useEffect(() => {
    if (currentTool.id === 'password-generator' && !password) {
      generatePassword();
    }
  }, [currentTool.id]);

  useEffect(() => {
    if (currentTool.id === 'online-notepad') {
      try {
        localStorage.setItem('infolinky_notepad_v1', noteContent);
        setNoteSavedAt(new Date().toLocaleTimeString());
      } catch {
        // Ignore storage quota errors
      }
    }
  }, [noteContent, currentTool.id]);

  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      const loadVoices = () => {
        const list = window.speechSynthesis.getVoices();
        setVoices(list);
        if (list.length > 0 && !selectedVoice) {
          setSelectedVoice(list[0].name);
        }
      };
      loadVoices();
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }
  }, []);

  const generatePassword = () => {
    let charset = '';
    if (useUpper) charset += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    if (useLower) charset += 'abcdefghijklmnopqrstuvwxyz';
    if (useNumbers) charset += '0123456789';
    if (useSymbols) charset += '!@#$%^&*()-_=+[]{}|;:,.<>?';
    if (!charset) charset = 'abcdefghijklmnopqrstuvwxyz0123456789';

    const array = new Uint32Array(pwLength);
    window.crypto.getRandomValues(array);
    let result = '';
    for (let i = 0; i < pwLength; i++) {
      result += charset[array[i] % charset.length];
    }
    setPassword(result);
  };

  const copyString = async (val: string) => {
    if (!val) return;
    await navigator.clipboard.writeText(val);
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  };

  const downloadTextFile = (content: string, filename: string) => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Word & character metrics
  const trimmed = text.trim();
  const words = trimmed ? trimmed.split(/\s+/).length : 0;
  const charsWithSpaces = text.length;
  const charsWithoutSpaces = text.replace(/\s/g, '').length;
  const sentences = trimmed ? trimmed.split(/[.!?]+/).filter((s) => s.trim().length > 0).length : 0;
  const paragraphs = trimmed ? trimmed.split(/\n\s*\n/).filter((p) => p.trim().length > 0).length : 0;
  const byteSize = new TextEncoder().encode(text).length;
  const readingMinutes = Math.max(1, Math.ceil(words / 220));

  const topKeywords = (() => {
    if (!trimmed) return [];
    const freq: Record<string, number> = {};
    const tokens = trimmed.toLowerCase().match(/[a-z0-9]{3,}/g) || [];
    for (const tok of tokens) {
      freq[tok] = (freq[tok] || 0) + 1;
    }
    return Object.entries(freq)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 6);
  })();

  const applyFormat = (mode: string) => {
    if (mode === 'upper') setText(text.toUpperCase());
    else if (mode === 'lower') setText(text.toLowerCase());
    else if (mode === 'title') {
      setText(
        text.replace(/\w\S*/g, (w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
      );
    } else if (mode === 'sentence') {
      setText(
        text
          .toLowerCase()
          .replace(/(^\s*\w|[.!?]\s+\w)/g, (c) => c.toUpperCase())
      );
    } else if (mode === 'trim') {
      setText(text.replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim());
    } else if (mode === 'dedupe') {
      const seen = new Set<string>();
      setText(
        text
          .split('\n')
          .filter((line) => {
            if (seen.has(line)) return false;
            seen.add(line);
            return true;
          })
          .join('\n')
      );
    } else if (mode === 'sort') {
      setText(text.split('\n').sort((a, b) => a.localeCompare(b)).join('\n'));
    } else if (mode === 'slug') {
      setText(
        text
          .toLowerCase()
          .trim()
          .replace(/[^a-z0-9\s-]/g, '')
          .replace(/\s+/g, '-')
          .replace(/-+/g, '-')
      );
    }
  };

  const handleSpeak = () => {
    if (!('speechSynthesis' in window) || !text.trim()) return;
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    const v = voices.find((item) => item.name === selectedVoice);
    if (v) utter.voice = v;
    utter.rate = speechRate;
    utter.pitch = speechPitch;
    utter.onstart = () => setSpeaking(true);
    utter.onend = () => setSpeaking(false);
    utter.onerror = () => setSpeaking(false);
    window.speechSynthesis.speak(utter);
  };

  const handleStopSpeak = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setSpeaking(false);
    }
  };

  const toggleSpeechToText = () => {
    setSttError('');
    if (listening && recognitionRef.current) {
      recognitionRef.current.stop();
      setListening(false);
      return;
    }

    const SpeechRecognitionCtor =
      (window as unknown as Record<string, unknown>).SpeechRecognition ||
      (window as unknown as Record<string, unknown>).webkitSpeechRecognition;

    if (!SpeechRecognitionCtor || typeof SpeechRecognitionCtor !== 'function') {
      setSttError(
        'Browser speech recognition is not supported in this browser. Try Chrome, Edge, or Safari with microphone permissions enabled.'
      );
      return;
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const rec = new (SpeechRecognitionCtor as any)();
    rec.continuous = true;
    rec.interimResults = false;
    rec.lang = sttLang;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    rec.onresult = (event: any) => {
      let appended = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        if (event.results[i].isFinal) {
          appended += event.results[i][0].transcript + ' ';
        }
      }
      if (appended) {
        setText((prev) => (prev ? `${prev.trimEnd()} ${appended}` : appended));
      }
    };
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    rec.onerror = (event: any) => {
      setSttError(`Microphone recognition stopped (${event.error || 'permission required'}).`);
      setListening(false);
    };
    rec.onend = () => setListening(false);
    recognitionRef.current = rec;
    rec.start();
    setListening(true);
  };

  const poolSize =
    (useUpper ? 26 : 0) + (useLower ? 26 : 0) + (useNumbers ? 10 : 0) + (useSymbols ? 26 : 0) || 36;
  const entropyBits = Math.round(pwLength * Math.log2(poolSize));

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      <div className="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-3">
        <div className="px-3 py-2 text-xs font-semibold text-slate-500">
          Productivity Suite (8 Tools)
        </div>
        <div className="space-y-1">
          {PRODUCTIVITY_TOOLS.map((tool) => (
            <button
              key={tool.id}
              type="button"
              onClick={() => onSelectTool(tool.id)}
              className={`w-full text-left px-3 py-2.5 rounded-lg text-sm transition-colors cursor-pointer ${
                tool.id === currentTool.id
                  ? 'bg-[#101C35] text-white font-semibold'
                  : 'text-slate-700 hover:bg-[#F5F7FB]'
              }`}
            >
              {tool.name}
            </button>
          ))}
        </div>
      </div>

      <div className="lg:col-span-8 bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-6">
        <div className="border-b border-slate-100 pb-4">
          <div className="text-xs font-medium text-[#059669] mb-1">
            Instant Browser Utility
          </div>
          <h2 className="font-display text-xl sm:text-2xl font-bold text-[#101C35]">
            {currentTool.name}
          </h2>
          <p className="text-sm text-slate-600 mt-1">{currentTool.description}</p>
        </div>

        {(currentTool.id === 'word-counter' || currentTool.id === 'character-counter') && (
          <div className="space-y-5">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3.5 rounded-xl bg-[#F5F7FB] border border-slate-200">
                <div className="text-xs text-slate-500">Words</div>
                <div className="text-2xl font-bold text-[#101C35] tabular-nums">{words}</div>
              </div>
              <div className="p-3.5 rounded-xl bg-[#F5F7FB] border border-slate-200">
                <div className="text-xs text-slate-500">Characters</div>
                <div className="text-2xl font-bold text-[#101C35] tabular-nums">{charsWithSpaces}</div>
              </div>
              <div className="p-3.5 rounded-xl bg-[#F5F7FB] border border-slate-200">
                <div className="text-xs text-slate-500">No Spaces</div>
                <div className="text-2xl font-bold text-[#101C35] tabular-nums">{charsWithoutSpaces}</div>
              </div>
              <div className="p-3.5 rounded-xl bg-[#F5F7FB] border border-slate-200">
                <div className="text-xs text-slate-500">
                  {currentTool.id === 'character-counter' ? 'UTF-8 Bytes' : 'Read Time'}
                </div>
                <div className="text-2xl font-bold text-[#101C35] tabular-nums">
                  {currentTool.id === 'character-counter' ? byteSize : `${words ? readingMinutes : 0} min`}
                </div>
              </div>
            </div>

            <textarea
              rows={8}
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Paste or type your text here to inspect live metrics..."
              className="w-full p-4 rounded-xl border border-slate-200 bg-[#F5F7FB] focus:bg-white text-sm text-[#101C35] focus:outline-none focus:border-[#2563EB]"
            />

            <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600 tabular-nums">
              <span>Sentences: {sentences} · Paragraphs: {paragraphs}</span>
              <span>Meta Title (60): {charsWithSpaces}/60 · Meta Description (160): {charsWithSpaces}/160</span>
            </div>

            {topKeywords.length > 0 && (
              <div className="pt-2 border-t border-slate-100">
                <div className="text-xs font-semibold text-slate-500 mb-2">
                  Top Repeated Terms
                </div>
                <div className="flex flex-wrap gap-3 text-xs text-slate-700 tabular-nums">
                  {topKeywords.map(([word, count]) => (
                    <span key={word}>
                      <strong>{word}</strong> ({count})
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {currentTool.id === 'text-formatter' && (
          <div className="space-y-4">
            <div className="flex flex-wrap gap-2">
              {[
                ['upper', 'UPPERCASE'],
                ['lower', 'lowercase'],
                ['title', 'Title Case'],
                ['sentence', 'Sentence case'],
                ['trim', 'Clean Whitespace'],
                ['dedupe', 'Remove Duplicate Lines'],
                ['sort', 'Sort A–Z'],
                ['slug', 'URL Slug'],
              ].map(([key, label]) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => applyFormat(key)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 bg-[#F5F7FB] hover:bg-slate-200/70 text-xs font-semibold text-[#101C35] cursor-pointer"
                >
                  {label}
                </button>
              ))}
            </div>
            <textarea
              rows={9}
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Enter text to format..."
              className="w-full p-4 rounded-xl border border-slate-200 bg-[#F5F7FB] focus:bg-white text-sm text-[#101C35] focus:outline-none focus:border-[#2563EB]"
            />
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => copyString(text)}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#2563EB] text-white text-xs font-semibold hover:bg-[#1d4ed8] cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy Text'}</span>
              </button>
              <button
                type="button"
                onClick={() => downloadTextFile(text, 'formatted-text.txt')}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-slate-200 text-xs font-semibold text-[#101C35] hover:bg-slate-50 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download .txt</span>
              </button>
            </div>
          </div>
        )}

        {currentTool.id === 'qr-code-generator' && (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
            <div className="md:col-span-7 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">
                  URL or Text Content
                </label>
                <textarea
                  rows={4}
                  value={qrInput}
                  onChange={(e) => setQrInput(e.target.value)}
                  placeholder="https://example.com or plain text"
                  className="w-full p-3 rounded-lg border border-slate-200 text-sm"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">
                    Foreground Color
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={qrColor}
                      onChange={(e) => setQrColor(e.target.value)}
                      className="h-9 w-12 rounded border border-slate-200 cursor-pointer"
                    />
                    <span className="text-xs font-mono text-slate-600">{qrColor}</span>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">
                    Background Color
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={qrBg}
                      onChange={(e) => setQrBg(e.target.value)}
                      className="h-9 w-12 rounded border border-slate-200 cursor-pointer"
                    />
                    <span className="text-xs font-mono text-slate-600">{qrBg}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="md:col-span-5 flex flex-col items-center p-5 rounded-xl border border-slate-200 bg-[#F5F7FB] space-y-4">
              {qrPngUrl && (
                <img
                  src={qrPngUrl}
                  alt="Generated QR code"
                  className="w-48 h-48 rounded-lg border border-slate-200 bg-white"
                />
              )}
              <div className="flex flex-wrap justify-center gap-2">
                {qrPngUrl && (
                  <a
                    href={qrPngUrl}
                    download="infolinky-qrcode.png"
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#2563EB] text-white text-xs font-semibold hover:bg-[#1d4ed8]"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>PNG</span>
                  </a>
                )}
                {qrSvg && (
                  <button
                    type="button"
                    onClick={() => {
                      const blob = new Blob([qrSvg], { type: 'image/svg+xml' });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement('a');
                      a.href = url;
                      a.download = 'infolinky-qrcode.svg';
                      a.click();
                      URL.revokeObjectURL(url);
                    }}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#101C35] text-white text-xs font-semibold hover:bg-[#1b2d52] cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>SVG</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {currentTool.id === 'password-generator' && (
          <div className="space-y-5">
            <div className="p-4 rounded-xl bg-[#101C35] text-white flex items-center justify-between gap-3">
              <span className="font-mono text-base sm:text-lg break-all">{password}</span>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={generatePassword}
                  aria-label="Regenerate password"
                  className="p-2 rounded-lg bg-white/10 hover:bg-white/20 cursor-pointer"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => copyString(password)}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#2563EB] hover:bg-[#1d4ed8] text-xs font-semibold cursor-pointer"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>

            <div className="text-xs text-slate-600 tabular-nums">
              Estimated entropy: <strong className="text-[#059669]">{entropyBits} bits</strong> (Generated locally via <code>crypto.getRandomValues</code>)
            </div>

            <div>
              <div className="flex justify-between text-xs font-medium text-slate-700 mb-1">
                <span>Length</span>
                <span className="tabular-nums">{pwLength} characters</span>
              </div>
              <input
                type="range"
                min={8}
                max={64}
                value={pwLength}
                onChange={(e) => setPwLength(Number(e.target.value))}
                className="w-full accent-[#2563EB]"
              />
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-medium text-slate-700">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={useUpper} onChange={(e) => setUseUpper(e.target.checked)} />
                Uppercase (A–Z)
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={useLower} onChange={(e) => setUseLower(e.target.checked)} />
                Lowercase (a–z)
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={useNumbers} onChange={(e) => setUseNumbers(e.target.checked)} />
                Numbers (0–9)
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={useSymbols} onChange={(e) => setUseSymbols(e.target.checked)} />
                Symbols (!@#$)
              </label>
            </div>
          </div>
        )}

        {currentTool.id === 'online-notepad' && (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
              <span>Autosaved locally in your browser {noteSavedAt ? `· Last saved ${noteSavedAt}` : ''}</span>
              <span className="tabular-nums">
                {noteContent.trim() ? noteContent.trim().split(/\s+/).length : 0} words
              </span>
            </div>
            <textarea
              rows={12}
              value={noteContent}
              onChange={(e) => setNoteContent(e.target.value)}
              placeholder="Write meeting notes, outlines, or drafts here..."
              className="w-full p-4 rounded-xl border border-slate-200 bg-[#F5F7FB] focus:bg-white text-sm text-[#101C35] leading-relaxed focus:outline-none focus:border-[#2563EB]"
            />
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => downloadTextFile(noteContent, 'infolinky-notes.txt')}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#101C35] text-white text-xs font-semibold hover:bg-[#1b2d52] cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export .txt</span>
              </button>
              <button
                type="button"
                onClick={() => downloadTextFile(noteContent, 'infolinky-notes.md')}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-slate-200 text-xs font-semibold text-[#101C35] hover:bg-slate-50 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export .md</span>
              </button>
              <button
                type="button"
                onClick={() => setNoteContent('')}
                className="px-4 py-2 rounded-lg border border-rose-200 text-xs font-semibold text-rose-700 hover:bg-rose-50 cursor-pointer"
              >
                Clear Notepad
              </button>
            </div>
          </div>
        )}

        {currentTool.id === 'text-to-speech' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Voice</label>
                <select
                  value={selectedVoice}
                  onChange={(e) => setSelectedVoice(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg border border-slate-200 text-xs"
                >
                  {voices.map((v) => (
                    <option key={v.name} value={v.name}>
                      {v.name} ({v.lang})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="flex justify-between text-xs text-slate-600 mb-1">
                  <span>Speed</span>
                  <span className="tabular-nums">{speechRate.toFixed(1)}x</span>
                </label>
                <input
                  type="range"
                  min={0.6}
                  max={1.8}
                  step={0.1}
                  value={speechRate}
                  onChange={(e) => setSpeechRate(Number(e.target.value))}
                  className="w-full accent-[#2563EB]"
                />
              </div>
              <div>
                <label className="flex justify-between text-xs text-slate-600 mb-1">
                  <span>Pitch</span>
                  <span className="tabular-nums">{speechPitch.toFixed(1)}</span>
                </label>
                <input
                  type="range"
                  min={0.6}
                  max={1.6}
                  step={0.1}
                  value={speechPitch}
                  onChange={(e) => setSpeechPitch(Number(e.target.value))}
                  className="w-full accent-[#2563EB]"
                />
              </div>
            </div>

            <textarea
              rows={6}
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Enter text to read aloud using your browser's speech synthesizer..."
              className="w-full p-4 rounded-xl border border-slate-200 bg-[#F5F7FB] text-sm"
            />

            <div className="flex gap-2">
              <button
                type="button"
                onClick={handleSpeak}
                disabled={speaking || !text.trim()}
                className="inline-flex items-center gap-2 h-10 px-5 rounded-lg bg-[#2563EB] disabled:opacity-50 text-white text-sm font-semibold hover:bg-[#1d4ed8] cursor-pointer"
              >
                <Play className="w-4 h-4" />
                <span>Speak Text</span>
              </button>
              <button
                type="button"
                onClick={handleStopSpeak}
                className="inline-flex items-center gap-2 h-10 px-4 rounded-lg border border-slate-200 text-sm font-semibold text-[#101C35] hover:bg-slate-50 cursor-pointer"
              >
                <Square className="w-4 h-4" />
                <span>Stop</span>
              </button>
            </div>
          </div>
        )}

        {currentTool.id === 'speech-to-text' && (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <select
                value={sttLang}
                onChange={(e) => setSttLang(e.target.value)}
                className="h-10 px-3 rounded-lg border border-slate-200 text-sm"
              >
                <option value="en-US">English (US)</option>
                <option value="en-GB">English (UK)</option>
                <option value="ur-PK">Urdu (Pakistan)</option>
                <option value="ar-SA">Arabic</option>
                <option value="es-ES">Spanish</option>
                <option value="fr-FR">French</option>
              </select>

              <button
                type="button"
                onClick={toggleSpeechToText}
                className={`inline-flex items-center gap-2 h-10 px-5 rounded-lg text-sm font-semibold text-white cursor-pointer ${
                  listening ? 'bg-rose-600 hover:bg-rose-700' : 'bg-[#2563EB] hover:bg-[#1d4ed8]'
                }`}
              >
                {listening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                <span>{listening ? 'Stop Dictation' : 'Start Microphone Dictation'}</span>
              </button>
            </div>

            {sttError && (
              <p className="text-xs text-rose-700 bg-rose-50 border border-rose-200 rounded-lg p-3">
                {sttError}
              </p>
            )}

            <textarea
              rows={7}
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Spoken transcript appears here..."
              className="w-full p-4 rounded-xl border border-slate-200 bg-[#F5F7FB] text-sm"
            />

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => copyString(text)}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-slate-200 text-xs font-semibold hover:bg-slate-50 cursor-pointer"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>Copy Transcript</span>
              </button>
              <button
                type="button"
                onClick={() => downloadTextFile(text, 'transcript.txt')}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#101C35] text-white text-xs font-semibold hover:bg-[#1b2d52] cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download .txt</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
