import { useState } from 'react';
import { Plus, Trash2, Download, Loader2 } from 'lucide-react';
import { jsPDF } from 'jspdf';
import { TOOLS_CATALOG } from '../data/toolsCatalog';

const BUSINESS_TOOLS = TOOLS_CATALOG.filter((t) => t.category === 'business');

interface LineItem {
  description: string;
  qty: number;
  price: number;
}

interface BusinessToolsWorkspaceProps {
  activeToolId: string;
  onSelectTool: (id: string) => void;
}

export function BusinessToolsWorkspace({
  activeToolId,
  onSelectTool,
}: BusinessToolsWorkspaceProps) {
  const currentTool = BUSINESS_TOOLS.find((t) => t.id === activeToolId) || BUSINESS_TOOLS[0];

  const [docNumber, setDocNumber] = useState('INV-2026-001');
  const [senderName, setSenderName] = useState('InfoLinky Digital Services');
  const [senderEmail, setSenderEmail] = useState('billing@example.com');
  const [clientName, setClientName] = useState('Client Organization');
  const [currency, setCurrency] = useState('$');
  const [taxRate, setTaxRate] = useState(0);
  const [discountPct, setDiscountPct] = useState(0);
  const [notes, setNotes] = useState('Payment due within 14 days. Thank you for your business.');
  const [items, setItems] = useState<LineItem[]>([
    { description: 'Website Strategy & Technical Audit', qty: 1, price: 450 },
    { description: 'Landing Page Implementation', qty: 1, price: 650 },
  ]);

  const [resName, setResName] = useState('Ali Raza');
  const [resTitle, setResTitle] = useState('Digital Strategist & Web Product Builder');
  const [resContact, setResContact] = useState('Hyderabad, Pakistan · email@example.com');
  const [resSummary, setResSummary] = useState(
    'Product-focused digital builder experienced in web workflows, SEO architecture, and browser utility platforms.'
  );
  const [resExperience, setResExperience] = useState(
    'Founder, InfoLinky (2024–Present)\n- Built and maintained 50+ browser utilities and software comparison guides.\n- Managed partner relationships and editorial review standards.'
  );
  const [resEducation, setResEducation] = useState('B.S. Computer Science / Information Systems');
  const [resSkills, setResSkills] = useState(
    'TypeScript, React, Technical SEO, Content Strategy, Digital Marketing'
  );

  const [clApplicant, setClApplicant] = useState('');
  const [clRole, setClRole] = useState('');
  const [clCompany, setClCompany] = useState('');
  const [clHighlights, setClHighlights] = useState('');
  const [clDraft, setClDraft] = useState('');
  const [clBusy, setClBusy] = useState(false);
  const [clError, setClError] = useState('');

  const [pctA, setPctA] = useState(15);
  const [pctB, setPctB] = useState(200);
  const [chgOld, setChgOld] = useState(120);
  const [chgNew, setChgNew] = useState(150);

  const [discPrice, setDiscPrice] = useState(100);
  const [discPct, setDiscPct] = useState(20);
  const [discTax, setDiscTax] = useState(5);

  const [plCost, setPlCost] = useState(25);
  const [plSell, setPlSell] = useState(49);
  const [plQty, setPlQty] = useState(100);
  const [plOverhead, setPlOverhead] = useState(400);

  const subtotal = items.reduce((sum, it) => sum + it.qty * it.price, 0);
  const discountAmount = (subtotal * discountPct) / 100;
  const taxable = Math.max(0, subtotal - discountAmount);
  const taxAmount = (taxable * taxRate) / 100;
  const grandTotal = taxable + taxAmount;

  const downloadInvoiceOrQuotePdf = (isQuote: boolean) => {
    const doc = new jsPDF({ unit: 'mm', format: 'a4' });
    doc.setFillColor(16, 28, 53);
    doc.rect(0, 0, 210, 32, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(18);
    doc.text(isQuote ? 'PROJECT QUOTATION' : 'INVOICE', 16, 20);
    doc.setFontSize(10);
    doc.text(`Ref: ${docNumber}`, 155, 20);

    doc.setTextColor(16, 28, 53);
    doc.setFontSize(11);
    doc.text(`From: ${senderName}`, 16, 46);
    doc.setFontSize(9.5);
    doc.setTextColor(80, 90, 110);
    doc.text(senderEmail, 16, 52);

    doc.setTextColor(16, 28, 53);
    doc.setFontSize(11);
    doc.text(`Prepared For: ${clientName}`, 120, 46);

    let y = 70;
    doc.setFillColor(245, 247, 251);
    doc.rect(16, y - 6, 178, 9, 'F');
    doc.setFontSize(9.5);
    doc.text('Description', 18, y);
    doc.text('Qty', 132, y);
    doc.text('Rate', 150, y);
    doc.text('Total', 175, y);

    y += 9;
    items.forEach((it) => {
      doc.text(it.description.slice(0, 55), 18, y);
      doc.text(String(it.qty), 132, y);
      doc.text(`${currency}${it.price.toFixed(2)}`, 150, y);
      doc.text(`${currency}${(it.qty * it.price).toFixed(2)}`, 175, y);
      y += 8;
    });

    y += 6;
    doc.line(120, y, 194, y);
    y += 7;
    doc.text(`Subtotal: ${currency}${subtotal.toFixed(2)}`, 140, y);
    y += 6;
    if (discountPct > 0) {
      doc.text(`Discount (${discountPct}%): -${currency}${discountAmount.toFixed(2)}`, 140, y);
      y += 6;
    }
    if (taxRate > 0) {
      doc.text(`Tax (${taxRate}%): ${currency}${taxAmount.toFixed(2)}`, 140, y);
      y += 6;
    }
    doc.setFontSize(11.5);
    doc.text(`Total: ${currency}${grandTotal.toFixed(2)}`, 140, y + 2);

    y += 18;
    doc.setFontSize(9);
    doc.setTextColor(90, 100, 115);
    const noteLines = doc.splitTextToSize(notes, 176);
    doc.text(noteLines, 16, y);

    doc.save(`${isQuote ? 'quotation' : 'invoice'}-${docNumber}.pdf`);
  };

  const downloadResumePdf = () => {
    const doc = new jsPDF({ unit: 'mm', format: 'a4' });
    doc.setFontSize(20);
    doc.setTextColor(16, 28, 53);
    doc.text(resName, 16, 22);
    doc.setFontSize(11);
    doc.setTextColor(37, 99, 235);
    doc.text(resTitle, 16, 29);
    doc.setFontSize(9.5);
    doc.setTextColor(90, 100, 115);
    doc.text(resContact, 16, 35);
    doc.line(16, 39, 194, 39);

    let y = 48;
    const addSection = (heading: string, body: string) => {
      doc.setFontSize(11.5);
      doc.setTextColor(16, 28, 53);
      doc.text(heading, 16, y);
      y += 6;
      doc.setFontSize(9.5);
      doc.setTextColor(55, 65, 81);
      const lines = doc.splitTextToSize(body, 176);
      doc.text(lines, 16, y);
      y += lines.length * 5 + 7;
    };

    addSection('Professional Summary', resSummary);
    addSection('Experience', resExperience);
    addSection('Education', resEducation);
    addSection('Core Skills', resSkills);
    doc.save('infolinky-resume.pdf');
  };

  const generateCoverLetterTemplate = () => {
    const name = clApplicant.trim() || '[Your Name]';
    const role = clRole.trim() || '[Role Title]';
    const comp = clCompany.trim() || '[Company Name]';
    const high =
      clHighlights.trim() ||
      'proven track record of delivering measurable digital projects on schedule';

    setClError('');
    setClDraft(
      `Dear Hiring Team at ${comp},\n\nI am writing to express my interest in the ${role} position. With ${high}, I am confident I can contribute immediate value to your team.\n\nIn my recent work, I have focused on clear execution, cross-functional communication, and practical problem-solving that directly supports team goals. I welcome the opportunity to discuss how my background aligns with ${comp}'s upcoming priorities.\n\nThank you for your time and consideration.\n\nSincerely,\n${name}`
    );
  };

  const polishCoverLetterWithAi = async () => {
    const source =
      clDraft.trim() ||
      `Applicant: ${clApplicant}, Role: ${clRole}, Company: ${clCompany}, Highlights: ${clHighlights}`;
    if (!source.replace(/[ApplicantRoleCompanyHighlights:,.\s]/g, '')) {
      setClError('Please enter your role, company, or draft text first.');
      return;
    }
    setClBusy(true);
    setClError('');
    try {
      const res = await fetch('/api/ai/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          toolId: 'cover-letter-enhance',
          input: source,
          tone: 'Professional',
        }),
      });
      const data = await res.json();
      if (res.ok && data.output) {
        setClDraft(data.output);
      } else {
        setClError(data.error || 'AI enhancement unavailable. You can still edit and export the structured template.');
      }
    } catch {
      setClError('Unable to reach server AI endpoint. Use the structured template builder above.');
    } finally {
      setClBusy(false);
    }
  };

  const downloadCoverLetterPdf = () => {
    const doc = new jsPDF({ unit: 'mm', format: 'a4' });
    doc.setFontSize(11);
    const lines = doc.splitTextToSize(clDraft, 176);
    doc.text(lines, 16, 22);
    doc.save('cover-letter.pdf');
  };

  const plRevenue = plSell * plQty;
  const plCogs = plCost * plQty;
  const plNet = plRevenue - plCogs - plOverhead;
  const plMargin = plRevenue > 0 ? (plNet / plRevenue) * 100 : 0;
  const plMarkup = plCost > 0 ? ((plSell - plCost) / plCost) * 100 : 0;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      <div className="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-3">
        <div className="px-3 py-2 text-xs font-semibold text-slate-500">
          Business Suite (7 Tools)
        </div>
        <div className="space-y-1">
          {BUSINESS_TOOLS.map((tool) => (
            <button
              key={tool.id}
              type="button"
              onClick={() => onSelectTool(tool.id)}
              className={`w-full text-left px-3 py-2.5 rounded-lg text-sm transition-colors cursor-pointer ${
                tool.id === currentTool.id
                  ? 'bg-[#101C35] text-white font-semibold'
                  : 'text-slate-700 hover:bg-[#F5F7FB]'
              }`}
            >
              {tool.name}
            </button>
          ))}
        </div>
      </div>

      <div className="lg:col-span-8 bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-6">
        <div className="border-b border-slate-100 pb-4">
          <div className="text-xs font-medium text-[#059669] mb-1">
            Client-Side PDF Documents &amp; Financial Calculators
          </div>
          <h2 className="font-display text-xl sm:text-2xl font-bold text-[#101C35]">
            {currentTool.name}
          </h2>
          <p className="text-sm text-slate-600 mt-1">{currentTool.description}</p>
        </div>

        {(currentTool.id === 'invoice-generator' || currentTool.id === 'quotation-generator') && (
          <div className="space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">
                  {currentTool.id === 'quotation-generator' ? 'Quotation #' : 'Invoice #'}
                </label>
                <input
                  type="text"
                  value={docNumber}
                  onChange={(e) => setDocNumber(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm font-mono"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Currency</label>
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm"
                >
                  <option value="$">USD ($)</option>
                  <option value="€">EUR (€)</option>
                  <option value="£">GBP (£)</option>
                  <option value="PKR ">PKR</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">From (Your Business)</label>
                <input
                  type="text"
                  value={senderName}
                  onChange={(e) => setSenderName(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Sender Email</label>
                <input
                  type="email"
                  value={senderEmail}
                  onChange={(e) => setSenderEmail(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-slate-600 mb-1">Bill To (Client)</label>
                <input
                  type="text"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm"
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-600">Line Items</span>
                <button
                  type="button"
                  onClick={() =>
                    setItems((p) => [...p, { description: 'New Service Item', qty: 1, price: 100 }])
                  }
                  className="inline-flex items-center gap-1 text-xs font-semibold text-[#2563EB] hover:underline cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Add Row
                </button>
              </div>
              {items.map((item, idx) => (
                <div key={idx} className="grid grid-cols-12 gap-2 items-center">
                  <input
                    type="text"
                    value={item.description}
                    onChange={(e) =>
                      setItems((prev) =>
                        prev.map((row, i) => (i === idx ? { ...row, description: e.target.value } : row))
                      )
                    }
                    className="col-span-6 h-9 px-2.5 rounded-lg border border-slate-200 text-xs"
                  />
                  <input
                    type="number"
                    min={1}
                    value={item.qty}
                    onChange={(e) =>
                      setItems((prev) =>
                        prev.map((row, i) =>
                          i === idx ? { ...row, qty: Number(e.target.value) || 1 } : row
                        )
                      )
                    }
                    className="col-span-2 h-9 px-2 rounded-lg border border-slate-200 text-xs tabular-nums"
                  />
                  <input
                    type="number"
                    min={0}
                    value={item.price}
                    onChange={(e) =>
                      setItems((prev) =>
                        prev.map((row, i) =>
                          i === idx ? { ...row, price: Number(e.target.value) || 0 } : row
                        )
                      )
                    }
                    className="col-span-3 h-9 px-2 rounded-lg border border-slate-200 text-xs tabular-nums"
                  />
                  <button
                    type="button"
                    onClick={() => setItems((prev) => prev.filter((_, i) => i !== idx))}
                    className="col-span-1 flex justify-center text-rose-600 cursor-pointer"
                    aria-label="Remove item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs text-slate-600 mb-1">Discount (%)</label>
                <input
                  type="number"
                  min={0}
                  max={100}
                  value={discountPct}
                  onChange={(e) => setDiscountPct(Number(e.target.value) || 0)}
                  className="w-full h-9 px-3 rounded-lg border border-slate-200 text-sm tabular-nums"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-600 mb-1">Tax (%)</label>
                <input
                  type="number"
                  min={0}
                  max={100}
                  value={taxRate}
                  onChange={(e) => setTaxRate(Number(e.target.value) || 0)}
                  className="w-full h-9 px-3 rounded-lg border border-slate-200 text-sm tabular-nums"
                />
              </div>
              <div className="col-span-2 sm:col-span-1 flex flex-col justify-end text-right bg-[#F5F7FB] rounded-lg px-3 py-2 border border-slate-200">
                <span className="text-[11px] text-slate-500">Grand Total</span>
                <span className="text-lg font-bold text-[#101C35] tabular-nums">
                  {currency}{grandTotal.toFixed(2)}
                </span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Notes / Terms</label>
              <textarea
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full p-2.5 rounded-lg border border-slate-200 text-xs"
              />
            </div>

            <button
              type="button"
              onClick={() => downloadInvoiceOrQuotePdf(currentTool.id === 'quotation-generator')}
              className="inline-flex items-center gap-2 h-10 px-6 rounded-lg bg-[#2563EB] hover:bg-[#1d4ed8] text-white text-sm font-semibold cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>
                Download {currentTool.id === 'quotation-generator' ? 'Quotation' : 'Invoice'} PDF
              </span>
            </button>
          </div>
        )}

        {currentTool.id === 'resume-builder' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                type="text"
                value={resName}
                onChange={(e) => setResName(e.target.value)}
                placeholder="Full Name"
                className="h-10 px-3 rounded-lg border border-slate-200 text-sm"
              />
              <input
                type="text"
                value={resTitle}
                onChange={(e) => setResTitle(e.target.value)}
                placeholder="Target Role Title"
                className="h-10 px-3 rounded-lg border border-slate-200 text-sm"
              />
            </div>
            <input
              type="text"
              value={resContact}
              onChange={(e) => setResContact(e.target.value)}
              placeholder="Location · Email · Website"
              className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm"
            />
            <textarea
              rows={3}
              value={resSummary}
              onChange={(e) => setResSummary(e.target.value)}
              placeholder="Professional Summary"
              className="w-full p-3 rounded-lg border border-slate-200 text-sm"
            />
            <textarea
              rows={4}
              value={resExperience}
              onChange={(e) => setResExperience(e.target.value)}
              placeholder="Experience"
              className="w-full p-3 rounded-lg border border-slate-200 text-sm"
            />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                type="text"
                value={resEducation}
                onChange={(e) => setResEducation(e.target.value)}
                placeholder="Education"
                className="h-10 px-3 rounded-lg border border-slate-200 text-sm"
              />
              <input
                type="text"
                value={resSkills}
                onChange={(e) => setResSkills(e.target.value)}
                placeholder="Comma-separated skills"
                className="h-10 px-3 rounded-lg border border-slate-200 text-sm"
              />
            </div>
            <button
              type="button"
              onClick={downloadResumePdf}
              className="inline-flex items-center gap-2 h-10 px-6 rounded-lg bg-[#2563EB] hover:bg-[#1d4ed8] text-white text-sm font-semibold cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Export Resume PDF</span>
            </button>
          </div>
        )}

        {currentTool.id === 'cover-letter-generator' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <input
                type="text"
                value={clApplicant}
                onChange={(e) => setClApplicant(e.target.value)}
                placeholder="Your Full Name"
                className="h-10 px-3 rounded-lg border border-slate-200 text-sm"
              />
              <input
                type="text"
                value={clRole}
                onChange={(e) => setClRole(e.target.value)}
                placeholder="Target Role"
                className="h-10 px-3 rounded-lg border border-slate-200 text-sm"
              />
              <input
                type="text"
                value={clCompany}
                onChange={(e) => setClCompany(e.target.value)}
                placeholder="Company Name"
                className="h-10 px-3 rounded-lg border border-slate-200 text-sm"
              />
            </div>
            <input
              type="text"
              value={clHighlights}
              onChange={(e) => setClHighlights(e.target.value)}
              placeholder="Key achievements or relevant skills..."
              className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm"
            />
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={generateCoverLetterTemplate}
                className="h-9 px-4 rounded-lg bg-[#101C35] text-white text-xs font-semibold hover:bg-[#1b2d52] cursor-pointer"
              >
                Build Structured Draft
              </button>
              <button
                type="button"
                onClick={polishCoverLetterWithAi}
                disabled={clBusy}
                className="inline-flex items-center gap-1.5 h-9 px-4 rounded-lg bg-[#2563EB] text-white text-xs font-semibold hover:bg-[#1d4ed8] cursor-pointer"
              >
                {clBusy && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                <span>Enhance Draft with AI</span>
              </button>
            </div>
            {clError && (
              <p className="text-xs text-rose-700 bg-rose-50 border border-rose-200 rounded-lg p-3">
                {clError}
              </p>
            )}
            <textarea
              rows={8}
              value={clDraft}
              onChange={(e) => setClDraft(e.target.value)}
              placeholder="Your cover letter draft appears here..."
              className="w-full p-4 rounded-xl border border-slate-200 bg-[#F5F7FB] text-sm"
            />
            {clDraft && (
              <button
                type="button"
                onClick={downloadCoverLetterPdf}
                className="inline-flex items-center gap-2 h-10 px-5 rounded-lg bg-[#059669] text-white text-xs font-semibold hover:bg-[#047857] cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Cover Letter PDF</span>
              </button>
            )}
          </div>
        )}

        {currentTool.id === 'percentage-calculator' && (
          <div className="space-y-6">
            <div className="p-4 rounded-xl bg-[#F5F7FB] border border-slate-200 space-y-3">
              <div className="text-xs font-semibold text-[#101C35]">What is X% of Y?</div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-center">
                <input
                  type="number"
                  value={pctA}
                  onChange={(e) => setPctA(Number(e.target.value))}
                  className="h-10 px-3 rounded-lg border border-slate-200 bg-white text-sm tabular-nums"
                />
                <input
                  type="number"
                  value={pctB}
                  onChange={(e) => setPctB(Number(e.target.value))}
                  className="h-10 px-3 rounded-lg border border-slate-200 bg-white text-sm tabular-nums"
                />
                <div className="text-base font-bold text-[#2563EB] tabular-nums">
                  = {((pctA / 100) * pctB).toFixed(2)}
                </div>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-[#F5F7FB] border border-slate-200 space-y-3">
              <div className="text-xs font-semibold text-[#101C35]">
                Percentage Change (From → To)
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-center">
                <input
                  type="number"
                  value={chgOld}
                  onChange={(e) => setChgOld(Number(e.target.value))}
                  className="h-10 px-3 rounded-lg border border-slate-200 bg-white text-sm tabular-nums"
                />
                <input
                  type="number"
                  value={chgNew}
                  onChange={(e) => setChgNew(Number(e.target.value))}
                  className="h-10 px-3 rounded-lg border border-slate-200 bg-white text-sm tabular-nums"
                />
                <div className="text-base font-bold text-[#059669] tabular-nums">
                  {chgOld !== 0 ? `${(((chgNew - chgOld) / chgOld) * 100).toFixed(2)}%` : 'N/A'}
                </div>
              </div>
            </div>
          </div>
        )}

        {currentTool.id === 'discount-calculator' && (
          <div className="space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs text-slate-600 mb-1">Original Price</label>
                <input
                  type="number"
                  min={0}
                  value={discPrice}
                  onChange={(e) => setDiscPrice(Number(e.target.value))}
                  className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm tabular-nums"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-600 mb-1">Discount (%)</label>
                <input
                  type="number"
                  min={0}
                  max={100}
                  value={discPct}
                  onChange={(e) => setDiscPct(Number(e.target.value))}
                  className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm tabular-nums"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-600 mb-1">Sales Tax (%)</label>
                <input
                  type="number"
                  min={0}
                  max={100}
                  value={discTax}
                  onChange={(e) => setDiscTax(Number(e.target.value))}
                  className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm tabular-nums"
                />
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-4 rounded-xl bg-[#F5F7FB] border border-slate-200">
                <div className="text-xs text-slate-500">You Save</div>
                <div className="text-xl font-bold text-[#059669] tabular-nums">
                  ${((discPrice * discPct) / 100).toFixed(2)}
                </div>
              </div>
              <div className="p-4 rounded-xl bg-[#F5F7FB] border border-slate-200">
                <div className="text-xs text-slate-500">Tax Amount</div>
                <div className="text-xl font-bold text-[#101C35] tabular-nums">
                  ${(((discPrice * (1 - discPct / 100)) * discTax) / 100).toFixed(2)}
                </div>
              </div>
              <div className="p-4 rounded-xl bg-[#101C35] text-white">
                <div className="text-xs text-slate-300">Final Price</div>
                <div className="text-xl font-bold tabular-nums">
                  ${(discPrice * (1 - discPct / 100) * (1 + discTax / 100)).toFixed(2)}
                </div>
              </div>
            </div>
          </div>
        )}

        {currentTool.id === 'profit-loss-calculator' && (
          <div className="space-y-5">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <label className="block text-xs text-slate-600 mb-1">Unit Cost ($)</label>
                <input
                  type="number"
                  value={plCost}
                  onChange={(e) => setPlCost(Number(e.target.value))}
                  className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm tabular-nums"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-600 mb-1">Selling Price ($)</label>
                <input
                  type="number"
                  value={plSell}
                  onChange={(e) => setPlSell(Number(e.target.value))}
                  className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm tabular-nums"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-600 mb-1">Units Sold</label>
                <input
                  type="number"
                  value={plQty}
                  onChange={(e) => setPlQty(Number(e.target.value))}
                  className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm tabular-nums"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-600 mb-1">Fixed Overhead ($)</label>
                <input
                  type="number"
                  value={plOverhead}
                  onChange={(e) => setPlOverhead(Number(e.target.value))}
                  className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm tabular-nums"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-4 rounded-xl bg-[#F5F7FB] border border-slate-200">
                <div className="text-xs text-slate-500">Revenue</div>
                <div className="text-lg font-bold text-[#101C35] tabular-nums">
                  ${plRevenue.toFixed(2)}
                </div>
              </div>
              <div className="p-4 rounded-xl bg-[#F5F7FB] border border-slate-200">
                <div className="text-xs text-slate-500">Net {plNet >= 0 ? 'Profit' : 'Loss'}</div>
                <div
                  className={`text-lg font-bold tabular-nums ${
                    plNet >= 0 ? 'text-[#059669]' : 'text-rose-600'
                  }`}
                >
                  ${plNet.toFixed(2)}
                </div>
              </div>
              <div className="p-4 rounded-xl bg-[#F5F7FB] border border-slate-200">
                <div className="text-xs text-slate-500">Net Margin</div>
                <div className="text-lg font-bold text-[#101C35] tabular-nums">
                  {plMargin.toFixed(1)}%
                </div>
              </div>
              <div className="p-4 rounded-xl bg-[#F5F7FB] border border-slate-200">
                <div className="text-xs text-slate-500">Unit Markup</div>
                <div className="text-lg font-bold text-[#101C35] tabular-nums">
                  {plMarkup.toFixed(1)}%
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
