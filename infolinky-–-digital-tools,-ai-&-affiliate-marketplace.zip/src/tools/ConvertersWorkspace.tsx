import { useState } from 'react';
import { Upload, Download } from 'lucide-react';
import { TOOLS_CATALOG } from '../data/toolsCatalog';

const CONVERTER_TOOLS = TOOLS_CATALOG.filter((t) => t.category === 'converters');

const UNIT_TABLES: Record<
  string,
  { units: { id: string; label: string; factorToBase: number }[] }
> = {
  'file-size-converter': {
    units: [
      { id: 'B', label: 'Bytes (B)', factorToBase: 1 },
      { id: 'KB', label: 'Kilobytes (KB, 1000)', factorToBase: 1000 },
      { id: 'MB', label: 'Megabytes (MB, 1000²)', factorToBase: 1e6 },
      { id: 'GB', label: 'Gigabytes (GB, 1000³)', factorToBase: 1e9 },
      { id: 'TB', label: 'Terabytes (TB, 1000⁴)', factorToBase: 1e12 },
      { id: 'KiB', label: 'Kibibytes (KiB, 1024)', factorToBase: 1024 },
      { id: 'MiB', label: 'Mebibytes (MiB, 1024²)', factorToBase: 1024 ** 2 },
      { id: 'GiB', label: 'Gibibytes (GiB, 1024³)', factorToBase: 1024 ** 3 },
    ],
  },
  'length-converter': {
    units: [
      { id: 'mm', label: 'Millimeters (mm)', factorToBase: 0.001 },
      { id: 'cm', label: 'Centimeters (cm)', factorToBase: 0.01 },
      { id: 'm', label: 'Meters (m)', factorToBase: 1 },
      { id: 'km', label: 'Kilometers (km)', factorToBase: 1000 },
      { id: 'in', label: 'Inches (in)', factorToBase: 0.0254 },
      { id: 'ft', label: 'Feet (ft)', factorToBase: 0.3048 },
      { id: 'yd', label: 'Yards (yd)', factorToBase: 0.9144 },
      { id: 'mi', label: 'Miles (mi)', factorToBase: 1609.344 },
    ],
  },
  'weight-converter': {
    units: [
      { id: 'mg', label: 'Milligrams (mg)', factorToBase: 0.001 },
      { id: 'g', label: 'Grams (g)', factorToBase: 1 },
      { id: 'kg', label: 'Kilograms (kg)', factorToBase: 1000 },
      { id: 't', label: 'Metric Tons (t)', factorToBase: 1e6 },
      { id: 'oz', label: 'Ounces (oz)', factorToBase: 28.349523125 },
      { id: 'lb', label: 'Pounds (lb)', factorToBase: 453.59237 },
      { id: 'st', label: 'Stone (st)', factorToBase: 6350.29318 },
    ],
  },
  'time-converter': {
    units: [
      { id: 'ms', label: 'Milliseconds (ms)', factorToBase: 0.001 },
      { id: 's', label: 'Seconds (s)', factorToBase: 1 },
      { id: 'min', label: 'Minutes (min)', factorToBase: 60 },
      { id: 'hr', label: 'Hours (hr)', factorToBase: 3600 },
      { id: 'day', label: 'Days (24h)', factorToBase: 86400 },
      { id: 'wk', label: 'Weeks (7d)', factorToBase: 604800 },
      { id: 'yr', label: 'Years (365d)', factorToBase: 31536000 },
    ],
  },
};

interface ConvertersWorkspaceProps {
  activeToolId: string;
  onSelectTool: (id: string) => void;
}

export function ConvertersWorkspace({ activeToolId, onSelectTool }: ConvertersWorkspaceProps) {
  const currentTool = CONVERTER_TOOLS.find((t) => t.id === activeToolId) || CONVERTER_TOOLS[0];

  const [value, setValue] = useState<number>(1);
  const [fromUnit, setFromUnit] = useState<string>('');
  const [toUnit, setToUnit] = useState<string>('');

  const [tempVal, setTempVal] = useState<number>(25);
  const [tempUnit, setTempUnit] = useState<'C' | 'F' | 'K'>('C');

  const [imgTargetFormat, setImgTargetFormat] = useState<'image/png' | 'image/jpeg' | 'image/webp'>(
    'image/webp'
  );
  const [convertedImgUrl, setConvertedImgUrl] = useState<string>('');
  const [convertedName, setConvertedName] = useState<string>('');

  const table = UNIT_TABLES[currentTool.id];
  const resolvedFrom =
    table && table.units.some((u) => u.id === fromUnit) ? fromUnit : table?.units[0]?.id || '';
  const resolvedTo =
    table && table.units.some((u) => u.id === toUnit) ? toUnit : table?.units[2]?.id || '';

  const convertedValue = (() => {
    if (!table) return 0;
    const f = table.units.find((u) => u.id === resolvedFrom);
    const t = table.units.find((u) => u.id === resolvedTo);
    if (!f || !t) return 0;
    return (value * f.factorToBase) / t.factorToBase;
  })();

  const temps = (() => {
    let c = tempVal;
    if (tempUnit === 'F') c = ((tempVal - 32) * 5) / 9;
    if (tempUnit === 'K') c = tempVal - 273.15;
    return {
      C: c,
      F: (c * 9) / 5 + 32,
      K: c + 273.15,
    };
  })();

  const handleImageFormatUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.naturalWidth;
        canvas.height = img.naturalHeight;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        if (imgTargetFormat === 'image/jpeg') {
          ctx.fillStyle = '#FFFFFF';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
        }
        ctx.drawImage(img, 0, 0);
        const ext =
          imgTargetFormat === 'image/png'
            ? 'png'
            : imgTargetFormat === 'image/jpeg'
              ? 'jpg'
              : 'webp';
        setConvertedImgUrl(canvas.toDataURL(imgTargetFormat, 0.9));
        setConvertedName(`${file.name.replace(/\.[^.]+$/, '')}.${ext}`);
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      <div className="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-3">
        <div className="px-3 py-2 text-xs font-semibold text-slate-500">
          File &amp; Unit Converters (6 Tools)
        </div>
        <div className="space-y-1">
          {CONVERTER_TOOLS.map((tool) => (
            <button
              key={tool.id}
              type="button"
              onClick={() => {
                onSelectTool(tool.id);
                setConvertedImgUrl('');
              }}
              className={`w-full text-left px-3 py-2.5 rounded-lg text-sm transition-colors cursor-pointer ${
                tool.id === currentTool.id
                  ? 'bg-[#101C35] text-white font-semibold'
                  : 'text-slate-700 hover:bg-[#F5F7FB]'
              }`}
            >
              {tool.name}
            </button>
          ))}
        </div>
      </div>

      <div className="lg:col-span-8 bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-6">
        <div className="border-b border-slate-100 pb-4">
          <div className="text-xs font-medium text-[#059669] mb-1">
            Precision Instant Conversion
          </div>
          <h2 className="font-display text-xl sm:text-2xl font-bold text-[#101C35]">
            {currentTool.name}
          </h2>
          <p className="text-sm text-slate-600 mt-1">{currentTool.description}</p>
        </div>

        {currentTool.id === 'image-format-converter' && (
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <label className="text-xs font-medium text-slate-600">Target Output Format</label>
              <select
                value={imgTargetFormat}
                onChange={(e) => setImgTargetFormat(e.target.value as typeof imgTargetFormat)}
                className="h-10 px-3 rounded-lg border border-slate-200 text-sm"
              >
                <option value="image/webp">WebP (.webp)</option>
                <option value="image/png">PNG (.png)</option>
                <option value="image/jpeg">JPG (.jpg)</option>
              </select>
            </div>
            <label className="flex flex-col items-center justify-center border-2 border-dashed border-slate-300 hover:border-[#2563EB] bg-[#F5F7FB] rounded-xl p-6 cursor-pointer">
              <Upload className="w-6 h-6 text-[#2563EB] mb-2" />
              <span className="text-sm font-semibold text-[#101C35]">
                Select an image to convert
              </span>
              <input
                type="file"
                accept="image/*"
                onChange={handleImageFormatUpload}
                className="hidden"
              />
            </label>
            {convertedImgUrl && (
              <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-between gap-3">
                <span className="text-xs font-medium text-emerald-900">
                  Ready: {convertedName}
                </span>
                <a
                  href={convertedImgUrl}
                  download={convertedName}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#059669] text-white text-xs font-semibold"
                >
                  <Download className="w-3.5 h-3.5" />
                  Download
                </a>
              </div>
            )}
          </div>
        )}

        {currentTool.id === 'temperature-converter' && (
          <div className="space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                type="number"
                value={tempVal}
                onChange={(e) => setTempVal(Number(e.target.value))}
                className="h-11 px-3 rounded-lg border border-slate-200 text-base font-mono tabular-nums"
              />
              <select
                value={tempUnit}
                onChange={(e) => setTempUnit(e.target.value as 'C' | 'F' | 'K')}
                className="h-11 px-3 rounded-lg border border-slate-200 text-sm"
              >
                <option value="C">Celsius (°C)</option>
                <option value="F">Fahrenheit (°F)</option>
                <option value="K">Kelvin (K)</option>
              </select>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-4 rounded-xl bg-[#F5F7FB] border border-slate-200">
                <div className="text-xs text-slate-500">Celsius</div>
                <div className="text-xl font-bold text-[#101C35] tabular-nums">
                  {temps.C.toFixed(2)} °C
                </div>
              </div>
              <div className="p-4 rounded-xl bg-[#F5F7FB] border border-slate-200">
                <div className="text-xs text-slate-500">Fahrenheit</div>
                <div className="text-xl font-bold text-[#101C35] tabular-nums">
                  {temps.F.toFixed(2)} °F
                </div>
              </div>
              <div className="p-4 rounded-xl bg-[#F5F7FB] border border-slate-200">
                <div className="text-xs text-slate-500">Kelvin</div>
                <div className="text-xl font-bold text-[#101C35] tabular-nums">
                  {temps.K.toFixed(2)} K
                </div>
              </div>
            </div>
          </div>
        )}

        {table && (
          <div className="space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs text-slate-600 mb-1">Value</label>
                <input
                  type="number"
                  value={value}
                  onChange={(e) => setValue(Number(e.target.value))}
                  className="w-full h-11 px-3 rounded-lg border border-slate-200 text-sm font-mono tabular-nums"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-600 mb-1">From</label>
                <select
                  value={resolvedFrom}
                  onChange={(e) => setFromUnit(e.target.value)}
                  className="w-full h-11 px-3 rounded-lg border border-slate-200 text-sm"
                >
                  {table.units.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.label}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs text-slate-600 mb-1">To</label>
                <select
                  value={resolvedTo}
                  onChange={(e) => setToUnit(e.target.value)}
                  className="w-full h-11 px-3 rounded-lg border border-slate-200 text-sm"
                >
                  {table.units.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="p-5 rounded-xl bg-[#101C35] text-white flex items-center justify-between gap-4">
              <span className="text-sm text-slate-300">Converted Result</span>
              <span className="text-2xl font-bold font-mono tabular-nums">
                {Number.isInteger(convertedValue)
                  ? convertedValue.toLocaleString()
                  : convertedValue.toPrecision(6)}{' '}
                {resolvedTo}
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
