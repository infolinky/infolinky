import { useState, useRef } from 'react';
import { Upload, Download, RotateCw, FlipHorizontal, FlipVertical, Trash2 } from 'lucide-react';
import { jsPDF } from 'jspdf';
import { TOOLS_CATALOG } from '../data/toolsCatalog';

const IMAGE_TOOLS = TOOLS_CATALOG.filter((t) => t.category === 'image');

interface LoadedImage {
  name: string;
  size: number;
  width: number;
  height: number;
  dataUrl: string;
  img: HTMLImageElement;
}

interface ImageToolsWorkspaceProps {
  activeToolId: string;
  onSelectTool: (id: string) => void;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export function ImageToolsWorkspace({ activeToolId, onSelectTool }: ImageToolsWorkspaceProps) {
  const currentTool = IMAGE_TOOLS.find((t) => t.id === activeToolId) || IMAGE_TOOLS[0];
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [source, setSource] = useState<LoadedImage | null>(null);
  const [multiImages, setMultiImages] = useState<LoadedImage[]>([]);
  const [resultUrl, setResultUrl] = useState<string>('');
  const [resultSize, setResultSize] = useState<number>(0);
  const [resultExt, setResultExt] = useState<string>('png');
  const [statusMsg, setStatusMsg] = useState<string>('');

  // Resize controls
  const [targetWidth, setTargetWidth] = useState<number>(800);
  const [targetHeight, setTargetHeight] = useState<number>(600);
  const [keepAspect, setKeepAspect] = useState<boolean>(true);

  // Compress & format controls
  const [quality, setQuality] = useState<number>(80);
  const [bgColor, setBgColor] = useState<string>('#FFFFFF');
  const [webpTarget, setWebpTarget] = useState<'image/webp' | 'image/png' | 'image/jpeg'>('image/webp');

  // Crop controls (percentage 0-100)
  const [cropX, setCropX] = useState<number>(10);
  const [cropY, setCropY] = useState<number>(10);
  const [cropW, setCropW] = useState<number>(80);
  const [cropH, setCropH] = useState<number>(80);

  // Background remover controls
  const [tolerance, setTolerance] = useState<number>(36);
  const [edgeOnly, setEdgeOnly] = useState<boolean>(true);

  // Basic editor controls
  const [brightness, setBrightness] = useState<number>(100);
  const [contrast, setContrast] = useState<number>(100);
  const [saturate, setSaturate] = useState<number>(100);
  const [grayscale, setGrayscale] = useState<number>(0);
  const [rotation, setRotation] = useState<number>(0);
  const [flipH, setFlipH] = useState<boolean>(false);
  const [flipV, setFlipV] = useState<boolean>(false);

  // PDF options for Image to PDF
  const [pdfPageSize, setPdfPageSize] = useState<'a4' | 'letter'>('a4');

  const loadFileAsImage = (file: File): Promise<LoadedImage> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const dataUrl = String(reader.result);
        const img = new Image();
        img.onload = () => {
          resolve({
            name: file.name,
            size: file.size,
            width: img.naturalWidth,
            height: img.naturalHeight,
            dataUrl,
            img,
          });
        };
        img.onerror = () => reject(new Error(`Unable to decode ${file.name}`));
        img.src = dataUrl;
      };
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsDataURL(file);
    });
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;
    setResultUrl('');
    setResultSize(0);
    setStatusMsg('');

    try {
      if (currentTool.id === 'image-to-pdf') {
        const loaded = await Promise.all(files.map(loadFileAsImage));
        setMultiImages((prev) => [...prev, ...loaded]);
      } else {
        const loaded = await loadFileAsImage(files[0]);
        setSource(loaded);
        setTargetWidth(loaded.width);
        setTargetHeight(loaded.height);
      }
    } catch (err) {
      setStatusMsg(err instanceof Error ? err.message : 'Invalid image file.');
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const dataUrlByteSize = (url: string) => {
    const base64 = url.split(',')[1] || '';
    return Math.floor((base64.length * 3) / 4);
  };

  const processSingleImage = () => {
    if (!source) return;
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let mime = 'image/png';
    let ext = 'png';
    let q = quality / 100;

    if (currentTool.id === 'image-resizer') {
      canvas.width = Math.max(1, targetWidth);
      canvas.height = Math.max(1, targetHeight);
      ctx.drawImage(source.img, 0, 0, canvas.width, canvas.height);
      mime = source.name.toLowerCase().endsWith('.png') ? 'image/png' : 'image/jpeg';
      ext = mime === 'image/png' ? 'png' : 'jpg';
    } else if (currentTool.id === 'image-compressor') {
      canvas.width = source.width;
      canvas.height = source.height;
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(source.img, 0, 0);
      mime = 'image/jpeg';
      ext = 'jpg';
    } else if (currentTool.id === 'image-cropper') {
      const sx = Math.round((cropX / 100) * source.width);
      const sy = Math.round((cropY / 100) * source.height);
      const sw = Math.max(1, Math.round((cropW / 100) * source.width));
      const sh = Math.max(1, Math.round((cropH / 100) * source.height));
      canvas.width = sw;
      canvas.height = sh;
      ctx.drawImage(source.img, sx, sy, sw, sh, 0, 0, sw, sh);
      mime = 'image/png';
      ext = 'png';
    } else if (currentTool.id === 'jpg-to-png') {
      canvas.width = source.width;
      canvas.height = source.height;
      ctx.drawImage(source.img, 0, 0);
      mime = 'image/png';
      ext = 'png';
    } else if (currentTool.id === 'png-to-jpg') {
      canvas.width = source.width;
      canvas.height = source.height;
      ctx.fillStyle = bgColor;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(source.img, 0, 0);
      mime = 'image/jpeg';
      ext = 'jpg';
    } else if (currentTool.id === 'webp-converter') {
      canvas.width = source.width;
      canvas.height = source.height;
      if (webpTarget === 'image/jpeg') {
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }
      ctx.drawImage(source.img, 0, 0);
      mime = webpTarget;
      ext = webpTarget === 'image/webp' ? 'webp' : webpTarget === 'image/png' ? 'png' : 'jpg';
    } else if (currentTool.id === 'background-remover') {
      canvas.width = source.width;
      canvas.height = source.height;
      ctx.drawImage(source.img, 0, 0);
      const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = imgData.data;
      const w = canvas.width;
      const h = canvas.height;
      // Sample top-left pixel as background reference
      const bgR = data[0];
      const bgG = data[1];
      const bgB = data[2];
      const tolSq = tolerance * tolerance * 3;

      const colorMatch = (idx: number) => {
        const dr = data[idx] - bgR;
        const dg = data[idx + 1] - bgG;
        const db = data[idx + 2] - bgB;
        return dr * dr + dg * dg + db * db <= tolSq;
      };

      if (edgeOnly) {
        const visited = new Uint8Array(w * h);
        const queue: number[] = [];
        const pushIfMatch = (x: number, y: number) => {
          const pos = y * w + x;
          if (visited[pos]) return;
          if (colorMatch(pos * 4)) {
            visited[pos] = 1;
            queue.push(pos);
          }
        };
        for (let x = 0; x < w; x++) {
          pushIfMatch(x, 0);
          pushIfMatch(x, h - 1);
        }
        for (let y = 0; y < h; y++) {
          pushIfMatch(0, y);
          pushIfMatch(w - 1, y);
        }
        let head = 0;
        while (head < queue.length) {
          const pos = queue[head++];
          data[pos * 4 + 3] = 0;
          const x = pos % w;
          const y = (pos - x) / w;
          if (x > 0) pushIfMatch(x - 1, y);
          if (x + 1 < w) pushIfMatch(x + 1, y);
          if (y > 0) pushIfMatch(x, y - 1);
          if (y + 1 < h) pushIfMatch(x, y + 1);
        }
      } else {
        for (let i = 0; i < data.length; i += 4) {
          if (colorMatch(i)) {
            data[i + 3] = 0;
          }
        }
      }
      ctx.putImageData(imgData, 0, 0);
      mime = 'image/png';
      ext = 'png';
    } else if (currentTool.id === 'basic-image-editor') {
      const rad = (rotation * Math.PI) / 180;
      const swap = rotation % 180 !== 0;
      canvas.width = swap ? source.height : source.width;
      canvas.height = swap ? source.width : source.height;
      ctx.filter = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturate}%) grayscale(${grayscale}%)`;
      ctx.translate(canvas.width / 2, canvas.height / 2);
      ctx.rotate(rad);
      ctx.scale(flipH ? -1 : 1, flipV ? -1 : 1);
      ctx.drawImage(source.img, -source.width / 2, -source.height / 2);
      mime = 'image/png';
      ext = 'png';
    }

    const outUrl = canvas.toDataURL(mime, q);
    setResultUrl(outUrl);
    setResultSize(dataUrlByteSize(outUrl));
    setResultExt(ext);
    setStatusMsg('Processed locally in your browser.');
  };

  const generatePdfFromImages = () => {
    if (multiImages.length === 0) return;
    const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: pdfPageSize });
    const pageW = doc.internal.pageSize.getWidth();
    const pageH = doc.internal.pageSize.getHeight();
    const margin = 10;

    multiImages.forEach((item, index) => {
      if (index > 0) doc.addPage();
      const maxW = pageW - margin * 2;
      const maxH = pageH - margin * 2;
      const ratio = Math.min(maxW / item.width, maxH / item.height);
      const drawW = item.width * ratio;
      const drawH = item.height * ratio;
      const x = (pageW - drawW) / 2;
      const y = (pageH - drawH) / 2;
      const format = item.dataUrl.startsWith('data:image/png') ? 'PNG' : 'JPEG';
      doc.addImage(item.dataUrl, format, x, y, drawW, drawH);
    });

    doc.save('infolinky-images.pdf');
    setStatusMsg(`Generated PDF with ${multiImages.length} page(s).`);
  };

  const handleWidthChange = (w: number) => {
    setTargetWidth(w);
    if (keepAspect && source && source.width > 0) {
      setTargetHeight(Math.max(1, Math.round((w / source.width) * source.height)));
    }
  };

  const handleHeightChange = (h: number) => {
    setTargetHeight(h);
    if (keepAspect && source && source.height > 0) {
      setTargetWidth(Math.max(1, Math.round((h / source.height) * source.width)));
    }
  };

  const applyCropPreset = (ratioW: number, ratioH: number) => {
    if (!source) return;
    const imgRatio = source.width / source.height;
    const targetRatio = ratioW / ratioH;
    if (imgRatio > targetRatio) {
      const wPct = Math.round((targetRatio / imgRatio) * 100);
      setCropW(wPct);
      setCropH(100);
      setCropX(Math.round((100 - wPct) / 2));
      setCropY(0);
    } else {
      const hPct = Math.round((imgRatio / targetRatio) * 100);
      setCropW(100);
      setCropH(hPct);
      setCropX(0);
      setCropY(Math.round((100 - hPct) / 2));
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      <div className="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-3">
        <div className="px-3 py-2 text-xs font-semibold text-slate-500">
          Browser Image Suite (9 Tools)
        </div>
        <div className="space-y-1">
          {IMAGE_TOOLS.map((tool) => (
            <button
              key={tool.id}
              type="button"
              onClick={() => {
                onSelectTool(tool.id);
                setResultUrl('');
                setStatusMsg('');
              }}
              className={`w-full text-left px-3 py-2.5 rounded-lg text-sm transition-colors cursor-pointer ${
                tool.id === currentTool.id
                  ? 'bg-[#101C35] text-white font-semibold'
                  : 'text-slate-700 hover:bg-[#F5F7FB]'
              }`}
            >
              {tool.name}
            </button>
          ))}
        </div>
      </div>

      <div className="lg:col-span-8 bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-6">
        <div className="border-b border-slate-100 pb-4">
          <div className="text-xs font-medium text-[#059669] mb-1">
            100% Client-Side Canvas Processing · No File Uploads
          </div>
          <h2 className="font-display text-xl sm:text-2xl font-bold text-[#101C35]">
            {currentTool.name}
          </h2>
          <p className="text-sm text-slate-600 mt-1">{currentTool.description}</p>
        </div>

        {/* Upload Zone */}
        <div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            multiple={currentTool.id === 'image-to-pdf'}
            onChange={handleFileChange}
            className="hidden"
            id="image-upload-input"
          />
          <label
            htmlFor="image-upload-input"
            className="flex flex-col items-center justify-center border-2 border-dashed border-slate-300 hover:border-[#2563EB] bg-[#F5F7FB] rounded-xl p-6 text-center cursor-pointer transition-colors"
          >
            <Upload className="w-6 h-6 text-[#2563EB] mb-2" aria-hidden="true" />
            <span className="text-sm font-semibold text-[#101C35]">
              {currentTool.id === 'image-to-pdf'
                ? 'Select one or multiple images (JPG, PNG, WebP)'
                : source
                  ? `Replace "${source.name}"`
                  : 'Choose an image file (JPG, PNG, WebP)'}
            </span>
            <span className="text-xs text-slate-500 mt-1">
              Processed locally inside your browser memory
            </span>
          </label>
        </div>

        {/* Image to PDF queue */}
        {currentTool.id === 'image-to-pdf' && multiImages.length > 0 && (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <label htmlFor="pdf-page-sz" className="text-xs font-medium text-slate-600">
                  Page Format
                </label>
                <select
                  id="pdf-page-sz"
                  value={pdfPageSize}
                  onChange={(e) => setPdfPageSize(e.target.value as 'a4' | 'letter')}
                  className="h-9 px-3 rounded-lg border border-slate-200 text-xs"
                >
                  <option value="a4">A4 Portrait</option>
                  <option value="letter">US Letter Portrait</option>
                </select>
              </div>
              <button
                type="button"
                onClick={generatePdfFromImages}
                className="inline-flex items-center gap-2 h-10 px-5 rounded-lg bg-[#2563EB] text-white text-sm font-semibold hover:bg-[#1d4ed8] cursor-pointer"
              >
                <Download className="w-4 h-4" aria-hidden="true" />
                <span>Create &amp; Download PDF ({multiImages.length})</span>
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {multiImages.map((item, idx) => (
                <div
                  key={`${item.name}-${idx}`}
                  className="border border-slate-200 rounded-lg p-2 bg-[#F5F7FB] relative"
                >
                  <img
                    src={item.dataUrl}
                    alt={item.name}
                    className="w-full h-24 object-cover rounded"
                  />
                  <div className="mt-1.5 flex items-center justify-between gap-1 text-[11px] text-slate-600">
                    <span className="truncate">{item.name}</span>
                    <button
                      type="button"
                      onClick={() =>
                        setMultiImages((prev) => prev.filter((_, i) => i !== idx))
                      }
                      aria-label={`Remove ${item.name}`}
                      className="text-rose-600 hover:text-rose-800 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Controls for Single Image Tools */}
        {currentTool.id !== 'image-to-pdf' && source && (
          <div className="space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600 bg-[#F5F7FB] px-3.5 py-2.5 rounded-lg tabular-nums">
              <span>
                Source: <strong className="text-[#101C35]">{source.name}</strong>
              </span>
              <span>
                {source.width} × {source.height} px · {formatBytes(source.size)}
              </span>
            </div>

            {currentTool.id === 'image-resizer' && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">
                    Width (px)
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={8000}
                    value={targetWidth}
                    onChange={(e) => handleWidthChange(Number(e.target.value) || 1)}
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">
                    Height (px)
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={8000}
                    value={targetHeight}
                    onChange={(e) => handleHeightChange(Number(e.target.value) || 1)}
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm tabular-nums"
                  />
                </div>
                <label className="flex items-center gap-2 h-10 text-xs font-medium text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={keepAspect}
                    onChange={(e) => setKeepAspect(e.target.checked)}
                    className="rounded border-slate-300 text-[#2563EB]"
                  />
                  Lock aspect ratio
                </label>
              </div>
            )}

            {currentTool.id === 'image-compressor' && (
              <div>
                <div className="flex justify-between text-xs font-medium text-slate-600 mb-1">
                  <span>JPEG Quality</span>
                  <span className="tabular-nums">{quality}%</span>
                </div>
                <input
                  type="range"
                  min={10}
                  max={100}
                  value={quality}
                  onChange={(e) => setQuality(Number(e.target.value))}
                  className="w-full accent-[#2563EB]"
                />
              </div>
            )}

            {currentTool.id === 'image-cropper' && (
              <div className="space-y-3">
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => applyCropPreset(1, 1)}
                    className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium hover:bg-slate-50 cursor-pointer"
                  >
                    1:1 Square
                  </button>
                  <button
                    type="button"
                    onClick={() => applyCropPreset(16, 9)}
                    className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium hover:bg-slate-50 cursor-pointer"
                  >
                    16:9 Widescreen
                  </button>
                  <button
                    type="button"
                    onClick={() => applyCropPreset(4, 3)}
                    className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium hover:bg-slate-50 cursor-pointer"
                  >
                    4:3 Standard
                  </button>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-xs text-slate-600 mb-1">Left (%)</label>
                    <input
                      type="number"
                      min={0}
                      max={95}
                      value={cropX}
                      onChange={(e) => setCropX(Number(e.target.value))}
                      className="w-full h-9 px-2.5 rounded-lg border border-slate-200 text-sm tabular-nums"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-600 mb-1">Top (%)</label>
                    <input
                      type="number"
                      min={0}
                      max={95}
                      value={cropY}
                      onChange={(e) => setCropY(Number(e.target.value))}
                      className="w-full h-9 px-2.5 rounded-lg border border-slate-200 text-sm tabular-nums"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-600 mb-1">Width (%)</label>
                    <input
                      type="number"
                      min={5}
                      max={100}
                      value={cropW}
                      onChange={(e) => setCropW(Number(e.target.value))}
                      className="w-full h-9 px-2.5 rounded-lg border border-slate-200 text-sm tabular-nums"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-600 mb-1">Height (%)</label>
                    <input
                      type="number"
                      min={5}
                      max={100}
                      value={cropH}
                      onChange={(e) => setCropH(Number(e.target.value))}
                      className="w-full h-9 px-2.5 rounded-lg border border-slate-200 text-sm tabular-nums"
                    />
                  </div>
                </div>
              </div>
            )}

            {currentTool.id === 'png-to-jpg' && (
              <div className="flex items-center gap-4">
                <label className="text-xs font-medium text-slate-600">
                  Transparency Fill Color
                </label>
                <input
                  type="color"
                  value={bgColor}
                  onChange={(e) => setBgColor(e.target.value)}
                  className="h-9 w-14 rounded border border-slate-200 cursor-pointer"
                />
                <span className="text-xs font-mono text-slate-500">{bgColor}</span>
              </div>
            )}

            {currentTool.id === 'webp-converter' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">
                    Output Format
                  </label>
                  <select
                    value={webpTarget}
                    onChange={(e) =>
                      setWebpTarget(e.target.value as 'image/webp' | 'image/png' | 'image/jpeg')
                    }
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm"
                  >
                    <option value="image/webp">WebP (.webp)</option>
                    <option value="image/png">PNG (.png)</option>
                    <option value="image/jpeg">JPG (.jpg)</option>
                  </select>
                </div>
                <div>
                  <div className="flex justify-between text-xs font-medium text-slate-600 mb-1">
                    <span>Encoding Quality</span>
                    <span className="tabular-nums">{quality}%</span>
                  </div>
                  <input
                    type="range"
                    min={10}
                    max={100}
                    value={quality}
                    onChange={(e) => setQuality(Number(e.target.value))}
                    className="w-full accent-[#2563EB]"
                  />
                </div>
              </div>
            )}

            {currentTool.id === 'background-remover' && (
              <div className="space-y-3 bg-[#F5F7FB] p-4 rounded-lg border border-slate-200">
                <p className="text-xs text-slate-600">
                  Samples the outer corner background color and removes matching backdrop pixels locally. Works best on clean solid or studio-lit backgrounds.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
                  <div>
                    <div className="flex justify-between text-xs font-medium text-slate-700 mb-1">
                      <span>Color Tolerance</span>
                      <span className="tabular-nums">{tolerance}</span>
                    </div>
                    <input
                      type="range"
                      min={5}
                      max={110}
                      value={tolerance}
                      onChange={(e) => setTolerance(Number(e.target.value))}
                      className="w-full accent-[#2563EB]"
                    />
                  </div>
                  <label className="flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={edgeOnly}
                      onChange={(e) => setEdgeOnly(e.target.checked)}
                    />
                    Edge-connected flood fill (preserves interior highlights)
                  </label>
                </div>
              </div>
            )}

            {currentTool.id === 'basic-image-editor' && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="flex justify-between text-xs text-slate-600 mb-1">
                      <span>Brightness</span>
                      <span>{brightness}%</span>
                    </label>
                    <input
                      type="range"
                      min={30}
                      max={180}
                      value={brightness}
                      onChange={(e) => setBrightness(Number(e.target.value))}
                      className="w-full accent-[#2563EB]"
                    />
                  </div>
                  <div>
                    <label className="flex justify-between text-xs text-slate-600 mb-1">
                      <span>Contrast</span>
                      <span>{contrast}%</span>
                    </label>
                    <input
                      type="range"
                      min={30}
                      max={180}
                      value={contrast}
                      onChange={(e) => setContrast(Number(e.target.value))}
                      className="w-full accent-[#2563EB]"
                    />
                  </div>
                  <div>
                    <label className="flex justify-between text-xs text-slate-600 mb-1">
                      <span>Saturation</span>
                      <span>{saturate}%</span>
                    </label>
                    <input
                      type="range"
                      min={0}
                      max={200}
                      value={saturate}
                      onChange={(e) => setSaturate(Number(e.target.value))}
                      className="w-full accent-[#2563EB]"
                    />
                  </div>
                  <div>
                    <label className="flex justify-between text-xs text-slate-600 mb-1">
                      <span>Grayscale</span>
                      <span>{grayscale}%</span>
                    </label>
                    <input
                      type="range"
                      min={0}
                      max={100}
                      value={grayscale}
                      onChange={(e) => setGrayscale(Number(e.target.value))}
                      className="w-full accent-[#2563EB]"
                    />
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => setRotation((r) => (r + 90) % 360)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium hover:bg-slate-50 cursor-pointer"
                  >
                    <RotateCw className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Rotate 90° ({rotation}°)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setFlipH((v) => !v)}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium cursor-pointer ${
                      flipH ? 'border-[#2563EB] bg-blue-50 text-[#2563EB]' : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <FlipHorizontal className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Flip Horizontal</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setFlipV((v) => !v)}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium cursor-pointer ${
                      flipV ? 'border-[#2563EB] bg-blue-50 text-[#2563EB]' : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <FlipVertical className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Flip Vertical</span>
                  </button>
                </div>
              </div>
            )}

            <button
              type="button"
              onClick={processSingleImage}
              className="h-10 px-6 rounded-lg bg-[#2563EB] hover:bg-[#1d4ed8] text-white text-sm font-semibold transition-colors cursor-pointer"
            >
              Process Image
            </button>

            {resultUrl && (
              <div className="pt-4 border-t border-slate-100 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="text-xs text-slate-600 tabular-nums">
                    Output size: <strong className="text-[#101C35]">{formatBytes(resultSize)}</strong>
                    {source.size > 0 && (
                      <span className="ml-2 text-[#059669]">
                        ({resultSize < source.size
                          ? `${Math.round(((source.size - resultSize) / source.size) * 100)}% smaller`
                          : 'Converted'}
                        )
                      </span>
                    )}
                  </div>
                  <a
                    href={resultUrl}
                    download={`infolinky-${currentTool.id}.${resultExt}`}
                    className="inline-flex items-center gap-2 h-9 px-4 rounded-lg bg-[#101C35] text-white text-xs font-semibold hover:bg-[#1b2d52]"
                  >
                    <Download className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Download .{resultExt}</span>
                  </a>
                </div>
                <div
                  className="rounded-xl border border-slate-200 p-4 flex items-center justify-center overflow-hidden"
                  style={{
                    backgroundImage:
                      'linear-gradient(45deg, #f1f5f9 25%, transparent 25%), linear-gradient(-45deg, #f1f5f9 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #f1f5f9 75%), linear-gradient(-45deg, transparent 75%, #f1f5f9 75%)',
                    backgroundSize: '20px 20px',
                    backgroundPosition: '0 0, 0 10px, 10px -10px, -10px 0px',
                  }}
                >
                  <img
                    src={resultUrl}
                    alt="Processed output preview"
                    className="max-h-72 object-contain rounded"
                  />
                </div>
              </div>
            )}
          </div>
        )}

        {statusMsg && !resultUrl && (
          <p className="text-xs font-medium text-[#059669]">{statusMsg}</p>
        )}
      </div>
    </div>
  );
}
