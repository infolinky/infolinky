import { useState, useRef } from 'react';
import { Upload, Download, Trash2, ArrowUp, ArrowDown, Loader2, AlertCircle } from 'lucide-react';
import { PDFDocument } from 'pdf-lib';
import { jsPDF } from 'jspdf';
import * as pdfjsLib from 'pdfjs-dist';
import pdfWorkerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import mammoth from 'mammoth';
import { Document, Packer, Paragraph, TextRun } from 'docx';
import { TOOLS_CATALOG } from '../data/toolsCatalog';

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorkerUrl;

const PDF_TOOLS = TOOLS_CATALOG.filter((t) => t.category === 'pdf');

interface PdfToolsWorkspaceProps {
  activeToolId: string;
  onSelectTool: (id: string) => void;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function parsePageRanges(rangeStr: string, maxPages: number): number[] {
  const pages = new Set<number>();
  const parts = rangeStr
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);

  for (const part of parts) {
    if (part.includes('-')) {
      const [aStr, bStr] = part.split('-');
      const a = Math.max(1, parseInt(aStr, 10));
      const b = Math.min(maxPages, parseInt(bStr, 10));
      if (!Number.isNaN(a) && !Number.isNaN(b) && a <= b) {
        for (let i = a; i <= b; i++) pages.add(i - 1);
      }
    } else {
      const n = parseInt(part, 10);
      if (!Number.isNaN(n) && n >= 1 && n <= maxPages) {
        pages.add(n - 1);
      }
    }
  }
  return Array.from(pages).sort((x, y) => x - y);
}

export function PdfToolsWorkspace({ activeToolId, onSelectTool }: PdfToolsWorkspaceProps) {
  const currentTool = PDF_TOOLS.find((t) => t.id === activeToolId) || PDF_TOOLS[0];
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [files, setFiles] = useState<File[]>([]);
  const [pageCount, setPageCount] = useState<number>(0);
  const [splitRange, setSplitRange] = useState<string>('1');
  const [compressQuality, setCompressQuality] = useState<number>(65);
  const [busy, setBusy] = useState<boolean>(false);
  const [error, setError] = useState<string>('');
  const [status, setStatus] = useState<string>('');
  const [downloadUrl, setDownloadUrl] = useState<string>('');
  const [downloadName, setDownloadName] = useState<string>('output.pdf');
  const [renderedJpgs, setRenderedJpgs] = useState<{ page: number; url: string }[]>([]);

  const clearOutputs = () => {
    if (downloadUrl) URL.revokeObjectURL(downloadUrl);
    setDownloadUrl('');
    setRenderedJpgs([]);
    setError('');
    setStatus('');
  };

  const handleFilesSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const picked = Array.from(e.target.files || []);
    if (picked.length === 0) return;
    clearOutputs();

    if (currentTool.id === 'pdf-merge' || currentTool.id === 'jpg-to-pdf') {
      setFiles((prev) => [...prev, ...picked]);
    } else {
      setFiles([picked[0]]);
      if (
        picked[0].type === 'application/pdf' ||
        picked[0].name.toLowerCase().endsWith('.pdf')
      ) {
        try {
          const buf = await picked[0].arrayBuffer();
          const pdf = await PDFDocument.load(buf);
          const count = pdf.getPageCount();
          setPageCount(count);
          setSplitRange(count > 1 ? `1-${Math.min(2, count)}` : '1');
        } catch {
          setPageCount(0);
          setError('Could not inspect PDF pages. Ensure the PDF is not password-encrypted.');
        }
      }
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const moveFile = (idx: number, dir: -1 | 1) => {
    setFiles((prev) => {
      const next = [...prev];
      const target = idx + dir;
      if (target < 0 || target >= next.length) return prev;
      const [moved] = next.splice(idx, 1);
      next.splice(target, 0, moved);
      return next;
    });
  };

  const runPdfMerge = async () => {
    if (files.length < 2) {
      setError('Please add at least 2 PDF files to merge.');
      return;
    }
    const merged = await PDFDocument.create();
    for (const f of files) {
      const bytes = await f.arrayBuffer();
      const doc = await PDFDocument.load(bytes);
      const copied = await merged.copyPages(doc, doc.getPageIndices());
      copied.forEach((p) => merged.addPage(p));
    }
    const outBytes = await merged.save();
    const blob = new Blob([new Uint8Array(outBytes)], { type: 'application/pdf' });
    setDownloadUrl(URL.createObjectURL(blob));
    setDownloadName('infolinky-merged.pdf');
    setStatus(`Merged ${files.length} PDF files (${merged.getPageCount()} pages total, ${formatBytes(blob.size)}).`);
  };

  const runPdfSplit = async () => {
    if (files.length === 0) return;
    const bytes = await files[0].arrayBuffer();
    const src = await PDFDocument.load(bytes);
    const total = src.getPageCount();
    const indices = parsePageRanges(splitRange, total);
    if (indices.length === 0) {
      setError(`Enter valid page numbers between 1 and ${total} (for example: 1-2, 4).`);
      return;
    }
    const outDoc = await PDFDocument.create();
    const copied = await outDoc.copyPages(src, indices);
    copied.forEach((p) => outDoc.addPage(p));
    const outBytes = await outDoc.save();
    const blob = new Blob([new Uint8Array(outBytes)], { type: 'application/pdf' });
    setDownloadUrl(URL.createObjectURL(blob));
    setDownloadName('infolinky-split.pdf');
    setStatus(`Extracted ${indices.length} page(s) into a new PDF (${formatBytes(blob.size)}).`);
  };

  const runPdfCompress = async () => {
    if (files.length === 0) return;
    const file = files[0];
    const data = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data }).promise;
    const doc = new jsPDF({ unit: 'pt', compress: true });

    for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
      const page = await pdf.getPage(pageNum);
      const viewport = page.getViewport({ scale: 1.25 });
      const canvas = document.createElement('canvas');
      canvas.width = viewport.width;
      canvas.height = viewport.height;
      const ctx = canvas.getContext('2d');
      if (!ctx) continue;
      await page.render({ canvasContext: ctx, viewport, canvas }).promise;
      const jpegData = canvas.toDataURL('image/jpeg', compressQuality / 100);

      const orient = viewport.width > viewport.height ? 'l' : 'p';
      if (pageNum === 1) {
        doc.deletePage(1);
      }
      doc.addPage([viewport.width, viewport.height], orient);
      doc.addImage(jpegData, 'JPEG', 0, 0, viewport.width, viewport.height, undefined, 'FAST');
    }

    const blob = doc.output('blob');
    setDownloadUrl(URL.createObjectURL(blob));
    setDownloadName(`compressed-${file.name}`);
    setStatus(
      `Original: ${formatBytes(file.size)} → Compressed: ${formatBytes(blob.size)}.`
    );
  };

  const runPdfToJpg = async () => {
    if (files.length === 0) return;
    const data = await files[0].arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data }).promise;
    const pagesOut: { page: number; url: string }[] = [];

    for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
      const page = await pdf.getPage(pageNum);
      const viewport = page.getViewport({ scale: 1.6 });
      const canvas = document.createElement('canvas');
      canvas.width = viewport.width;
      canvas.height = viewport.height;
      const ctx = canvas.getContext('2d');
      if (!ctx) continue;
      await page.render({ canvasContext: ctx, viewport, canvas }).promise;
      pagesOut.push({ page: pageNum, url: canvas.toDataURL('image/jpeg', 0.92) });
    }
    setRenderedJpgs(pagesOut);
    setStatus(`Rendered ${pagesOut.length} PDF page(s) to JPG images.`);
  };

  const runJpgToPdf = async () => {
    if (files.length === 0) return;
    const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
    const pageW = doc.internal.pageSize.getWidth();
    const pageH = doc.internal.pageSize.getHeight();
    const margin = 10;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () => reject(new Error('Failed to read image'));
        reader.readAsDataURL(file);
      });
      const img = await new Promise<HTMLImageElement>((resolve, reject) => {
        const el = new Image();
        el.onload = () => resolve(el);
        el.onerror = () => reject(new Error('Invalid image'));
        el.src = dataUrl;
      });
      if (i > 0) doc.addPage();
      const maxW = pageW - margin * 2;
      const maxH = pageH - margin * 2;
      const ratio = Math.min(maxW / img.naturalWidth, maxH / img.naturalHeight);
      const w = img.naturalWidth * ratio;
      const h = img.naturalHeight * ratio;
      const fmt = dataUrl.startsWith('data:image/png') ? 'PNG' : 'JPEG';
      doc.addImage(dataUrl, fmt, (pageW - w) / 2, (pageH - h) / 2, w, h);
    }

    const blob = doc.output('blob');
    setDownloadUrl(URL.createObjectURL(blob));
    setDownloadName('infolinky-photos.pdf');
    setStatus(`Created PDF from ${files.length} image(s) (${formatBytes(blob.size)}).`);
  };

  const runPdfToWord = async () => {
    if (files.length === 0) return;
    const data = await files[0].arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data }).promise;
    const paragraphs: Paragraph[] = [];

    for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
      const page = await pdf.getPage(pageNum);
      const content = await page.getTextContent();
      const text = content.items
        .map((item) => ('str' in item ? item.str : ''))
        .join(' ')
        .replace(/\s+/g, ' ')
        .trim();

      paragraphs.push(
        new Paragraph({
          children: [new TextRun({ text: `Page ${pageNum}`, bold: true })],
        }),
        new Paragraph({
          children: [new TextRun({ text: text || '(No selectable text found on this page)' })],
        }),
        new Paragraph({ text: '' })
      );
    }

    const doc = new Document({
      sections: [{ properties: {}, children: paragraphs }],
    });
    const blob = await Packer.toBlob(doc);
    setDownloadUrl(URL.createObjectURL(blob));
    setDownloadName(files[0].name.replace(/\.pdf$/i, '') + '.docx');
    setStatus(`Extracted text from ${pdf.numPages} page(s) into a downloadable .docx Word document.`);
  };

  const runWordToPdf = async () => {
    if (files.length === 0) return;
    const file = files[0];
    if (!file.name.toLowerCase().endsWith('.docx')) {
      setError('Please upload a .docx Word document.');
      return;
    }
    const arrayBuffer = await file.arrayBuffer();
    const result = await mammoth.extractRawText({ arrayBuffer });
    const rawText = result.value.trim() || '(Empty document)';

    const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(11);
    const lines = doc.splitTextToSize(rawText, 180);
    let y = 18;
    for (const line of lines) {
      if (y > 280) {
        doc.addPage();
        y = 18;
      }
      doc.text(line, 15, y);
      y += 6;
    }

    const blob = doc.output('blob');
    setDownloadUrl(URL.createObjectURL(blob));
    setDownloadName(file.name.replace(/\.docx$/i, '') + '.pdf');
    setStatus(`Converted "${file.name}" into a paginated PDF (${formatBytes(blob.size)}).`);
  };

  const handleRun = async () => {
    if (files.length === 0) {
      setError('Please select a file first.');
      return;
    }
    setBusy(true);
    clearOutputs();

    try {
      if (currentTool.id === 'pdf-merge') await runPdfMerge();
      else if (currentTool.id === 'pdf-split') await runPdfSplit();
      else if (currentTool.id === 'pdf-compress') await runPdfCompress();
      else if (currentTool.id === 'pdf-to-jpg') await runPdfToJpg();
      else if (currentTool.id === 'jpg-to-pdf') await runJpgToPdf();
      else if (currentTool.id === 'pdf-to-word') await runPdfToWord();
      else if (currentTool.id === 'word-to-pdf') await runWordToPdf();
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'Could not process this document. Verify the file is unencrypted and valid.'
      );
    } finally {
      setBusy(false);
    }
  };

  const acceptType =
    currentTool.id === 'jpg-to-pdf'
      ? 'image/jpeg,image/png,image/webp'
      : currentTool.id === 'word-to-pdf'
        ? '.docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        : '.pdf,application/pdf';

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      <div className="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-3">
        <div className="px-3 py-2 text-xs font-semibold text-slate-500">
          Browser PDF Suite (7 Tools)
        </div>
        <div className="space-y-1">
          {PDF_TOOLS.map((tool) => (
            <button
              key={tool.id}
              type="button"
              onClick={() => {
                onSelectTool(tool.id);
                setFiles([]);
                setPageCount(0);
                clearOutputs();
              }}
              className={`w-full text-left px-3 py-2.5 rounded-lg text-sm transition-colors cursor-pointer ${
                tool.id === currentTool.id
                  ? 'bg-[#101C35] text-white font-semibold'
                  : 'text-slate-700 hover:bg-[#F5F7FB]'
              }`}
            >
              {tool.name}
            </button>
          ))}
        </div>
      </div>

      <div className="lg:col-span-8 bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-6">
        <div className="border-b border-slate-100 pb-4">
          <div className="text-xs font-medium text-[#059669] mb-1">
            Private Local Document Processing
          </div>
          <h2 className="font-display text-xl sm:text-2xl font-bold text-[#101C35]">
            {currentTool.name}
          </h2>
          <p className="text-sm text-slate-600 mt-1">{currentTool.description}</p>
        </div>

        <div>
          <input
            ref={fileInputRef}
            id="pdf-tool-upload"
            type="file"
            accept={acceptType}
            multiple={currentTool.id === 'pdf-merge' || currentTool.id === 'jpg-to-pdf'}
            onChange={handleFilesSelected}
            className="hidden"
          />
          <label
            htmlFor="pdf-tool-upload"
            className="flex flex-col items-center justify-center border-2 border-dashed border-slate-300 hover:border-[#2563EB] bg-[#F5F7FB] rounded-xl p-6 text-center cursor-pointer transition-colors"
          >
            <Upload className="w-6 h-6 text-[#2563EB] mb-2" aria-hidden="true" />
            <span className="text-sm font-semibold text-[#101C35]">
              {currentTool.id === 'word-to-pdf'
                ? 'Choose a .docx Word document'
                : currentTool.id === 'jpg-to-pdf'
                  ? 'Add one or more JPG/PNG images'
                  : currentTool.id === 'pdf-merge'
                    ? 'Add PDF files to merge'
                    : 'Choose a PDF file'}
            </span>
            <span className="text-xs text-slate-500 mt-1">
              Documents remain on your device—nothing is uploaded to external storage
            </span>
          </label>
        </div>

        {files.length > 0 && (
          <div className="space-y-4">
            <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg">
              {files.map((f, idx) => (
                <div
                  key={`${f.name}-${idx}`}
                  className="px-3.5 py-2.5 flex items-center justify-between gap-3 text-xs"
                >
                  <div className="min-w-0">
                    <div className="font-semibold text-[#101C35] truncate">{f.name}</div>
                    <div className="text-slate-500 tabular-nums">
                      {formatBytes(f.size)}
                      {pageCount > 0 && files.length === 1 ? ` · ${pageCount} pages` : ''}
                    </div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    {(currentTool.id === 'pdf-merge' || currentTool.id === 'jpg-to-pdf') && (
                      <>
                        <button
                          type="button"
                          onClick={() => moveFile(idx, -1)}
                          aria-label="Move up"
                          className="p-1.5 rounded hover:bg-slate-100 text-slate-600 cursor-pointer"
                        >
                          <ArrowUp className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => moveFile(idx, 1)}
                          aria-label="Move down"
                          className="p-1.5 rounded hover:bg-slate-100 text-slate-600 cursor-pointer"
                        >
                          <ArrowDown className="w-3.5 h-3.5" />
                        </button>
                      </>
                    )}
                    <button
                      type="button"
                      onClick={() => {
                        setFiles((prev) => prev.filter((_, i) => i !== idx));
                        clearOutputs();
                      }}
                      aria-label="Remove file"
                      className="p-1.5 rounded hover:bg-rose-50 text-rose-600 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {currentTool.id === 'pdf-split' && pageCount > 0 && (
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">
                  Pages to extract (Total: {pageCount} — e.g. 1-2, 4)
                </label>
                <input
                  type="text"
                  value={splitRange}
                  onChange={(e) => setSplitRange(e.target.value)}
                  className="w-full sm:w-72 h-10 px-3 rounded-lg border border-slate-200 text-sm font-mono"
                />
              </div>
            )}

            {currentTool.id === 'pdf-compress' && (
              <div>
                <div className="flex justify-between text-xs font-medium text-slate-600 mb-1">
                  <span>Page Raster Compression Quality (Lower = Smaller File)</span>
                  <span className="tabular-nums">{compressQuality}%</span>
                </div>
                <input
                  type="range"
                  min={25}
                  max={95}
                  value={compressQuality}
                  onChange={(e) => setCompressQuality(Number(e.target.value))}
                  className="w-full accent-[#2563EB]"
                />
              </div>
            )}

            <button
              type="button"
              disabled={busy}
              onClick={handleRun}
              className="inline-flex items-center gap-2 h-10 px-6 rounded-lg bg-[#2563EB] hover:bg-[#1d4ed8] disabled:opacity-60 text-white text-sm font-semibold cursor-pointer"
            >
              {busy && <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" />}
              <span>{busy ? 'Processing...' : `Run ${currentTool.name}`}</span>
            </button>
          </div>
        )}

        {error && (
          <div
            role="alert"
            className="flex items-start gap-2.5 p-3.5 rounded-lg border border-rose-200 bg-rose-50 text-xs text-rose-800"
          >
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" aria-hidden="true" />
            <span>{error}</span>
          </div>
        )}

        {status && (
          <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <span className="text-xs font-medium text-emerald-900">{status}</span>
            {downloadUrl && (
              <a
                href={downloadUrl}
                download={downloadName}
                className="inline-flex items-center justify-center gap-2 h-9 px-4 rounded-lg bg-[#059669] text-white text-xs font-semibold hover:bg-[#047857] shrink-0"
              >
                <Download className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Download {downloadName}</span>
              </a>
            )}
          </div>
        )}

        {renderedJpgs.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 pt-2">
            {renderedJpgs.map((item) => (
              <div key={item.page} className="border border-slate-200 rounded-lg p-2.5 bg-[#F5F7FB] space-y-2">
                <img
                  src={item.url}
                  alt={`PDF Page ${item.page}`}
                  className="w-full h-44 object-contain bg-white rounded border border-slate-100"
                />
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium text-slate-700 tabular-nums">Page {item.page}</span>
                  <a
                    href={item.url}
                    download={`page-${item.page}.jpg`}
                    className="font-semibold text-[#2563EB] hover:underline"
                  >
                    Download JPG
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
