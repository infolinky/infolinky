import { useState } from 'react';
import { Copy, Check, Download, Loader2, AlertCircle } from 'lucide-react';
import { TOOLS_CATALOG } from '../data/toolsCatalog';

const AI_TOOLS = TOOLS_CATALOG.filter((t) => t.category === 'ai-writing');

const LANGUAGES = [
  'Spanish',
  'French',
  'German',
  'Arabic',
  'Urdu',
  'Hindi',
  'Chinese (Simplified)',
  'Japanese',
  'Portuguese',
  'Turkish',
];

const TONES = ['Professional', 'Clear & Direct', 'Friendly', 'Academic', 'Persuasive'];
const LENGTHS = ['Short', 'Medium', 'Detailed'];
const PLATFORMS = ['LinkedIn', 'X (Twitter)', 'Instagram', 'Facebook', 'TikTok'];

interface AiToolsWorkspaceProps {
  activeToolId: string;
  onSelectTool: (id: string) => void;
}

export function AiToolsWorkspace({ activeToolId, onSelectTool }: AiToolsWorkspaceProps) {
  const currentTool = AI_TOOLS.find((t) => t.id === activeToolId) || AI_TOOLS[0];
  const [input, setInput] = useState('');
  const [tone, setTone] = useState('Professional');
  const [length, setLength] = useState('Medium');
  const [targetLanguage, setTargetLanguage] = useState('Spanish');
  const [platform, setPlatform] = useState('LinkedIn');
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) {
      setError('Please enter source text or a prompt first.');
      return;
    }
    setLoading(true);
    setError('');
    setOutput('');

    try {
      const res = await fetch('/api/ai/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          toolId: currentTool.id,
          input,
          tone,
          length,
          targetLanguage,
          platform,
        }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        setError(data.error || 'Unable to generate output right now.');
      } else {
        setOutput(data.output || '');
      }
    } catch {
      setError(
        'Could not reach the InfoLinky server-side AI endpoint. If running as a static GitHub Pages build, connect a backend proxy for AI tools.'
      );
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = async () => {
    if (!output) return;
    await navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  const handleDownload = () => {
    if (!output) return;
    const blob = new Blob([output], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${currentTool.id}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const placeholderByTool: Record<string, string> = {
    'ai-text-generator': 'Describe the topic, key points, or text you want drafted...',
    'ai-content-writer': 'Describe the product, landing page section, or service to write copy for...',
    'ai-paragraph-rewriter': 'Paste the paragraph you want rewritten for better clarity and flow...',
    'ai-summarizer': 'Paste an article, meeting transcript, or long passage to summarize...',
    'ai-translator': 'Enter text to translate accurately into your selected target language...',
    'ai-grammar-checker': 'Paste text to check grammar, punctuation, spelling, and sentence clarity...',
    'ai-email-writer': 'Enter recipient role, purpose of email, and key details to include...',
    'ai-social-caption': 'Describe your post topic, audience, or product announcement...',
    'ai-blog-post': 'Enter the blog topic, target reader, and main points to cover...',
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Tool Selector */}
      <div className="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-3">
        <div className="px-3 py-2 text-xs font-semibold text-slate-500">
          AI Writing Suite (9 Tools)
        </div>
        <div className="space-y-1">
          {AI_TOOLS.map((tool) => {
            const active = tool.id === currentTool.id;
            return (
              <button
                key={tool.id}
                type="button"
                onClick={() => {
                  onSelectTool(tool.id);
                  setError('');
                }}
                className={`w-full text-left px-3 py-2.5 rounded-lg text-sm transition-colors cursor-pointer ${
                  active
                    ? 'bg-[#101C35] text-white font-semibold'
                    : 'text-slate-700 hover:bg-[#F5F7FB]'
                }`}
              >
                {tool.name}
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Workspace */}
      <div className="lg:col-span-8 bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-6">
        <div className="border-b border-slate-100 pb-4">
          <div className="text-xs font-medium text-[#2563EB] mb-1">
            Server-Side Gemini AI · {currentTool.categoryLabel}
          </div>
          <h2 className="font-display text-xl sm:text-2xl font-bold text-[#101C35]">
            {currentTool.name}
          </h2>
          <p className="text-sm text-slate-600 mt-1">{currentTool.description}</p>
        </div>

        <form onSubmit={handleGenerate} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label htmlFor="ai-tone" className="block text-xs font-medium text-slate-600 mb-1">
                Tone
              </label>
              <select
                id="ai-tone"
                value={tone}
                onChange={(e) => setTone(e.target.value)}
                className="w-full h-10 px-3 rounded-lg border border-slate-200 bg-white text-sm text-[#101C35] focus:outline-none focus:border-[#2563EB]"
              >
                {TONES.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>

            {currentTool.id === 'ai-translator' ? (
              <div>
                <label htmlFor="ai-lang" className="block text-xs font-medium text-slate-600 mb-1">
                  Target Language
                </label>
                <select
                  id="ai-lang"
                  value={targetLanguage}
                  onChange={(e) => setTargetLanguage(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg border border-slate-200 bg-white text-sm text-[#101C35] focus:outline-none focus:border-[#2563EB]"
                >
                  {LANGUAGES.map((lang) => (
                    <option key={lang} value={lang}>
                      {lang}
                    </option>
                  ))}
                </select>
              </div>
            ) : currentTool.id === 'ai-social-caption' ? (
              <div>
                <label htmlFor="ai-platform" className="block text-xs font-medium text-slate-600 mb-1">
                  Platform
                </label>
                <select
                  id="ai-platform"
                  value={platform}
                  onChange={(e) => setPlatform(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg border border-slate-200 bg-white text-sm text-[#101C35] focus:outline-none focus:border-[#2563EB]"
                >
                  {PLATFORMS.map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </select>
              </div>
            ) : (
              <div>
                <label htmlFor="ai-length" className="block text-xs font-medium text-slate-600 mb-1">
                  Output Length
                </label>
                <select
                  id="ai-length"
                  value={length}
                  onChange={(e) => setLength(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg border border-slate-200 bg-white text-sm text-[#101C35] focus:outline-none focus:border-[#2563EB]"
                >
                  {LENGTHS.map((l) => (
                    <option key={l} value={l}>
                      {l}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div className="flex items-end">
              <button
                type="submit"
                disabled={loading}
                className="w-full h-10 px-4 rounded-lg bg-[#2563EB] hover:bg-[#1d4ed8] disabled:opacity-60 text-white font-semibold text-sm inline-flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                {loading && <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" />}
                <span>{loading ? 'Generating...' : 'Run Tool'}</span>
              </button>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label htmlFor="ai-input" className="text-xs font-medium text-slate-600">
                Input Text or Prompt
              </label>
              <span className="text-xs text-slate-400 tabular-nums">
                {input.length.toLocaleString()} / 15,000 chars
              </span>
            </div>
            <textarea
              id="ai-input"
              rows={6}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={placeholderByTool[currentTool.id] || 'Enter text here...'}
              className="w-full p-3.5 rounded-lg border border-slate-200 bg-[#F5F7FB] focus:bg-white text-sm text-[#101C35] placeholder:text-slate-400 focus:outline-none focus:border-[#2563EB]"
            />
          </div>
        </form>

        {error && (
          <div
            role="alert"
            className="flex items-start gap-2.5 p-3.5 rounded-lg border border-rose-200 bg-rose-50 text-xs text-rose-800"
          >
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" aria-hidden="true" />
            <span>{error}</span>
          </div>
        )}

        {output && (
          <div className="space-y-2.5 pt-2 border-t border-slate-100">
            <div className="flex items-center justify-between gap-3">
              <span className="text-xs font-semibold text-[#101C35]">Generated Result</span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleCopy}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  {copied ? (
                    <Check className="w-3.5 h-3.5 text-[#059669]" aria-hidden="true" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" aria-hidden="true" />
                  )}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
                <button
                  type="button"
                  onClick={handleDownload}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#101C35] text-white text-xs font-medium hover:bg-[#1b2d52] cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Download .txt</span>
                </button>
              </div>
            </div>
            <div className="p-4 rounded-lg border border-slate-200 bg-[#F5F7FB] text-sm text-[#101C35] whitespace-pre-wrap leading-relaxed max-h-[420px] overflow-y-auto">
              {output}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
