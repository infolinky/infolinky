import { useState, useRef, useEffect } from 'react';
import { Copy, Check, Download, RefreshCw } from 'lucide-react';
import { TOOLS_CATALOG } from '../data/toolsCatalog';

const DESIGN_TOOLS = TOOLS_CATALOG.filter((t) => t.category === 'design');

function hexToRgb(hex: string): { r: number; g: number; b: number } {
  const clean = hex.replace('#', '');
  const num = parseInt(clean.length === 3 ? clean.replace(/(.)/g, '$1$1') : clean, 16) || 0;
  return { r: (num >> 16) & 255, g: (num >> 8) & 255, b: num & 255 };
}

function rgbToHsl(r: number, g: number, b: number): { h: number; s: number; l: number } {
  r /= 255;
  g /= 255;
  b /= 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h = 0;
  let s = 0;
  const l = (max + min) / 2;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0);
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      default:
        h = (r - g) / d + 4;
    }
    h /= 6;
  }
  return { h: Math.round(h * 360), s: Math.round(s * 100), l: Math.round(l * 100) };
}

function hslToHex(h: number, s: number, l: number): string {
  const sn = s / 100;
  const ln = l / 100;
  const a = sn * Math.min(ln, 1 - ln);
  const f = (n: number) => {
    const k = (n + h / 30) % 12;
    const color = ln - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
    return Math.round(255 * color)
      .toString(16)
      .padStart(2, '0');
  };
  return `#${f(0)}${f(8)}${f(4)}`.toUpperCase();
}

function relativeLuminance(hex: string): number {
  const { r, g, b } = hexToRgb(hex);
  const chan = [r, g, b].map((v) => {
    const c = v / 255;
    return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * chan[0] + 0.7152 * chan[1] + 0.0722 * chan[2];
}

function contrastRatio(hexA: string, hexB: string): number {
  const l1 = relativeLuminance(hexA);
  const l2 = relativeLuminance(hexB);
  return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
}

interface DesignToolsWorkspaceProps {
  activeToolId: string;
  onSelectTool: (id: string) => void;
}

export function DesignToolsWorkspace({ activeToolId, onSelectTool }: DesignToolsWorkspaceProps) {
  const currentTool = DESIGN_TOOLS.find((t) => t.id === activeToolId) || DESIGN_TOOLS[0];
  const [copied, setCopied] = useState(false);

  const [pickedColor, setPickedColor] = useState('#2563EB');
  const [baseHex, setBaseHex] = useState('#101C35');
  const [harmony, setHarmony] = useState<'analogous' | 'complementary' | 'triadic' | 'mono'>(
    'triadic'
  );

  const [gradA, setGradA] = useState('#101C35');
  const [gradB, setGradB] = useState('#2563EB');
  const [gradAngle, setGradAngle] = useState(135);
  const [gradType, setGradType] = useState<'linear' | 'radial'>('linear');

  const [logoBrand, setLogoBrand] = useState('InfoLinky');
  const [logoInitials, setLogoInitials] = useState('IL');
  const [logoBg, setLogoBg] = useState('#101C35');
  const [logoAccent, setLogoAccent] = useState('#D4AF37');
  const [logoShape, setLogoShape] = useState<'rounded' | 'circle' | 'hexagon'>('rounded');

  const [postPreset, setPostPreset] = useState<'square' | 'landscape' | 'story'>('square');
  const [postHeadline, setPostHeadline] = useState('Build Faster With 50+ Digital Tools');
  const [postSubtext, setPostSubtext] = useState(
    'Free browser-based PDF, image, and AI utilities.'
  );
  const [postCta, setPostCta] = useState('Explore InfoLinky');
  const [postBg, setPostBg] = useState('#101C35');
  const [postAccent, setPostAccent] = useState('#D4AF37');
  const socialCanvasRef = useRef<HTMLCanvasElement>(null);

  const copyText = async (val: string) => {
    await navigator.clipboard.writeText(val);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const rgb = hexToRgb(pickedColor);
  const hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);
  const whiteContrast = contrastRatio(pickedColor, '#FFFFFF');
  const darkContrast = contrastRatio(pickedColor, '#101C35');

  const paletteColors = (() => {
    const c = hexToRgb(baseHex);
    const base = rgbToHsl(c.r, c.g, c.b);
    if (harmony === 'analogous') {
      return [
        hslToHex((base.h + 330) % 360, base.s, base.l),
        hslToHex((base.h + 345) % 360, base.s, Math.min(90, base.l + 8)),
        baseHex.toUpperCase(),
        hslToHex((base.h + 15) % 360, base.s, Math.min(90, base.l + 8)),
        hslToHex((base.h + 30) % 360, base.s, base.l),
      ];
    }
    if (harmony === 'complementary') {
      return [
        baseHex.toUpperCase(),
        hslToHex(base.h, Math.max(15, base.s - 20), Math.min(92, base.l + 25)),
        hslToHex((base.h + 180) % 360, base.s, base.l),
        hslToHex((base.h + 180) % 360, Math.max(15, base.s - 20), Math.min(92, base.l + 22)),
        hslToHex(base.h, 15, 95),
      ];
    }
    if (harmony === 'mono') {
      return [
        hslToHex(base.h, base.s, Math.max(12, base.l - 18)),
        baseHex.toUpperCase(),
        hslToHex(base.h, base.s, Math.min(75, base.l + 18)),
        hslToHex(base.h, Math.max(10, base.s - 20), Math.min(88, base.l + 34)),
        hslToHex(base.h, 12, 95),
      ];
    }
    return [
      baseHex.toUpperCase(),
      hslToHex((base.h + 120) % 360, base.s, base.l),
      hslToHex((base.h + 240) % 360, base.s, base.l),
      hslToHex(base.h, Math.max(15, base.s - 20), 90),
      hslToHex((base.h + 120) % 360, Math.max(15, base.s - 20), 90),
    ];
  })();

  const gradientCss =
    gradType === 'linear'
      ? `linear-gradient(${gradAngle}deg, ${gradA}, ${gradB})`
      : `radial-gradient(circle, ${gradA}, ${gradB})`;

  const safeBrand = logoBrand.replace(/[<>&"]/g, '');
  const safeInitials = logoInitials.slice(0, 3).replace(/[<>&"]/g, '');

  const logoSvgMarkup = `<svg xmlns="http://www.w3.org/2000/svg" width="512" height="160" viewBox="0 0 512 160">
  <rect width="512" height="160" fill="#FFFFFF" rx="16"/>
  ${
    logoShape === 'circle'
      ? `<circle cx="84" cy="80" r="46" fill="${logoBg}"/>`
      : logoShape === 'hexagon'
        ? `<polygon points="84,30 128,55 128,105 84,130 40,105 40,55" fill="${logoBg}"/>`
        : `<rect x="38" y="34" width="92" height="92" rx="20" fill="${logoBg}"/>`
  }
  <rect x="38" y="114" width="92" height="6" rx="3" fill="${logoAccent}"/>
  <text x="84" y="92" text-anchor="middle" font-family="Plus Jakarta Sans, Arial, sans-serif" font-weight="800" font-size="34" fill="#FFFFFF">${safeInitials}</text>
  <text x="156" y="94" font-family="Plus Jakarta Sans, Arial, sans-serif" font-weight="700" font-size="40" fill="${logoBg}">${safeBrand}</text>
</svg>`;

  const downloadLogoPng = () => {
    const img = new Image();
    const blob = new Blob([logoSvgMarkup], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    img.onload = () => {
      const c = document.createElement('canvas');
      c.width = 1024;
      c.height = 320;
      const ctx = c.getContext('2d');
      if (ctx) {
        ctx.drawImage(img, 0, 0, 1024, 320);
        const a = document.createElement('a');
        a.href = c.toDataURL('image/png');
        a.download = `${logoBrand.toLowerCase().replace(/\s+/g, '-')}-logo.png`;
        a.click();
      }
      URL.revokeObjectURL(url);
    };
    img.src = url;
  };

  useEffect(() => {
    if (currentTool.id !== 'social-post-designer') return;
    const canvas = socialCanvasRef.current;
    if (!canvas) return;
    const dims =
      postPreset === 'square'
        ? { w: 1080, h: 1080 }
        : postPreset === 'landscape'
          ? { w: 1200, h: 675 }
          : { w: 1080, h: 1920 };
    canvas.width = dims.w;
    canvas.height = dims.h;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = postBg;
    ctx.fillRect(0, 0, dims.w, dims.h);

    ctx.fillStyle = postAccent;
    ctx.fillRect(72, 72, 96, 8);

    ctx.fillStyle = '#FFFFFF';
    ctx.font = `bold ${dims.w > 1100 ? 64 : 68}px sans-serif`;
    const words = postHeadline.split(' ');
    const lines: string[] = [];
    let current = '';
    for (const w of words) {
      const test = current ? `${current} ${w}` : w;
      if (ctx.measureText(test).width > dims.w - 144) {
        lines.push(current);
        current = w;
      } else {
        current = test;
      }
    }
    if (current) lines.push(current);

    let y = dims.h * 0.34;
    lines.forEach((line) => {
      ctx.fillText(line, 72, y);
      y += 84;
    });

    ctx.fillStyle = '#CBD5E1';
    ctx.font = '34px sans-serif';
    ctx.fillText(postSubtext.slice(0, 62), 72, y + 28);

    ctx.fillStyle = postAccent;
    ctx.fillRect(72, dims.h - 170, 340, 68);
    ctx.fillStyle = '#101C35';
    ctx.font = 'bold 28px sans-serif';
    ctx.fillText(postCta.slice(0, 22), 104, dims.h - 126);
  }, [currentTool.id, postPreset, postHeadline, postSubtext, postCta, postBg, postAccent]);

  const downloadSocialPost = () => {
    const canvas = socialCanvasRef.current;
    if (!canvas) return;
    const a = document.createElement('a');
    a.href = canvas.toDataURL('image/png');
    a.download = `infolinky-social-${postPreset}.png`;
    a.click();
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      <div className="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-3">
        <div className="px-3 py-2 text-xs font-semibold text-slate-500">
          Design Suite (5 Tools)
        </div>
        <div className="space-y-1">
          {DESIGN_TOOLS.map((tool) => (
            <button
              key={tool.id}
              type="button"
              onClick={() => onSelectTool(tool.id)}
              className={`w-full text-left px-3 py-2.5 rounded-lg text-sm transition-colors cursor-pointer ${
                tool.id === currentTool.id
                  ? 'bg-[#101C35] text-white font-semibold'
                  : 'text-slate-700 hover:bg-[#F5F7FB]'
              }`}
            >
              {tool.name}
            </button>
          ))}
        </div>
      </div>

      <div className="lg:col-span-8 bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-6">
        <div className="border-b border-slate-100 pb-4">
          <div className="text-xs font-medium text-[#059669] mb-1">
            Interactive Visual &amp; Color Utilities
          </div>
          <h2 className="font-display text-xl sm:text-2xl font-bold text-[#101C35]">
            {currentTool.name}
          </h2>
          <p className="text-sm text-slate-600 mt-1">{currentTool.description}</p>
        </div>

        {currentTool.id === 'color-picker' && (
          <div className="space-y-5">
            <div className="flex flex-wrap items-center gap-4">
              <input
                type="color"
                value={pickedColor}
                onChange={(e) => setPickedColor(e.target.value.toUpperCase())}
                className="w-20 h-20 rounded-xl border border-slate-200 cursor-pointer"
              />
              <div className="space-y-2">
                <div className="font-mono text-sm text-[#101C35]">
                  HEX: <strong>{pickedColor}</strong>
                </div>
                <div className="font-mono text-sm text-slate-600">
                  RGB: rgb({rgb.r}, {rgb.g}, {rgb.b})
                </div>
                <div className="font-mono text-sm text-slate-600">
                  HSL: hsl({hsl.h}, {hsl.s}%, {hsl.l}%)
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div
                className="p-4 rounded-xl border border-slate-200"
                style={{ backgroundColor: pickedColor, color: '#FFFFFF' }}
              >
                <div className="text-sm font-semibold">White Text Contrast</div>
                <div className="text-xs mt-1 tabular-nums">
                  Ratio: {whiteContrast.toFixed(2)}:1 ·{' '}
                  {whiteContrast >= 4.5 ? 'WCAG AA Pass' : 'Low Contrast'}
                </div>
              </div>
              <div
                className="p-4 rounded-xl border border-slate-200"
                style={{ backgroundColor: pickedColor, color: '#101C35' }}
              >
                <div className="text-sm font-semibold">Navy Text Contrast</div>
                <div className="text-xs mt-1 tabular-nums">
                  Ratio: {darkContrast.toFixed(2)}:1 ·{' '}
                  {darkContrast >= 4.5 ? 'WCAG AA Pass' : 'Low Contrast'}
                </div>
              </div>
            </div>
          </div>
        )}

        {currentTool.id === 'color-palette-generator' && (
          <div className="space-y-5">
            <div className="flex flex-wrap items-center gap-4">
              <input
                type="color"
                value={baseHex}
                onChange={(e) => setBaseHex(e.target.value)}
                className="h-10 w-14 rounded border border-slate-200 cursor-pointer"
              />
              <select
                value={harmony}
                onChange={(e) => setHarmony(e.target.value as typeof harmony)}
                className="h-10 px-3 rounded-lg border border-slate-200 text-sm"
              >
                <option value="triadic">Triadic Harmony</option>
                <option value="analogous">Analogous Harmony</option>
                <option value="complementary">Complementary Harmony</option>
                <option value="mono">Monochromatic Scale</option>
              </select>
              <button
                type="button"
                onClick={() =>
                  setBaseHex(
                    `#${Math.floor(Math.random() * 16777215)
                      .toString(16)
                      .padStart(6, '0')}`
                  )
                }
                className="inline-flex items-center gap-1.5 h-10 px-4 rounded-lg bg-[#101C35] text-white text-xs font-semibold cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Random Seed
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              {paletteColors.map((hex) => (
                <button
                  key={hex}
                  type="button"
                  onClick={() => copyText(hex)}
                  className="text-left rounded-xl overflow-hidden border border-slate-200 hover:shadow-md transition-shadow cursor-pointer"
                >
                  <div className="h-24" style={{ backgroundColor: hex }} />
                  <div className="p-2.5 text-xs font-mono font-semibold text-[#101C35]">
                    {hex}
                  </div>
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={() =>
                copyText(
                  `:root {\n${paletteColors.map((c, i) => `  --color-${i + 1}: ${c};`).join('\n')}\n}`
                )
              }
              className="inline-flex items-center gap-1.5 h-9 px-4 rounded-lg border border-slate-200 text-xs font-semibold hover:bg-slate-50 cursor-pointer"
            >
              {copied ? (
                <Check className="w-3.5 h-3.5 text-[#059669]" />
              ) : (
                <Copy className="w-3.5 h-3.5" />
              )}
              <span>{copied ? 'Copied CSS Variables' : 'Copy CSS Variables'}</span>
            </button>
          </div>
        )}

        {currentTool.id === 'gradient-generator' && (
          <div className="space-y-5">
            <div
              className="h-44 rounded-xl border border-slate-200"
              style={{ background: gradientCss }}
            />
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 items-end">
              <div>
                <label className="block text-xs text-slate-600 mb-1">Start Color</label>
                <input
                  type="color"
                  value={gradA}
                  onChange={(e) => setGradA(e.target.value)}
                  className="w-full h-10 rounded border border-slate-200 cursor-pointer"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-600 mb-1">End Color</label>
                <input
                  type="color"
                  value={gradB}
                  onChange={(e) => setGradB(e.target.value)}
                  className="w-full h-10 rounded border border-slate-200 cursor-pointer"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-600 mb-1">Type</label>
                <select
                  value={gradType}
                  onChange={(e) => setGradType(e.target.value as 'linear' | 'radial')}
                  className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm"
                >
                  <option value="linear">Linear</option>
                  <option value="radial">Radial</option>
                </select>
              </div>
              <div>
                <label className="block text-xs text-slate-600 mb-1">
                  Angle ({gradAngle}°)
                </label>
                <input
                  type="range"
                  min={0}
                  max={360}
                  value={gradAngle}
                  disabled={gradType === 'radial'}
                  onChange={(e) => setGradAngle(Number(e.target.value))}
                  className="w-full accent-[#2563EB]"
                />
              </div>
            </div>
            <div className="p-3.5 rounded-lg bg-[#F5F7FB] border border-slate-200 flex items-center justify-between gap-3">
              <code className="text-xs text-[#101C35] break-all">
                background: {gradientCss};
              </code>
              <button
                type="button"
                onClick={() => copyText(`background: ${gradientCss};`)}
                className="px-3 py-1.5 rounded-lg bg-[#2563EB] text-white text-xs font-semibold shrink-0 cursor-pointer"
              >
                {copied ? 'Copied' : 'Copy CSS'}
              </button>
            </div>
          </div>
        )}

        {currentTool.id === 'logo-design-assistant' && (
          <div className="space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <input
                type="text"
                value={logoBrand}
                onChange={(e) => setLogoBrand(e.target.value)}
                placeholder="Brand Wordmark"
                className="h-10 px-3 rounded-lg border border-slate-200 text-sm"
              />
              <input
                type="text"
                maxLength={3}
                value={logoInitials}
                onChange={(e) => setLogoInitials(e.target.value.toUpperCase())}
                placeholder="Monogram (2-3 chars)"
                className="h-10 px-3 rounded-lg border border-slate-200 text-sm font-mono"
              />
              <select
                value={logoShape}
                onChange={(e) => setLogoShape(e.target.value as typeof logoShape)}
                className="h-10 px-3 rounded-lg border border-slate-200 text-sm"
              >
                <option value="rounded">Rounded Square Emblem</option>
                <option value="circle">Circular Emblem</option>
                <option value="hexagon">Hexagon Emblem</option>
              </select>
            </div>
            <div className="flex flex-wrap gap-4 items-center">
              <label className="flex items-center gap-2 text-xs text-slate-600">
                Primary Color
                <input
                  type="color"
                  value={logoBg}
                  onChange={(e) => setLogoBg(e.target.value)}
                />
              </label>
              <label className="flex items-center gap-2 text-xs text-slate-600">
                Accent Bar
                <input
                  type="color"
                  value={logoAccent}
                  onChange={(e) => setLogoAccent(e.target.value)}
                />
              </label>
            </div>
            <div
              className="border border-slate-200 rounded-xl p-6 bg-[#F5F7FB] flex justify-center"
              dangerouslySetInnerHTML={{ __html: logoSvgMarkup }}
            />
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => {
                  const blob = new Blob([logoSvgMarkup], { type: 'image/svg+xml' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `${logoBrand.toLowerCase().replace(/\s+/g, '-')}-logo.svg`;
                  a.click();
                  URL.revokeObjectURL(url);
                }}
                className="inline-flex items-center gap-1.5 h-10 px-4 rounded-lg bg-[#101C35] text-white text-xs font-semibold cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                Download SVG
              </button>
              <button
                type="button"
                onClick={downloadLogoPng}
                className="inline-flex items-center gap-1.5 h-10 px-4 rounded-lg bg-[#2563EB] text-white text-xs font-semibold cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                Download PNG
              </button>
            </div>
          </div>
        )}

        {currentTool.id === 'social-post-designer' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <select
                value={postPreset}
                onChange={(e) => setPostPreset(e.target.value as typeof postPreset)}
                className="h-10 px-3 rounded-lg border border-slate-200 text-sm"
              >
                <option value="square">Instagram / Square (1080×1080)</option>
                <option value="landscape">LinkedIn / X Card (1200×675)</option>
                <option value="story">Vertical Story (1080×1920)</option>
              </select>
              <label className="flex items-center justify-between px-3 h-10 rounded-lg border border-slate-200 text-xs">
                <span>Backdrop</span>
                <input
                  type="color"
                  value={postBg}
                  onChange={(e) => setPostBg(e.target.value)}
                />
              </label>
              <label className="flex items-center justify-between px-3 h-10 rounded-lg border border-slate-200 text-xs">
                <span>Accent</span>
                <input
                  type="color"
                  value={postAccent}
                  onChange={(e) => setPostAccent(e.target.value)}
                />
              </label>
            </div>
            <input
              type="text"
              value={postHeadline}
              onChange={(e) => setPostHeadline(e.target.value)}
              placeholder="Headline"
              className="w-full h-10 px-3 rounded-lg border border-slate-200 text-sm"
            />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                type="text"
                value={postSubtext}
                onChange={(e) => setPostSubtext(e.target.value)}
                placeholder="Subheadline"
                className="h-10 px-3 rounded-lg border border-slate-200 text-sm"
              />
              <input
                type="text"
                value={postCta}
                onChange={(e) => setPostCta(e.target.value)}
                placeholder="CTA Label"
                className="h-10 px-3 rounded-lg border border-slate-200 text-sm"
              />
            </div>

            <div className="border border-slate-200 rounded-xl p-4 bg-[#F5F7FB] flex justify-center">
              <canvas
                ref={socialCanvasRef}
                className="max-h-80 w-auto rounded-lg shadow border border-slate-200"
              />
            </div>

            <button
              type="button"
              onClick={downloadSocialPost}
              className="inline-flex items-center gap-2 h-10 px-5 rounded-lg bg-[#2563EB] hover:bg-[#1d4ed8] text-white text-sm font-semibold cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Download Social Graphic PNG</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
